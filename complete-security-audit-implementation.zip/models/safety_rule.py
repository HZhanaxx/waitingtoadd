"""
Safety Rule Model
=================

Database model for global safety rules that apply to all agents.
This implements the "Global Safety Loop" from the plan:
- Input detection
- Language filtering  
- Jailbreak protection
- Content moderation

Safety rules are evaluated before any agent processes a message.
"""
import uuid
from datetime import datetime
from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, JSON, Enum as SQLEnum
from sqlalchemy.dialects.postgresql import UUID
from database import Base
import enum


class SafetyRuleType(str, enum.Enum):
    """Types of safety rules"""
    INPUT_FILTER = "input_filter"          # Filter/block certain inputs
    OUTPUT_FILTER = "output_filter"        # Filter agent outputs
    JAILBREAK_DETECT = "jailbreak"         # Detect jailbreak attempts
    LANGUAGE_CHECK = "language"            # Language detection/enforcement
    CONTENT_MODERATION = "moderation"      # Content moderation
    RATE_LIMIT = "rate_limit"              # Rate limiting
    LENGTH_LIMIT = "length_limit"          # Message length limits
    CUSTOM = "custom"                      # Custom rule


class SafetyAction(str, enum.Enum):
    """Action to take when rule matches"""
    BLOCK = "block"                        # Block the message entirely
    WARN = "warn"                          # Allow but log warning
    MODIFY = "modify"                      # Modify the content
    REDIRECT = "redirect"                  # Redirect to different handler
    LOG_ONLY = "log_only"                  # Just log, no action
    REQUIRE_CONFIRMATION = "confirm"       # Require user confirmation


class SafetyRuleStatus(str, enum.Enum):
    """Rule status"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    TESTING = "testing"                    # Active but only logs


class SafetyRule(Base):
    """
    Global safety rule definition.
    
    Rules are evaluated in priority order. When a rule matches,
    the specified action is taken.
    """
    __tablename__ = "safety_rules"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # Basic Info
    name = Column(String(100), nullable=False, unique=True, index=True)
    display_name = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    rule_type = Column(SQLEnum(SafetyRuleType), nullable=False)
    
    # Status & Priority
    status = Column(SQLEnum(SafetyRuleStatus), default=SafetyRuleStatus.ACTIVE)
    priority = Column(Integer, default=0)  # Higher = evaluated first
    is_system = Column(Boolean, default=False)  # System rules cannot be deleted
    
    # Matching Configuration
    match_patterns = Column(JSON, nullable=True)  # Regex patterns to match
    match_keywords = Column(JSON, nullable=True)  # Keywords to detect
    match_embeddings = Column(Boolean, default=False)  # Use semantic matching
    embedding_threshold = Column(Integer, default=85)  # Similarity threshold (0-100)
    match_script = Column(Text, nullable=True)  # Custom Python matching script
    
    # Scope
    apply_to_input = Column(Boolean, default=True)  # Apply to user input
    apply_to_output = Column(Boolean, default=False)  # Apply to agent output
    agent_ids = Column(JSON, nullable=True)  # Specific agents (null = all)
    
    # Action Configuration
    action = Column(SQLEnum(SafetyAction), default=SafetyAction.BLOCK)
    action_message = Column(Text, nullable=True)  # Message to show user
    action_redirect_agent = Column(UUID(as_uuid=True), nullable=True)  # For redirect action
    modification_script = Column(Text, nullable=True)  # For modify action
    
    # Rate Limiting (for rate_limit type)
    rate_limit_count = Column(Integer, nullable=True)  # Max requests
    rate_limit_window = Column(Integer, nullable=True)  # Time window in seconds
    
    # Length Limiting (for length_limit type)
    max_input_length = Column(Integer, nullable=True)
    max_output_length = Column(Integer, nullable=True)
    
    # Language Settings (for language type)
    allowed_languages = Column(JSON, nullable=True)  # ['zh', 'en']
    
    # Logging & Analytics
    log_matches = Column(Boolean, default=True)
    alert_on_match = Column(Boolean, default=False)  # Send alert to admin
    
    # Metadata
    category = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(UUID(as_uuid=True), nullable=True)

    def to_dict(self):
        return {
            "id": str(self.id),
            "name": self.name,
            "display_name": self.display_name,
            "description": self.description,
            "rule_type": self.rule_type.value,
            "status": self.status.value,
            "priority": self.priority,
            "is_system": self.is_system,
            "match_patterns": self.match_patterns,
            "match_keywords": self.match_keywords,
            "match_embeddings": self.match_embeddings,
            "embedding_threshold": self.embedding_threshold,
            "match_script": self.match_script,
            "apply_to_input": self.apply_to_input,
            "apply_to_output": self.apply_to_output,
            "agent_ids": self.agent_ids,
            "action": self.action.value,
            "action_message": self.action_message,
            "action_redirect_agent": str(self.action_redirect_agent) if self.action_redirect_agent else None,
            "modification_script": self.modification_script,
            "rate_limit_count": self.rate_limit_count,
            "rate_limit_window": self.rate_limit_window,
            "max_input_length": self.max_input_length,
            "max_output_length": self.max_output_length,
            "allowed_languages": self.allowed_languages,
            "log_matches": self.log_matches,
            "alert_on_match": self.alert_on_match,
            "category": self.category,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class SafetyLog(Base):
    """
    Log of safety rule matches for analytics and auditing.
    """
    __tablename__ = "safety_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # Rule that matched
    rule_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    rule_name = Column(String(100), nullable=True)  # Denormalized for quick access
    
    # Context
    user_id = Column(UUID(as_uuid=True), nullable=True, index=True)
    session_id = Column(String(100), nullable=True)
    agent_id = Column(UUID(as_uuid=True), nullable=True)
    
    # Content (may be truncated for privacy)
    input_preview = Column(Text, nullable=True)  # First 500 chars
    matched_content = Column(Text, nullable=True)  # What triggered the rule
    
    # Action Taken
    action_taken = Column(String(50), nullable=False)
    was_blocked = Column(Boolean, default=False)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    ip_address = Column(String(50), nullable=True)
    user_agent = Column(String(500), nullable=True)

    def to_dict(self):
        return {
            "id": str(self.id),
            "rule_id": str(self.rule_id),
            "rule_name": self.rule_name,
            "user_id": str(self.user_id) if self.user_id else None,
            "session_id": self.session_id,
            "agent_id": str(self.agent_id) if self.agent_id else None,
            "input_preview": self.input_preview,
            "matched_content": self.matched_content,
            "action_taken": self.action_taken,
            "was_blocked": self.was_blocked,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
