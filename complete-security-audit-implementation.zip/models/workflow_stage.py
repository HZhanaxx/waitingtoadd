"""
Workflow Stage Model
====================

Database model for dynamic workflow stages/phases.
This replaces the hardcoded WorkflowStage enum, allowing admins
to define new stages without code deployment.

Stages represent phases in the case workflow pipeline:
- Triage (分诊)
- Professional/Domain (专业)
- Search (搜索)
- Analysis (分析)
- Generation (生成)
- Custom stages...
"""
import uuid
from datetime import datetime
from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, JSON
from sqlalchemy.dialects.postgresql import UUID
from database import Base


class WorkflowStage(Base):
    """
    Workflow stage definition.
    
    Represents a phase in the multi-agent workflow pipeline.
    Stages can be dynamically added by admins without code changes.
    """
    __tablename__ = "workflow_stages"

    # Primary Key
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # Basic Info
    name = Column(String(50), nullable=False, unique=True, index=True)  # e.g., "triage", "analysis"
    display_name = Column(String(100), nullable=False)  # e.g., "分诊", "分析"
    description = Column(Text, nullable=True)
    
    # UI Configuration
    icon = Column(String(50), nullable=True)  # Emoji or icon class, e.g., "🎯"
    color = Column(String(50), nullable=True)  # CSS color for UI, e.g., "#3B82F6"
    
    # Order & Status
    sort_order = Column(Integer, default=0, index=True)
    is_active = Column(Boolean, default=True)
    is_system = Column(Boolean, default=False)  # System stages cannot be deleted
    
    # Stage Configuration
    agent_type_filter = Column(String(50), nullable=True)  # Which agent types belong to this stage
    allowed_transitions = Column(JSON, nullable=True)  # List of stage names this can transition to
    auto_advance = Column(Boolean, default=False)  # Automatically advance when all agents complete
    
    # Behavior Configuration
    requires_all_agents = Column(Boolean, default=False)  # Must complete all agents in stage
    max_agents = Column(Integer, nullable=True)  # Maximum agents allowed in this stage
    timeout_seconds = Column(Integer, nullable=True)  # Timeout for stage completion
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(UUID(as_uuid=True), nullable=True)

    def __repr__(self):
        return f"<WorkflowStage {self.name} ({self.display_name})>"

    def to_dict(self):
        """Convert to dictionary for API responses"""
        return {
            "id": str(self.id),
            "name": self.name,
            "display_name": self.display_name,
            "description": self.description,
            "icon": self.icon,
            "color": self.color,
            "sort_order": self.sort_order,
            "is_active": self.is_active,
            "is_system": self.is_system,
            "agent_type_filter": self.agent_type_filter,
            "allowed_transitions": self.allowed_transitions,
            "auto_advance": self.auto_advance,
            "requires_all_agents": self.requires_all_agents,
            "max_agents": self.max_agents,
            "timeout_seconds": self.timeout_seconds,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
    
    def to_simple_dict(self):
        """Simplified dict for frontend pipeline display"""
        return {
            "key": self.name,
            "name": self.display_name,
            "icon": self.icon or "📋",
            "color": self.color,
            "agent_type": self.agent_type_filter,
        }


class AgentType(Base):
    """
    Dynamic agent type definition.
    
    Replaces the static AgentType enum, allowing admins to define
    new agent types without code deployment.
    """
    __tablename__ = "agent_types"

    # Primary Key
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # Basic Info
    name = Column(String(50), nullable=False, unique=True, index=True)  # e.g., "triage", "domain"
    display_name = Column(String(100), nullable=False)  # e.g., "分诊Agent"
    description = Column(Text, nullable=True)
    
    # UI Configuration
    icon = Column(String(50), nullable=True)
    color = Column(String(50), nullable=True)
    
    # Stage Association
    default_stage = Column(String(50), nullable=True)  # Which stage this type belongs to
    
    # Order & Status
    sort_order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    is_system = Column(Boolean, default=False)  # System types cannot be deleted
    
    # Capabilities
    capabilities = Column(JSON, nullable=True)  # List of capability strings
    default_config = Column(JSON, nullable=True)  # Default configuration for new agents
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"<AgentType {self.name} ({self.display_name})>"

    def to_dict(self):
        """Convert to dictionary for API responses"""
        return {
            "id": str(self.id),
            "name": self.name,
            "value": self.name,  # For compatibility with existing frontend
            "display_name": self.display_name,
            "label": self.display_name,  # For compatibility with existing frontend
            "description": self.description,
            "icon": self.icon,
            "color": self.color,
            "default_stage": self.default_stage,
            "sort_order": self.sort_order,
            "is_active": self.is_active,
            "is_system": self.is_system,
            "capabilities": self.capabilities,
            "default_config": self.default_config,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


# ==================== Default Data ====================

DEFAULT_WORKFLOW_STAGES = [
    {
        "name": "triage",
        "display_name": "分诊",
        "description": "初始问诊和意图识别阶段",
        "icon": "🎯",
        "color": "#3B82F6",
        "sort_order": 1,
        "is_system": True,
        "agent_type_filter": "triage",
        "allowed_transitions": ["professional", "search"],
    },
    {
        "name": "professional",
        "display_name": "专业",
        "description": "专业领域数据收集阶段",
        "icon": "👨‍💼",
        "color": "#10B981",
        "sort_order": 2,
        "is_system": True,
        "agent_type_filter": "domain",
        "allowed_transitions": ["search", "analysis"],
    },
    {
        "name": "search",
        "display_name": "搜索",
        "description": "法条和案例检索阶段",
        "icon": "🔍",
        "color": "#F59E0B",
        "sort_order": 3,
        "is_system": True,
        "agent_type_filter": "search",
        "allowed_transitions": ["analysis"],
    },
    {
        "name": "analysis",
        "display_name": "分析",
        "description": "数据分析和推荐阶段",
        "icon": "📊",
        "color": "#8B5CF6",
        "sort_order": 4,
        "is_system": True,
        "agent_type_filter": "analyzer",
        "allowed_transitions": ["generation", "review"],
    },
    {
        "name": "generation",
        "display_name": "生成",
        "description": "文档和报告生成阶段",
        "icon": "📝",
        "color": "#EC4899",
        "sort_order": 5,
        "is_system": True,
        "agent_type_filter": "generation",
        "allowed_transitions": ["review", "completed"],
    },
    {
        "name": "review",
        "display_name": "审核",
        "description": "专业人员审核阶段",
        "icon": "✅",
        "color": "#06B6D4",
        "sort_order": 6,
        "is_system": True,
        "agent_type_filter": "review",
        "allowed_transitions": ["completed"],
    },
]

DEFAULT_AGENT_TYPES = [
    {
        "name": "triage",
        "display_name": "分诊Agent",
        "description": "初始问诊和意图识别",
        "icon": "🎯",
        "default_stage": "triage",
        "sort_order": 1,
        "is_system": True,
        "capabilities": ["greeting", "intent_classification", "routing"],
    },
    {
        "name": "domain",
        "display_name": "专业Agent",
        "description": "领域特定变量收集",
        "icon": "👨‍💼",
        "default_stage": "professional",
        "sort_order": 2,
        "is_system": True,
        "capabilities": ["data_collection", "validation", "domain_knowledge"],
    },
    {
        "name": "fetch",
        "display_name": "获取Agent",
        "description": "对话获取和信息提取",
        "icon": "💬",
        "default_stage": "professional",
        "sort_order": 3,
        "is_system": True,
        "capabilities": ["conversation", "extraction", "clarification"],
    },
    {
        "name": "search",
        "display_name": "搜索Agent",
        "description": "法条和案例检索",
        "icon": "🔍",
        "default_stage": "search",
        "sort_order": 4,
        "is_system": True,
        "capabilities": ["law_search", "case_search", "rag"],
    },
    {
        "name": "analyzer",
        "display_name": "分析Agent",
        "description": "数据分析和推荐",
        "icon": "📊",
        "default_stage": "analysis",
        "sort_order": 5,
        "is_system": True,
        "capabilities": ["analysis", "recommendation", "risk_assessment"],
    },
    {
        "name": "generation",
        "display_name": "生成Agent",
        "description": "文档和报告生成",
        "icon": "📝",
        "default_stage": "generation",
        "sort_order": 6,
        "is_system": True,
        "capabilities": ["document_generation", "template_filling", "formatting"],
    },
    {
        "name": "custom",
        "display_name": "自定义Agent",
        "description": "自定义功能Agent",
        "icon": "⚙️",
        "default_stage": None,
        "sort_order": 99,
        "is_system": True,
        "capabilities": [],
    },
]
