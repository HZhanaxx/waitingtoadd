"""
Agent Model
===========

Database model for AI Agent definitions in the multi-agent workflow system.
Each agent represents a node in the conversation flow with specific responsibilities.

Agent Types:
- triage: Initial greeting and intent classification (分诊Agent)
- domain: Domain-specific variable collection (专业Agent)  
- search: Law code and case retrieval (搜索Agent)
- analyzer: Data analysis and recommendation (分析Agent)
- custom: User-defined custom agents
"""
import uuid
from datetime import datetime
from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, JSON, Enum as SQLEnum, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from database import Base
import enum


class AgentType(str, enum.Enum):
    """
    Agent type enumeration.
    
    Note: This enum is maintained for backward compatibility.
    New agent types should be added to the agent_types database table
    for dynamic configuration. Use the /api/workflow-stages/agent-types
    endpoint to manage types dynamically.
    """
    TRIAGE = "triage"        # 分诊Agent - Initial intake and routing
    DOMAIN = "domain"        # 专业Agent - Domain-specific Q&A
    FETCH = "fetch"          # 获取Agent - Conversation fetching & extraction
    SEARCH = "search"        # 搜索Agent - Law/case retrieval
    ANALYZER = "analyzer"    # 分析Agent - Data analysis
    GENERATION = "generation" # 生成Agent - Document generation
    CUSTOM = "custom"        # Custom agent type


class AgentStatus(str, enum.Enum):
    """Agent status enumeration"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    DRAFT = "draft"
    ARCHIVED = "archived"


class Agent(Base):
    """
    Agent definition model.
    
    Stores the configuration for each agent in the multi-agent workflow,
    including prompts, routing logic, and tool bindings.
    """
    __tablename__ = "agents"

    # Primary Key
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # Basic Info
    name = Column(String(100), nullable=False, index=True)
    display_name = Column(String(200), nullable=False)  # 显示名称
    description = Column(Text, nullable=True)
    agent_type = Column(SQLEnum(AgentType), nullable=False, default=AgentType.CUSTOM)
    
    # Status & Order
    status = Column(SQLEnum(AgentStatus), nullable=False, default=AgentStatus.DRAFT)
    sort_order = Column(Integer, default=0)  # Order in the workflow
    is_entry_point = Column(Boolean, default=False)  # Is this the first agent?
    
    # System Prompt Configuration
    system_prompt = Column(Text, nullable=True)  # Main system prompt
    greeting_message = Column(Text, nullable=True)  # Initial greeting to user
    
    # Question Generation Settings (for domain agents)
    question_generation_prompt = Column(Text, nullable=True)  # Prompt for generating questions
    question_list = Column(JSON, nullable=True)  # Predefined question list [{id, text, variable_id, type}]
    
    # Routing Configuration
    routing_prompt = Column(Text, nullable=True)  # Prompt for deciding next agent
    routing_options = Column(JSON, nullable=True)  # [{value, label, target_agent_id, description}]
    default_next_agent_id = Column(UUID(as_uuid=True), nullable=True)  # Default next agent
    
    # Context Settings
    context_window_size = Column(Integer, default=10)  # Number of messages to include
    include_summaries = Column(Boolean, default=True)  # Include previous agent summaries
    context_sources = Column(JSON, nullable=True)  # Which data sources to include
    
    # Safety & Validation
    avoid_commands = Column(JSON, nullable=True)  # Commands to avoid/block
    input_validation_rules = Column(JSON, nullable=True)  # Input validation patterns
    max_turns = Column(Integer, default=50)  # Maximum conversation turns
    
    # LLM Settings
    model_name = Column(String(100), default="default")  # LLM model to use
    temperature = Column(Integer, default=70)  # Temperature * 100 (0.7 = 70)
    max_tokens = Column(Integer, default=2048)
    
    # Tool Configuration (stored as JSON, linked via agent_tools table)
    enabled_tools = Column(JSON, nullable=True)  # List of tool IDs
    tool_config = Column(JSON, nullable=True)  # Tool-specific configurations
    
    # RAG/Search Configuration
    rag_enabled = Column(Boolean, default=False)
    rag_collection = Column(String(100), nullable=True)  # Vector store collection
    es_enabled = Column(Boolean, default=False)
    es_index = Column(String(100), nullable=True)  # Elasticsearch index
    search_config = Column(JSON, nullable=True)  # Search parameters
    
    # Output Configuration
    output_format = Column(String(50), default="text")  # text, json, markdown
    summary_prompt = Column(Text, nullable=True)  # Prompt for generating summary
    handoff_message = Column(Text, nullable=True)  # Message when handing off to next agent
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(UUID(as_uuid=True), nullable=True)
    
    # Version Control
    version = Column(Integer, default=1)
    parent_version_id = Column(UUID(as_uuid=True), nullable=True)  # For version history
    
    # Relationships
    variables = relationship("AgentVariable", back_populates="agent", cascade="all, delete-orphan")
    tools = relationship("AgentTool", back_populates="agent", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Agent {self.name} ({self.agent_type.value})>"

    def to_dict(self):
        """Convert to dictionary for API responses"""
        return {
            "id": str(self.id),
            "name": self.name,
            "display_name": self.display_name,
            "description": self.description,
            "agent_type": self.agent_type.value,
            "status": self.status.value,
            "sort_order": self.sort_order,
            "is_entry_point": self.is_entry_point,
            "system_prompt": self.system_prompt,
            "greeting_message": self.greeting_message,
            "question_generation_prompt": self.question_generation_prompt,
            "question_list": self.question_list,
            "routing_prompt": self.routing_prompt,
            "routing_options": self.routing_options,
            "default_next_agent_id": str(self.default_next_agent_id) if self.default_next_agent_id else None,
            "context_window_size": self.context_window_size,
            "include_summaries": self.include_summaries,
            "context_sources": self.context_sources,
            "avoid_commands": self.avoid_commands,
            "input_validation_rules": self.input_validation_rules,
            "max_turns": self.max_turns,
            "model_name": self.model_name,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "enabled_tools": self.enabled_tools,
            "tool_config": self.tool_config,
            "rag_enabled": self.rag_enabled,
            "rag_collection": self.rag_collection,
            "es_enabled": self.es_enabled,
            "es_index": self.es_index,
            "search_config": self.search_config,
            "output_format": self.output_format,
            "summary_prompt": self.summary_prompt,
            "handoff_message": self.handoff_message,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "version": self.version,
        }


class AgentConnection(Base):
    """
    Agent connection model - defines edges between agents in the workflow graph.
    """
    __tablename__ = "agent_connections"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # Source and Target Agents
    source_agent_id = Column(UUID(as_uuid=True), ForeignKey("agents.id", ondelete="CASCADE"), nullable=False)
    target_agent_id = Column(UUID(as_uuid=True), ForeignKey("agents.id", ondelete="CASCADE"), nullable=False)
    
    # Connection Configuration
    condition_type = Column(String(50), default="always")  # always, conditional, user_choice
    condition_expression = Column(Text, nullable=True)  # Python expression or JSON condition
    condition_label = Column(String(200), nullable=True)  # Display label for the connection
    
    # Priority (for multiple connections from same source)
    priority = Column(Integer, default=0)
    
    # Data passing
    pass_context = Column(Boolean, default=True)
    pass_variables = Column(JSON, nullable=True)  # List of variable names to pass
    transform_script = Column(Text, nullable=True)  # Optional data transformation
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "id": str(self.id),
            "source_agent_id": str(self.source_agent_id),
            "target_agent_id": str(self.target_agent_id),
            "condition_type": self.condition_type,
            "condition_expression": self.condition_expression,
            "condition_label": self.condition_label,
            "priority": self.priority,
            "pass_context": self.pass_context,
            "pass_variables": self.pass_variables,
            "transform_script": self.transform_script,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }
