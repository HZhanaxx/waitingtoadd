"""
Agent Management Router
=======================

API endpoints for managing AI agents, tools, variables, and safety rules.
Admin-only endpoints for the Agent Studio.
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional, List
from uuid import UUID
from pydantic import BaseModel
import json

from database import get_db
from utils.auth import get_current_user
from routers.admin import require_admin
from models.user import User
from models.agent import Agent, AgentConnection, AgentType, AgentStatus
from models.agent_tool import Tool, AgentTool, ToolType, ToolStatus
from models.agent_variable import AgentVariable, AgentVariableGroup
from models.safety_rule import SafetyRule, SafetyLog, SafetyRuleType, SafetyAction, SafetyRuleStatus
from models.mother_point import MotherPoint, AgentMotherPoint, MotherPointResponse as MotherPointResponseModel, MotherPointStatus

from schemas.agent_management import (
    AgentCreate, AgentUpdate, AgentResponse, AgentListResponse,
    AgentConnectionCreate, AgentConnectionUpdate, AgentConnectionResponse,
    ToolCreate, ToolUpdate, ToolResponse, ToolListResponse,
    AgentToolAssignment, AgentToolResponse,
    AgentVariableCreate, AgentVariableUpdate, AgentVariableResponse,
    VariableGroupCreate, VariableGroupUpdate, VariableGroupResponse, VariableGroupListResponse,
    SafetyRuleCreate, SafetyRuleUpdate, SafetyRuleResponse, SafetyRuleListResponse,
    SafetyLogResponse, SafetyLogListResponse,
    WorkflowGraph, WorkflowValidation,
    TestScriptRequest, TestScriptResponse,
    # Mother Point schemas
    MotherPointCreate, MotherPointUpdate, MotherPointResponse, MotherPointListResponse,
    AgentMotherPointAssignment, AgentMotherPointResponse,
    MotherPointUserResponseCreate, MotherPointUserResponseResponse,
    GenerateQuestionRequest, GenerateQuestionResponse,
    ExtractAnswerRequest, ExtractAnswerResponse
)

router = APIRouter(prefix="/api/agent-management", tags=["Agent Management"])


# ==================== AGENT ENDPOINTS ====================

@router.get("/agents", response_model=AgentListResponse)
async def list_agents(
    status: Optional[str] = Query(None, description="Filter by status"),
    agent_type: Optional[str] = Query(None, description="Filter by type"),
    search: Optional[str] = Query(None, description="Search in name/description"),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """List all agents with optional filtering"""
    query = db.query(Agent)
    
    if status:
        query = query.filter(Agent.status == status)
    if agent_type:
        query = query.filter(Agent.agent_type == agent_type)
    if search:
        search_pattern = f"%{search}%"
        query = query.filter(
            (Agent.name.ilike(search_pattern)) | 
            (Agent.display_name.ilike(search_pattern)) |
            (Agent.description.ilike(search_pattern))
        )
    
    agents = query.order_by(Agent.sort_order, Agent.created_at.desc()).all()
    
    return AgentListResponse(
        agents=[AgentResponse(**a.to_dict()) for a in agents],
        total=len(agents)
    )


@router.post("/agents", response_model=AgentResponse)
async def create_agent(
    agent_data: AgentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Create a new agent"""
    # Check for duplicate name
    existing = db.query(Agent).filter(Agent.name == agent_data.name).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"Agent with name '{agent_data.name}' already exists")
    
    # If this is entry point, unset any existing entry points
    if agent_data.is_entry_point:
        db.query(Agent).filter(Agent.is_entry_point == True).update({"is_entry_point": False})
    
    agent = Agent(
        **agent_data.model_dump(exclude_unset=True),
        created_by=current_user.user_uuid
    )
    
    db.add(agent)
    db.commit()
    db.refresh(agent)
    
    return AgentResponse(**agent.to_dict())


@router.get("/agents/{agent_id}", response_model=AgentResponse)
async def get_agent(
    agent_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Get agent by ID with full details"""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    response_data = agent.to_dict()
    
    # Include variables
    variables = db.query(AgentVariable).filter(AgentVariable.agent_id == agent_id).order_by(AgentVariable.sort_order).all()
    response_data["variables"] = [v.to_dict() for v in variables]
    
    # Include tools
    agent_tools = db.query(AgentTool).filter(AgentTool.agent_id == agent_id).all()
    response_data["tools"] = [at.to_dict() for at in agent_tools]
    
    return AgentResponse(**response_data)


@router.put("/agents/{agent_id}", response_model=AgentResponse)
async def update_agent(
    agent_id: UUID,
    agent_data: AgentUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Update an agent"""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    # Check for duplicate name
    if agent_data.name and agent_data.name != agent.name:
        existing = db.query(Agent).filter(Agent.name == agent_data.name).first()
        if existing:
            raise HTTPException(status_code=400, detail=f"Agent with name '{agent_data.name}' already exists")
    
    # Handle entry point change
    if agent_data.is_entry_point and not agent.is_entry_point:
        db.query(Agent).filter(Agent.is_entry_point == True).update({"is_entry_point": False})
    
    # Update fields
    update_data = agent_data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(agent, key, value)
    
    # Increment version
    agent.version += 1
    
    db.commit()
    db.refresh(agent)
    
    return AgentResponse(**agent.to_dict())


@router.delete("/agents/{agent_id}")
async def delete_agent(
    agent_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Delete an agent"""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    db.delete(agent)
    db.commit()
    
    return {"message": "Agent deleted successfully"}


@router.post("/agents/{agent_id}/duplicate", response_model=AgentResponse)
async def duplicate_agent(
    agent_id: UUID,
    new_name: str = Query(..., description="Name for the duplicated agent"),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Duplicate an existing agent"""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    # Check for duplicate name
    existing = db.query(Agent).filter(Agent.name == new_name).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"Agent with name '{new_name}' already exists")
    
    # Create copy
    agent_dict = agent.to_dict()
    del agent_dict["id"]
    del agent_dict["created_at"]
    del agent_dict["updated_at"]
    
    new_agent = Agent(
        **{k: v for k, v in agent_dict.items() if k not in ["variables", "tools"]},
        name=new_name,
        display_name=f"{agent.display_name} (副本)",
        status=AgentStatus.DRAFT,
        is_entry_point=False,
        version=1,
        parent_version_id=agent.id,
        created_by=current_user.user_uuid
    )
    
    db.add(new_agent)
    db.commit()
    db.refresh(new_agent)
    
    return AgentResponse(**new_agent.to_dict())


# ==================== AGENT CONNECTION ENDPOINTS ====================

@router.get("/connections", response_model=List[AgentConnectionResponse])
async def list_connections(
    source_agent_id: Optional[UUID] = None,
    target_agent_id: Optional[UUID] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """List agent connections"""
    query = db.query(AgentConnection)
    
    if source_agent_id:
        query = query.filter(AgentConnection.source_agent_id == source_agent_id)
    if target_agent_id:
        query = query.filter(AgentConnection.target_agent_id == target_agent_id)
    
    connections = query.order_by(AgentConnection.priority.desc()).all()
    
    return [AgentConnectionResponse(**c.to_dict()) for c in connections]


@router.post("/connections", response_model=AgentConnectionResponse)
async def create_connection(
    connection_data: AgentConnectionCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Create a connection between agents"""
    # Verify both agents exist
    source = db.query(Agent).filter(Agent.id == connection_data.source_agent_id).first()
    target = db.query(Agent).filter(Agent.id == connection_data.target_agent_id).first()
    
    if not source or not target:
        raise HTTPException(status_code=404, detail="Source or target agent not found")
    
    # Prevent self-loops (optional, depending on your design)
    if connection_data.source_agent_id == connection_data.target_agent_id:
        raise HTTPException(status_code=400, detail="Cannot create self-referencing connection")
    
    connection = AgentConnection(**connection_data.model_dump())
    
    db.add(connection)
    db.commit()
    db.refresh(connection)
    
    return AgentConnectionResponse(**connection.to_dict())


@router.put("/connections/{connection_id}", response_model=AgentConnectionResponse)
async def update_connection(
    connection_id: UUID,
    connection_data: AgentConnectionUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Update a connection"""
    connection = db.query(AgentConnection).filter(AgentConnection.id == connection_id).first()
    if not connection:
        raise HTTPException(status_code=404, detail="Connection not found")
    
    update_data = connection_data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(connection, key, value)
    
    db.commit()
    db.refresh(connection)
    
    return AgentConnectionResponse(**connection.to_dict())


@router.delete("/connections/{connection_id}")
async def delete_connection(
    connection_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Delete a connection"""
    connection = db.query(AgentConnection).filter(AgentConnection.id == connection_id).first()
    if not connection:
        raise HTTPException(status_code=404, detail="Connection not found")
    
    db.delete(connection)
    db.commit()
    
    return {"message": "Connection deleted successfully"}


# ==================== TOOL ENDPOINTS ====================

@router.get("/tools", response_model=ToolListResponse)
async def list_tools(
    tool_type: Optional[str] = None,
    category: Optional[str] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """List all available tools"""
    try:
        query = db.query(Tool)
        
        if tool_type:
            query = query.filter(Tool.tool_type == tool_type)
        if category:
            query = query.filter(Tool.category == category)
        if status:
            query = query.filter(Tool.status == status)
        
        tools = query.order_by(Tool.category, Tool.display_name).all()
        
        return ToolListResponse(
            tools=[ToolResponse(**t.to_dict()) for t in tools],
            total=len(tools)
        )
    except Exception as e:
        # Return empty list if there's a database schema mismatch
        print(f"Error loading tools: {e}")
        return ToolListResponse(tools=[], total=0)


@router.post("/tools", response_model=ToolResponse)
async def create_tool(
    tool_data: ToolCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Create a new tool"""
    existing = db.query(Tool).filter(Tool.name == tool_data.name).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"Tool with name '{tool_data.name}' already exists")
    
    tool = Tool(
        **tool_data.model_dump(),
        created_by=current_user.user_uuid
    )
    
    db.add(tool)
    db.commit()
    db.refresh(tool)
    
    return ToolResponse(**tool.to_dict())


@router.get("/tools/{tool_id}", response_model=ToolResponse)
async def get_tool(
    tool_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Get tool by ID"""
    tool = db.query(Tool).filter(Tool.id == tool_id).first()
    if not tool:
        raise HTTPException(status_code=404, detail="Tool not found")
    
    return ToolResponse(**tool.to_dict())


@router.put("/tools/{tool_id}", response_model=ToolResponse)
async def update_tool(
    tool_id: UUID,
    tool_data: ToolUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Update a tool"""
    tool = db.query(Tool).filter(Tool.id == tool_id).first()
    if not tool:
        raise HTTPException(status_code=404, detail="Tool not found")
    
    if tool.is_system:
        raise HTTPException(status_code=403, detail="Cannot modify system tools")
    
    if tool_data.name and tool_data.name != tool.name:
        existing = db.query(Tool).filter(Tool.name == tool_data.name).first()
        if existing:
            raise HTTPException(status_code=400, detail=f"Tool with name '{tool_data.name}' already exists")
    
    update_data = tool_data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(tool, key, value)
    
    db.commit()
    db.refresh(tool)
    
    return ToolResponse(**tool.to_dict())


@router.delete("/tools/{tool_id}")
async def delete_tool(
    tool_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Delete a tool"""
    tool = db.query(Tool).filter(Tool.id == tool_id).first()
    if not tool:
        raise HTTPException(status_code=404, detail="Tool not found")
    
    if tool.is_system:
        raise HTTPException(status_code=403, detail="Cannot delete system tools")
    
    db.delete(tool)
    db.commit()
    
    return {"message": "Tool deleted successfully"}


# ==================== AGENT TOOL ASSIGNMENT ENDPOINTS ====================

@router.get("/agents/{agent_id}/tools", response_model=List[AgentToolResponse])
async def get_agent_tools(
    agent_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Get tools assigned to an agent"""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    agent_tools = db.query(AgentTool).filter(AgentTool.agent_id == agent_id).order_by(AgentTool.priority.desc()).all()
    
    return [AgentToolResponse(**at.to_dict()) for at in agent_tools]


@router.post("/agents/{agent_id}/tools", response_model=AgentToolResponse)
async def assign_tool_to_agent(
    agent_id: UUID,
    assignment: AgentToolAssignment,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Assign a tool to an agent"""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    tool = db.query(Tool).filter(Tool.id == assignment.tool_id).first()
    if not tool:
        raise HTTPException(status_code=404, detail="Tool not found")
    
    # Check if already assigned
    existing = db.query(AgentTool).filter(
        AgentTool.agent_id == agent_id,
        AgentTool.tool_id == assignment.tool_id
    ).first()
    
    if existing:
        raise HTTPException(status_code=400, detail="Tool already assigned to this agent")
    
    agent_tool = AgentTool(
        agent_id=agent_id,
        **assignment.model_dump()
    )
    
    db.add(agent_tool)
    db.commit()
    db.refresh(agent_tool)
    
    return AgentToolResponse(**agent_tool.to_dict())


@router.delete("/agents/{agent_id}/tools/{tool_id}")
async def remove_tool_from_agent(
    agent_id: UUID,
    tool_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Remove a tool from an agent"""
    agent_tool = db.query(AgentTool).filter(
        AgentTool.agent_id == agent_id,
        AgentTool.tool_id == tool_id
    ).first()
    
    if not agent_tool:
        raise HTTPException(status_code=404, detail="Tool assignment not found")
    
    db.delete(agent_tool)
    db.commit()
    
    return {"message": "Tool removed from agent successfully"}


# ==================== AGENT VARIABLE ENDPOINTS ====================

@router.get("/agents/{agent_id}/variables", response_model=List[AgentVariableResponse])
async def get_agent_variables(
    agent_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Get variables assigned to an agent with platform variable details"""
    from models.platform_variable import PlatformVariable
    
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    variables = db.query(AgentVariable).filter(
        AgentVariable.agent_id == agent_id
    ).order_by(AgentVariable.sort_order).all()
    
    # Enhance with platform variable details
    result = []
    for v in variables:
        data = v.to_dict()
        # Get platform variable info
        pvar = db.query(PlatformVariable).filter(PlatformVariable.variable_id == v.variable_id).first()
        if pvar:
            data['variable'] = pvar.to_dict()
        result.append(AgentVariableResponse(**data))
    
    return result


@router.post("/agents/{agent_id}/variables", response_model=AgentVariableResponse)
async def add_variable_to_agent(
    agent_id: UUID,
    variable_data: AgentVariableCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Add a variable to an agent"""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    # Check if already assigned
    existing = db.query(AgentVariable).filter(
        AgentVariable.agent_id == agent_id,
        AgentVariable.variable_id == variable_data.variable_id
    ).first()
    
    if existing:
        raise HTTPException(status_code=400, detail="Variable already assigned to this agent")
    
    agent_var = AgentVariable(
        agent_id=agent_id,
        **variable_data.model_dump()
    )
    
    db.add(agent_var)
    db.commit()
    db.refresh(agent_var)
    
    return AgentVariableResponse(**agent_var.to_dict())


@router.put("/agents/{agent_id}/variables/{variable_id}", response_model=AgentVariableResponse)
async def update_agent_variable(
    agent_id: UUID,
    variable_id: UUID,
    variable_data: AgentVariableUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Update an agent's variable configuration"""
    agent_var = db.query(AgentVariable).filter(
        AgentVariable.agent_id == agent_id,
        AgentVariable.variable_id == variable_id
    ).first()
    
    if not agent_var:
        raise HTTPException(status_code=404, detail="Variable assignment not found")
    
    update_data = variable_data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(agent_var, key, value)
    
    db.commit()
    db.refresh(agent_var)
    
    return AgentVariableResponse(**agent_var.to_dict())


@router.delete("/agents/{agent_id}/variables/{variable_id}")
async def remove_variable_from_agent(
    agent_id: UUID,
    variable_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Remove a variable from an agent"""
    agent_var = db.query(AgentVariable).filter(
        AgentVariable.agent_id == agent_id,
        AgentVariable.variable_id == variable_id
    ).first()
    
    if not agent_var:
        raise HTTPException(status_code=404, detail="Variable assignment not found")
    
    db.delete(agent_var)
    db.commit()
    
    return {"message": "Variable removed from agent successfully"}


@router.put("/agents/{agent_id}/variables/reorder")
async def reorder_agent_variables(
    agent_id: UUID,
    variable_ids: List[UUID],
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Reorder variables within an agent"""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    for order, var_id in enumerate(variable_ids):
        db.query(AgentVariable).filter(
            AgentVariable.agent_id == agent_id,
            AgentVariable.variable_id == var_id
        ).update({"sort_order": order})
    
    db.commit()
    
    return {"message": "Variables reordered successfully"}


# ==================== VARIABLE GROUP ENDPOINTS ====================

@router.get("/agents/{agent_id}/variable-groups", response_model=VariableGroupListResponse)
async def list_variable_groups(
    agent_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """List all variable groups for an agent"""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    groups = db.query(AgentVariableGroup).filter(
        AgentVariableGroup.agent_id == agent_id
    ).order_by(AgentVariableGroup.sort_order).all()
    
    # Include variables for each group
    result_groups = []
    for group in groups:
        group_dict = group.to_dict()
        if group.variable_ids:
            # Fetch variables in this group
            variables = db.query(AgentVariable).filter(
                AgentVariable.agent_id == agent_id,
                AgentVariable.variable_id.in_(group.variable_ids)
            ).all()
            group_dict["variables"] = [v.to_dict() for v in variables]
        else:
            group_dict["variables"] = []
        result_groups.append(VariableGroupResponse(**group_dict))
    
    return VariableGroupListResponse(groups=result_groups, total=len(result_groups))


@router.post("/agents/{agent_id}/variable-groups", response_model=VariableGroupResponse)
async def create_variable_group(
    agent_id: UUID,
    group_data: VariableGroupCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Create a new variable group for an agent"""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    # Check for duplicate name within agent
    existing = db.query(AgentVariableGroup).filter(
        AgentVariableGroup.agent_id == agent_id,
        AgentVariableGroup.name == group_data.name
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"Group with name '{group_data.name}' already exists for this agent")
    
    # Convert UUID list to strings for JSON storage
    variable_ids_str = None
    if group_data.variable_ids:
        variable_ids_str = [str(vid) for vid in group_data.variable_ids]
    
    group = AgentVariableGroup(
        agent_id=agent_id,
        name=group_data.name,
        display_name=group_data.display_name,
        description=group_data.description,
        sort_order=group_data.sort_order,
        is_collapsible=group_data.is_collapsible,
        is_collapsed_by_default=group_data.is_collapsed_by_default,
        summary_prompt=group_data.summary_prompt,
        variable_ids=variable_ids_str
    )
    
    db.add(group)
    db.commit()
    db.refresh(group)
    
    return VariableGroupResponse(**group.to_dict())


@router.get("/agents/{agent_id}/variable-groups/{group_id}", response_model=VariableGroupResponse)
async def get_variable_group(
    agent_id: UUID,
    group_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Get a variable group by ID"""
    group = db.query(AgentVariableGroup).filter(
        AgentVariableGroup.id == group_id,
        AgentVariableGroup.agent_id == agent_id
    ).first()
    
    if not group:
        raise HTTPException(status_code=404, detail="Variable group not found")
    
    group_dict = group.to_dict()
    if group.variable_ids:
        variables = db.query(AgentVariable).filter(
            AgentVariable.agent_id == agent_id,
            AgentVariable.variable_id.in_(group.variable_ids)
        ).all()
        group_dict["variables"] = [v.to_dict() for v in variables]
    else:
        group_dict["variables"] = []
    
    return VariableGroupResponse(**group_dict)


@router.put("/agents/{agent_id}/variable-groups/{group_id}", response_model=VariableGroupResponse)
async def update_variable_group(
    agent_id: UUID,
    group_id: UUID,
    group_data: VariableGroupUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Update a variable group"""
    group = db.query(AgentVariableGroup).filter(
        AgentVariableGroup.id == group_id,
        AgentVariableGroup.agent_id == agent_id
    ).first()
    
    if not group:
        raise HTTPException(status_code=404, detail="Variable group not found")
    
    update_data = group_data.model_dump(exclude_unset=True)
    
    # Convert UUID list to strings for JSON storage
    if "variable_ids" in update_data and update_data["variable_ids"]:
        update_data["variable_ids"] = [str(vid) for vid in update_data["variable_ids"]]
    
    for key, value in update_data.items():
        setattr(group, key, value)
    
    db.commit()
    db.refresh(group)
    
    group_dict = group.to_dict()
    if group.variable_ids:
        variables = db.query(AgentVariable).filter(
            AgentVariable.agent_id == agent_id,
            AgentVariable.variable_id.in_(group.variable_ids)
        ).all()
        group_dict["variables"] = [v.to_dict() for v in variables]
    else:
        group_dict["variables"] = []
    
    return VariableGroupResponse(**group_dict)


@router.delete("/agents/{agent_id}/variable-groups/{group_id}")
async def delete_variable_group(
    agent_id: UUID,
    group_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Delete a variable group"""
    group = db.query(AgentVariableGroup).filter(
        AgentVariableGroup.id == group_id,
        AgentVariableGroup.agent_id == agent_id
    ).first()
    
    if not group:
        raise HTTPException(status_code=404, detail="Variable group not found")
    
    db.delete(group)
    db.commit()
    
    return {"message": "Variable group deleted successfully"}


@router.put("/agents/{agent_id}/variable-groups/reorder")
async def reorder_variable_groups(
    agent_id: UUID,
    group_ids: List[UUID],
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Reorder variable groups within an agent"""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    for order, group_id in enumerate(group_ids):
        db.query(AgentVariableGroup).filter(
            AgentVariableGroup.id == group_id,
            AgentVariableGroup.agent_id == agent_id
        ).update({"sort_order": order})
    
    db.commit()
    
    return {"message": "Variable groups reordered successfully"}


@router.put("/agents/{agent_id}/variable-groups/{group_id}/variables")
async def update_group_variables(
    agent_id: UUID,
    group_id: UUID,
    variable_ids: List[UUID],
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Update the variables in a group"""
    group = db.query(AgentVariableGroup).filter(
        AgentVariableGroup.id == group_id,
        AgentVariableGroup.agent_id == agent_id
    ).first()
    
    if not group:
        raise HTTPException(status_code=404, detail="Variable group not found")
    
    # Convert UUIDs to strings for JSON storage
    group.variable_ids = [str(vid) for vid in variable_ids]
    
    db.commit()
    db.refresh(group)
    
    return {"message": "Group variables updated successfully", "variable_ids": group.variable_ids}


# ==================== SAFETY RULE ENDPOINTS ====================

@router.get("/safety-rules", response_model=SafetyRuleListResponse)
async def list_safety_rules(
    rule_type: Optional[str] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """List all safety rules"""
    query = db.query(SafetyRule)
    
    if rule_type:
        query = query.filter(SafetyRule.rule_type == rule_type)
    if status:
        query = query.filter(SafetyRule.status == status)
    
    rules = query.order_by(SafetyRule.priority.desc(), SafetyRule.created_at).all()
    
    return SafetyRuleListResponse(
        rules=[SafetyRuleResponse(**r.to_dict()) for r in rules],
        total=len(rules)
    )


@router.post("/safety-rules", response_model=SafetyRuleResponse)
async def create_safety_rule(
    rule_data: SafetyRuleCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Create a new safety rule"""
    existing = db.query(SafetyRule).filter(SafetyRule.name == rule_data.name).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"Rule with name '{rule_data.name}' already exists")
    
    rule = SafetyRule(
        **rule_data.model_dump(),
        created_by=current_user.user_uuid
    )
    
    db.add(rule)
    db.commit()
    db.refresh(rule)
    
    return SafetyRuleResponse(**rule.to_dict())


@router.get("/safety-rules/{rule_id}", response_model=SafetyRuleResponse)
async def get_safety_rule(
    rule_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Get safety rule by ID"""
    rule = db.query(SafetyRule).filter(SafetyRule.id == rule_id).first()
    if not rule:
        raise HTTPException(status_code=404, detail="Safety rule not found")
    
    return SafetyRuleResponse(**rule.to_dict())


@router.put("/safety-rules/{rule_id}", response_model=SafetyRuleResponse)
async def update_safety_rule(
    rule_id: UUID,
    rule_data: SafetyRuleUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Update a safety rule"""
    rule = db.query(SafetyRule).filter(SafetyRule.id == rule_id).first()
    if not rule:
        raise HTTPException(status_code=404, detail="Safety rule not found")
    
    if rule.is_system and rule_data.name:
        raise HTTPException(status_code=403, detail="Cannot rename system rules")
    
    if rule_data.name and rule_data.name != rule.name:
        existing = db.query(SafetyRule).filter(SafetyRule.name == rule_data.name).first()
        if existing:
            raise HTTPException(status_code=400, detail=f"Rule with name '{rule_data.name}' already exists")
    
    update_data = rule_data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(rule, key, value)
    
    db.commit()
    db.refresh(rule)
    
    return SafetyRuleResponse(**rule.to_dict())


@router.delete("/safety-rules/{rule_id}")
async def delete_safety_rule(
    rule_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Delete a safety rule"""
    rule = db.query(SafetyRule).filter(SafetyRule.id == rule_id).first()
    if not rule:
        raise HTTPException(status_code=404, detail="Safety rule not found")
    
    if rule.is_system:
        raise HTTPException(status_code=403, detail="Cannot delete system rules")
    
    db.delete(rule)
    db.commit()
    
    return {"message": "Safety rule deleted successfully"}


# ==================== SAFETY LOG ENDPOINTS ====================

@router.get("/safety-logs", response_model=SafetyLogListResponse)
async def list_safety_logs(
    rule_id: Optional[UUID] = None,
    user_id: Optional[UUID] = None,
    blocked_only: bool = False,
    limit: int = Query(100, le=1000),
    offset: int = 0,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """List safety logs with filtering"""
    query = db.query(SafetyLog)
    
    if rule_id:
        query = query.filter(SafetyLog.rule_id == rule_id)
    if user_id:
        query = query.filter(SafetyLog.user_id == user_id)
    if blocked_only:
        query = query.filter(SafetyLog.was_blocked == True)
    
    total = query.count()
    logs = query.order_by(SafetyLog.created_at.desc()).offset(offset).limit(limit).all()
    
    return SafetyLogListResponse(
        logs=[SafetyLogResponse(**l.to_dict()) for l in logs],
        total=total
    )


# ==================== WORKFLOW ENDPOINTS ====================

@router.get("/workflow", response_model=WorkflowGraph)
async def get_workflow_graph(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Get the complete workflow graph"""
    agents = db.query(Agent).filter(Agent.status != AgentStatus.ARCHIVED).order_by(Agent.sort_order).all()
    connections = db.query(AgentConnection).all()
    
    entry_point = db.query(Agent).filter(Agent.is_entry_point == True).first()
    
    return WorkflowGraph(
        agents=[AgentResponse(**a.to_dict()) for a in agents],
        connections=[AgentConnectionResponse(**c.to_dict()) for c in connections],
        entry_point_id=entry_point.id if entry_point else None
    )


@router.post("/workflow/validate", response_model=WorkflowValidation)
async def validate_workflow(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Validate the workflow graph"""
    errors = []
    warnings = []
    
    # Check for entry point
    entry_points = db.query(Agent).filter(Agent.is_entry_point == True, Agent.status == AgentStatus.ACTIVE).all()
    if len(entry_points) == 0:
        errors.append("No active entry point agent defined")
    elif len(entry_points) > 1:
        warnings.append(f"Multiple entry points found: {[e.name for e in entry_points]}")
    
    # Check for orphaned agents (no incoming connections, not entry point)
    active_agents = db.query(Agent).filter(Agent.status == AgentStatus.ACTIVE).all()
    
    for agent in active_agents:
        if not agent.is_entry_point:
            incoming = db.query(AgentConnection).filter(AgentConnection.target_agent_id == agent.id).count()
            if incoming == 0:
                warnings.append(f"Agent '{agent.name}' has no incoming connections")
    
    # Check for dead ends (no outgoing connections)
    for agent in active_agents:
        outgoing = db.query(AgentConnection).filter(AgentConnection.source_agent_id == agent.id).count()
        if outgoing == 0 and agent.agent_type != AgentType.ANALYZER:
            warnings.append(f"Agent '{agent.name}' has no outgoing connections (dead end)")
    
    # Check for circular dependencies
    # (simplified check - could be more thorough)
    connections = db.query(AgentConnection).all()
    graph = {}
    for conn in connections:
        if str(conn.source_agent_id) not in graph:
            graph[str(conn.source_agent_id)] = []
        graph[str(conn.source_agent_id)].append(str(conn.target_agent_id))
    
    # Basic cycle detection
    def has_cycle(node, visited, rec_stack, graph):
        visited.add(node)
        rec_stack.add(node)
        
        for neighbor in graph.get(node, []):
            if neighbor not in visited:
                if has_cycle(neighbor, visited, rec_stack, graph):
                    return True
            elif neighbor in rec_stack:
                return True
        
        rec_stack.remove(node)
        return False
    
    visited = set()
    rec_stack = set()
    for node in graph:
        if node not in visited:
            if has_cycle(node, visited, rec_stack, graph):
                warnings.append("Workflow contains circular dependencies (may be intentional)")
                break
    
    return WorkflowValidation(
        is_valid=len(errors) == 0,
        errors=errors,
        warnings=warnings
    )


# ==================== TESTING ENDPOINTS ====================

@router.post("/test-script", response_model=TestScriptResponse)
async def test_script(
    request: TestScriptRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Test a script or condition expression in a sandboxed environment.
    
    Security: Uses SafeScriptExecutor to prevent RCE attacks.
    No file access, imports, or dangerous operations are allowed.
    """
    from utils.script_sandbox import SafeScriptExecutor, ScriptType
    
    executor = SafeScriptExecutor()
    
    try:
        if request.script_type == "python" or request.script_type == "transform":
            # Execute as transformation script
            result = executor.execute_script(
                request.script,
                input_data=request.test_input or {}
            )
            
        elif request.script_type == "condition":
            # Execute as boolean condition
            result = executor.execute_condition(
                request.script,
                context=request.test_input or {}
            )
        else:
            raise ValueError(f"Unknown script type: {request.script_type}")
        
        if result.success:
            return TestScriptResponse(
                success=True,
                output=result.output,
                execution_time_ms=result.execution_time_ms
            )
        else:
            return TestScriptResponse(
                success=False,
                error=result.error,
                execution_time_ms=result.execution_time_ms
            )
        
    except Exception as e:
        return TestScriptResponse(
            success=False,
            error=f"Sandbox error: {str(e)}",
            execution_time_ms=0.0
        )


@router.post("/validate-script")
async def validate_script(
    request: TestScriptRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Validate a script for security issues WITHOUT executing it.
    
    Use this to check if a script is safe before saving it.
    Returns validation status and any security warnings.
    """
    from utils.script_sandbox import SafeScriptExecutor
    
    executor = SafeScriptExecutor()
    is_valid, error = executor.validate_script(request.script)
    
    return {
        "valid": is_valid,
        "error": error,
        "script_length": len(request.script),
        "script_type": request.script_type
    }


# ==================== PROMPT SAFETY ENDPOINTS ====================

class PromptValidationRequest(BaseModel):
    """Request to validate a prompt for injection attacks"""
    text: str
    strictness: str = "medium"  # "low", "medium", "high"
    max_length: int = 2000
    check_type: str = "input"  # "input" or "output"


class SafetyRuleCheckRequest(BaseModel):
    """Request to check text against safety rules"""
    text: str
    apply_to: str = "input"  # "input" or "output"
    agent_id: Optional[str] = None


@router.post("/validate-prompt")
async def validate_prompt(
    request: PromptValidationRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Validate a prompt/input for potential injection attacks.
    
    Returns detailed analysis including:
    - Whether the input is safe
    - List of detected threats with severity
    - Sanitized version of the text
    - Check time in milliseconds
    
    Use this to test prompts before deploying or to validate user input.
    """
    from utils.prompt_guard import PromptGuard, CheckResult
    
    try:
        guard = PromptGuard(
            strictness=request.strictness,
            max_length=request.max_length,
            enable_logging=True
        )
        
        context = {
            "user_id": str(current_user.id),
            "admin_test": True
        }
        
        if request.check_type == "output":
            result = guard.check_output(request.text, context)
        else:
            result = guard.check_input(request.text, context)
        
        return {
            "is_safe": result.is_safe,
            "threat_count": result.threat_count,
            "highest_severity": result.highest_severity,
            "threats": [
                {
                    "category": t.category.value,
                    "severity": t.severity,
                    "description": t.description,
                    "matched_text": t.matched_text[:50] + "..." if len(t.matched_text) > 50 else t.matched_text,
                    "position": t.position
                }
                for t in result.threats
            ],
            "sanitized_text": result.sanitized_text,
            "original_length": len(request.text),
            "sanitized_length": len(result.sanitized_text or ""),
            "check_time_ms": result.check_time_ms,
            "strictness": request.strictness
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Validation error: {str(e)}")


@router.post("/check-safety-rules")
async def check_safety_rules(
    request: SafetyRuleCheckRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Check text against configured safety rules in the database.
    
    Returns which rules (if any) matched and what action would be taken.
    Useful for testing rules before activating them.
    """
    from utils.prompt_guard import evaluate_safety_rules
    from models.safety_rule import SafetyRule, SafetyRuleStatus
    
    try:
        # Load active safety rules
        query = db.query(SafetyRule).filter(
            SafetyRule.status.in_([SafetyRuleStatus.ACTIVE, SafetyRuleStatus.TESTING])
        )
        
        # Filter by agent if specified
        if request.agent_id:
            query = query.filter(
                (SafetyRule.agent_ids == None) | 
                (SafetyRule.agent_ids.contains([request.agent_id]))
            )
        
        rules = query.order_by(SafetyRule.priority.desc()).all()
        rules_dicts = [r.to_dict() for r in rules]
        
        # Evaluate rules
        is_allowed, matched_rule, action_message = evaluate_safety_rules(
            request.text,
            rules_dicts,
            apply_to=request.apply_to
        )
        
        return {
            "is_allowed": is_allowed,
            "matched_rule": matched_rule.get("name") if matched_rule else None,
            "matched_rule_id": matched_rule.get("id") if matched_rule else None,
            "action": matched_rule.get("action") if matched_rule else None,
            "action_message": action_message,
            "rules_checked": len(rules_dicts),
            "apply_to": request.apply_to
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Rule check error: {str(e)}")


@router.get("/safety-logs")
async def get_safety_logs(
    limit: int = 50,
    offset: int = 0,
    severity: Optional[str] = None,
    rule_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Get safety event logs for admin review.
    
    Shows recent prompt injection attempts and safety rule matches.
    """
    from models.safety_rule import SafetyLog
    
    try:
        query = db.query(SafetyLog).order_by(SafetyLog.created_at.desc())
        
        if rule_id:
            query = query.filter(SafetyLog.rule_id == rule_id)
        
        total = query.count()
        logs = query.offset(offset).limit(limit).all()
        
        return {
            "total": total,
            "offset": offset,
            "limit": limit,
            "logs": [log.to_dict() for log in logs]
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching logs: {str(e)}")


@router.post("/log-safety-event")
async def log_safety_event(
    rule_id: str,
    input_preview: str,
    matched_content: str,
    action_taken: str,
    was_blocked: bool = False,
    session_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Log a safety event for analytics and auditing.
    
    Called internally when a safety rule matches.
    """
    from models.safety_rule import SafetyLog, SafetyRule
    import uuid
    
    try:
        # Get rule name
        rule = db.query(SafetyRule).filter(SafetyRule.id == rule_id).first()
        rule_name = rule.name if rule else "unknown"
        
        log = SafetyLog(
            id=uuid.uuid4(),
            rule_id=uuid.UUID(rule_id),
            rule_name=rule_name,
            user_id=current_user.id,
            session_id=session_id,
            agent_id=uuid.UUID(agent_id) if agent_id else None,
            input_preview=input_preview[:500],
            matched_content=matched_content[:200],
            action_taken=action_taken,
            was_blocked=was_blocked
        )
        
        db.add(log)
        db.commit()
        
        return {"logged": True, "log_id": str(log.id)}
        
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Logging error: {str(e)}")


# ==================== UTILITY ENDPOINTS ====================

@router.get("/agent-types")
async def get_agent_types(
    db: Session = Depends(get_db),
    include_inactive: bool = False
):
    """
    Get available agent types.
    
    Fetches from database for dynamic configuration.
    Falls back to hardcoded defaults if table doesn't exist.
    """
    try:
        # Try to get from database first
        from models.workflow_stage import AgentType as AgentTypeModel
        
        query = db.query(AgentTypeModel)
        if not include_inactive:
            query = query.filter(AgentTypeModel.is_active == True)
        
        types = query.order_by(AgentTypeModel.sort_order).all()
        
        if types:
            return [t.to_dict() for t in types]
    except Exception as e:
        # Table might not exist yet, fall back to hardcoded
        print(f"Warning: Could not fetch agent types from database: {e}")
    
    # Fallback to hardcoded defaults
    return [
        {"value": "triage", "label": "分诊Agent", "description": "初始问诊和意图识别", "icon": "🎯", "default_stage": "triage"},
        {"value": "domain", "label": "专业Agent", "description": "领域特定变量收集", "icon": "👨‍💼", "default_stage": "professional"},
        {"value": "fetch", "label": "获取Agent", "description": "对话获取和信息提取", "icon": "💬", "default_stage": "professional"},
        {"value": "search", "label": "搜索Agent", "description": "法条和案例检索", "icon": "🔍", "default_stage": "search"},
        {"value": "analyzer", "label": "分析Agent", "description": "数据分析和推荐", "icon": "📊", "default_stage": "analysis"},
        {"value": "generation", "label": "生成Agent", "description": "文档和报告生成", "icon": "📝", "default_stage": "generation"},
        {"value": "custom", "label": "自定义Agent", "description": "自定义功能", "icon": "⚙️", "default_stage": None},
    ]


@router.get("/workflow-phases")
async def get_workflow_phases(
    db: Session = Depends(get_db),
    include_inactive: bool = False
):
    """
    Get workflow phases/stages for pipeline display.
    
    Fetches from database for dynamic configuration.
    Falls back to hardcoded defaults if table doesn't exist.
    """
    try:
        # Try to get from database first
        from models.workflow_stage import WorkflowStage as WorkflowStageModel
        
        query = db.query(WorkflowStageModel)
        if not include_inactive:
            query = query.filter(WorkflowStageModel.is_active == True)
        
        stages = query.order_by(WorkflowStageModel.sort_order).all()
        
        if stages:
            return [s.to_simple_dict() for s in stages]
    except Exception as e:
        # Table might not exist yet, fall back to hardcoded
        print(f"Warning: Could not fetch workflow stages from database: {e}")
    
    # Fallback to hardcoded defaults
    return [
        {"key": "triage", "name": "分诊", "icon": "🎯", "agent_type": "triage"},
        {"key": "professional", "name": "专业", "icon": "👨‍💼", "agent_type": "domain"},
        {"key": "search", "name": "搜索", "icon": "🔍", "agent_type": "search"},
        {"key": "analysis", "name": "分析", "icon": "📊", "agent_type": "analyzer"},
        {"key": "generation", "name": "生成", "icon": "📝", "agent_type": "generation"},
    ]


@router.get("/tool-types")
async def get_tool_types():
    """Get available tool types"""
    return [
        {"value": "calculator", "label": "计算器", "description": "数学计算工具"},
        {"value": "search", "label": "数据库搜索", "description": "数据库查询工具"},
        {"value": "api", "label": "API调用", "description": "外部API调用"},
        {"value": "script", "label": "自定义脚本", "description": "Python脚本"},
        {"value": "rag", "label": "RAG检索", "description": "向量相似度搜索"},
        {"value": "elasticsearch", "label": "ES搜索", "description": "Elasticsearch关键词搜索"},
        {"value": "document", "label": "文档处理", "description": "文档生成和处理"},
        {"value": "validation", "label": "验证工具", "description": "输入验证"},
    ]


@router.get("/safety-rule-types")
async def get_safety_rule_types():
    """Get available safety rule types"""
    return [
        {"value": "input_filter", "label": "输入过滤", "description": "过滤用户输入"},
        {"value": "output_filter", "label": "输出过滤", "description": "过滤Agent输出"},
        {"value": "jailbreak", "label": "越狱检测", "description": "检测越狱尝试"},
        {"value": "language", "label": "语言检查", "description": "语言检测和限制"},
        {"value": "moderation", "label": "内容审核", "description": "内容审核"},
        {"value": "rate_limit", "label": "频率限制", "description": "请求频率限制"},
        {"value": "length_limit", "label": "长度限制", "description": "消息长度限制"},
        {"value": "custom", "label": "自定义规则", "description": "自定义安全规则"},
    ]


# ==================== MOTHER POINT ENDPOINTS ====================

@router.get("/mother-points", response_model=MotherPointListResponse)
async def list_mother_points(
    status: Optional[str] = Query(None, description="Filter by status"),
    category: Optional[str] = Query(None, description="Filter by category"),
    search: Optional[str] = Query(None, description="Search in name/description"),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """List all mother points"""
    query = db.query(MotherPoint)
    
    if status:
        query = query.filter(MotherPoint.status == status)
    if category:
        query = query.filter(MotherPoint.category == category)
    if search:
        query = query.filter(
            (MotherPoint.name.ilike(f"%{search}%")) |
            (MotherPoint.display_name.ilike(f"%{search}%")) |
            (MotherPoint.description.ilike(f"%{search}%"))
        )
    
    mother_points = query.order_by(MotherPoint.sort_order, MotherPoint.created_at.desc()).all()
    
    return MotherPointListResponse(
        mother_points=[MotherPointResponse(**mp.to_dict()) for mp in mother_points],
        total=len(mother_points)
    )


@router.post("/mother-points", response_model=MotherPointResponse)
async def create_mother_point(
    data: MotherPointCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Create a new mother point"""
    # Check for duplicate name
    existing = db.query(MotherPoint).filter(MotherPoint.name == data.name).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"Mother point with name '{data.name}' already exists")
    
    # Convert pydantic models to dicts for JSON storage
    mp_data = data.model_dump(exclude_unset=True)
    if 'sub_categories' in mp_data and mp_data['sub_categories']:
        mp_data['sub_categories'] = [sc.model_dump() if hasattr(sc, 'model_dump') else sc for sc in mp_data['sub_categories']]
    if 'key_points' in mp_data and mp_data['key_points']:
        mp_data['key_points'] = [kp.model_dump() if hasattr(kp, 'model_dump') else kp for kp in mp_data['key_points']]
    
    mother_point = MotherPoint(
        **mp_data,
        created_by=current_user.user_uuid
    )
    
    db.add(mother_point)
    db.commit()
    db.refresh(mother_point)
    
    return MotherPointResponse(**mother_point.to_dict())


@router.get("/mother-points/{mother_point_id}", response_model=MotherPointResponse)
async def get_mother_point(
    mother_point_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Get a mother point by ID"""
    mother_point = db.query(MotherPoint).filter(MotherPoint.id == mother_point_id).first()
    if not mother_point:
        raise HTTPException(status_code=404, detail="Mother point not found")
    
    return MotherPointResponse(**mother_point.to_dict())


@router.put("/mother-points/{mother_point_id}", response_model=MotherPointResponse)
async def update_mother_point(
    mother_point_id: UUID,
    data: MotherPointUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Update a mother point"""
    mother_point = db.query(MotherPoint).filter(MotherPoint.id == mother_point_id).first()
    if not mother_point:
        raise HTTPException(status_code=404, detail="Mother point not found")
    
    if mother_point.is_system:
        raise HTTPException(status_code=403, detail="Cannot modify system mother point")
    
    # Check for duplicate name if name is being changed
    if data.name and data.name != mother_point.name:
        existing = db.query(MotherPoint).filter(MotherPoint.name == data.name).first()
        if existing:
            raise HTTPException(status_code=400, detail=f"Mother point with name '{data.name}' already exists")
    
    update_data = data.model_dump(exclude_unset=True)
    
    # Convert nested models to dicts
    if 'sub_categories' in update_data and update_data['sub_categories']:
        update_data['sub_categories'] = [sc.model_dump() if hasattr(sc, 'model_dump') else sc for sc in update_data['sub_categories']]
    if 'key_points' in update_data and update_data['key_points']:
        update_data['key_points'] = [kp.model_dump() if hasattr(kp, 'model_dump') else kp for kp in update_data['key_points']]
    
    for key, value in update_data.items():
        setattr(mother_point, key, value)
    
    db.commit()
    db.refresh(mother_point)
    
    return MotherPointResponse(**mother_point.to_dict())


@router.delete("/mother-points/{mother_point_id}")
async def delete_mother_point(
    mother_point_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Delete a mother point"""
    mother_point = db.query(MotherPoint).filter(MotherPoint.id == mother_point_id).first()
    if not mother_point:
        raise HTTPException(status_code=404, detail="Mother point not found")
    
    if mother_point.is_system:
        raise HTTPException(status_code=403, detail="Cannot delete system mother point")
    
    db.delete(mother_point)
    db.commit()
    
    return {"status": "deleted", "id": str(mother_point_id)}


@router.post("/mother-points/{mother_point_id}/duplicate", response_model=MotherPointResponse)
async def duplicate_mother_point(
    mother_point_id: UUID,
    new_name: str = Query(..., description="Name for the duplicate"),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Duplicate a mother point"""
    original = db.query(MotherPoint).filter(MotherPoint.id == mother_point_id).first()
    if not original:
        raise HTTPException(status_code=404, detail="Mother point not found")
    
    # Check for duplicate name
    existing = db.query(MotherPoint).filter(MotherPoint.name == new_name).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"Mother point with name '{new_name}' already exists")
    
    # Create duplicate
    duplicate = MotherPoint(
        name=new_name,
        display_name=f"{original.display_name} (副本)",
        description=original.description,
        category=original.category,
        icon=original.icon,
        is_required=original.is_required,
        confirmation_question=original.confirmation_question,
        confirmation_keywords=original.confirmation_keywords,
        sub_categories=original.sub_categories,
        key_points=original.key_points,
        evidence_type=original.evidence_type,
        evidence_description=original.evidence_description,
        evidence_examples=original.evidence_examples,
        question_template=original.question_template,
        question_style=original.question_style,
        temperature=original.temperature,
        extraction_prompt=original.extraction_prompt,
        extraction_examples=original.extraction_examples,
        sort_order=original.sort_order + 1,
        color=original.color,
        status='draft',
        is_system=False,
        created_by=current_user.user_uuid
    )
    
    db.add(duplicate)
    db.commit()
    db.refresh(duplicate)
    
    return MotherPointResponse(**duplicate.to_dict())


# ==================== AGENT MOTHER POINT ASSIGNMENT ENDPOINTS ====================

@router.get("/agents/{agent_id}/mother-points", response_model=List[AgentMotherPointResponse])
async def get_agent_mother_points(
    agent_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Get all mother points assigned to an agent"""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    assignments = db.query(AgentMotherPoint).filter(
        AgentMotherPoint.agent_id == agent_id
    ).order_by(AgentMotherPoint.sort_order).all()
    
    return [AgentMotherPointResponse(**a.to_dict()) for a in assignments]


@router.post("/agents/{agent_id}/mother-points", response_model=AgentMotherPointResponse)
async def assign_mother_point_to_agent(
    agent_id: UUID,
    data: AgentMotherPointAssignment,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Assign a mother point to an agent"""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    mother_point = db.query(MotherPoint).filter(MotherPoint.id == data.mother_point_id).first()
    if not mother_point:
        raise HTTPException(status_code=404, detail="Mother point not found")
    
    # Check if already assigned
    existing = db.query(AgentMotherPoint).filter(
        AgentMotherPoint.agent_id == agent_id,
        AgentMotherPoint.mother_point_id == data.mother_point_id
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Mother point already assigned to this agent")
    
    assignment_data = data.model_dump(exclude_unset=True)
    if 'custom_key_points' in assignment_data and assignment_data['custom_key_points']:
        assignment_data['custom_key_points'] = [kp.model_dump() if hasattr(kp, 'model_dump') else kp for kp in assignment_data['custom_key_points']]
    
    assignment = AgentMotherPoint(
        agent_id=agent_id,
        **assignment_data
    )
    
    db.add(assignment)
    db.commit()
    db.refresh(assignment)
    
    return AgentMotherPointResponse(**assignment.to_dict())


@router.put("/agents/{agent_id}/mother-points/{assignment_id}", response_model=AgentMotherPointResponse)
async def update_agent_mother_point(
    agent_id: UUID,
    assignment_id: UUID,
    data: AgentMotherPointAssignment,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Update a mother point assignment for an agent"""
    assignment = db.query(AgentMotherPoint).filter(
        AgentMotherPoint.id == assignment_id,
        AgentMotherPoint.agent_id == agent_id
    ).first()
    if not assignment:
        raise HTTPException(status_code=404, detail="Assignment not found")
    
    update_data = data.model_dump(exclude_unset=True)
    if 'custom_key_points' in update_data and update_data['custom_key_points']:
        update_data['custom_key_points'] = [kp.model_dump() if hasattr(kp, 'model_dump') else kp for kp in update_data['custom_key_points']]
    
    for key, value in update_data.items():
        setattr(assignment, key, value)
    
    db.commit()
    db.refresh(assignment)
    
    return AgentMotherPointResponse(**assignment.to_dict())


@router.delete("/agents/{agent_id}/mother-points/{assignment_id}")
async def remove_mother_point_from_agent(
    agent_id: UUID,
    assignment_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Remove a mother point from an agent"""
    assignment = db.query(AgentMotherPoint).filter(
        AgentMotherPoint.id == assignment_id,
        AgentMotherPoint.agent_id == agent_id
    ).first()
    if not assignment:
        raise HTTPException(status_code=404, detail="Assignment not found")
    
    db.delete(assignment)
    db.commit()
    
    return {"status": "removed", "id": str(assignment_id)}


@router.put("/agents/{agent_id}/mother-points/reorder")
async def reorder_agent_mother_points(
    agent_id: UUID,
    assignment_ids: List[UUID],
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Reorder mother points for an agent"""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    for index, assignment_id in enumerate(assignment_ids):
        assignment = db.query(AgentMotherPoint).filter(
            AgentMotherPoint.id == assignment_id,
            AgentMotherPoint.agent_id == agent_id
        ).first()
        if assignment:
            assignment.sort_order = index
    
    db.commit()
    
    return {"status": "reordered", "count": len(assignment_ids)}


# ==================== MOTHER POINT CATEGORIES ====================

@router.get("/mother-point-categories")
async def get_mother_point_categories(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Get all unique mother point categories"""
    categories = db.query(MotherPoint.category).filter(
        MotherPoint.category.isnot(None)
    ).distinct().all()
    
    return [c[0] for c in categories if c[0]]


@router.get("/mother-point-data-types")
async def get_mother_point_data_types():
    """Get available data types for key points"""
    return [
        {"value": "text", "label": "文本", "description": "自由文本输入"},
        {"value": "number", "label": "数字", "description": "数值输入（含金额）"},
        {"value": "date", "label": "日期", "description": "日期选择"},
        {"value": "datetime", "label": "日期时间", "description": "日期和时间选择"},
        {"value": "select", "label": "单选", "description": "从选项中单选"},
        {"value": "multi_select", "label": "多选", "description": "从选项中多选"},
        {"value": "boolean", "label": "是/否", "description": "是或否选择"},
        {"value": "upload", "label": "上传", "description": "文件上传"},
        {"value": "location", "label": "地址", "description": "地址输入"},
        {"value": "phone", "label": "电话", "description": "电话号码"},
        {"value": "id_card", "label": "身份证号", "description": "身份证号码"},
    ]


@router.get("/evidence-types")
async def get_evidence_types():
    """Get available evidence types"""
    return [
        {"value": "none", "label": "无需证据", "description": "不需要提供证据"},
        {"value": "upload", "label": "文件上传", "description": "上传文件作为证据"},
        {"value": "photo", "label": "拍照", "description": "拍照上传"},
        {"value": "document", "label": "文档扫描", "description": "扫描文档"},
        {"value": "receipt", "label": "收据/发票", "description": "收据或发票"},
        {"value": "certificate", "label": "证明文件", "description": "官方证明文件"},
    ]

