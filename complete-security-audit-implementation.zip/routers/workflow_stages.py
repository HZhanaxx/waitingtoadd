"""
Workflow Stages Router
======================

API endpoints for managing workflow stages and agent types.
Provides dynamic configuration for the Agent Studio pipeline.
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional, List
from uuid import UUID
from pydantic import BaseModel, Field
from datetime import datetime

from database import get_db
from utils.auth import get_current_user
from routers.admin import require_admin
from models.user import User
from models.workflow_stage import WorkflowStage, AgentType as AgentTypeModel
from models.workflow_stage import DEFAULT_WORKFLOW_STAGES, DEFAULT_AGENT_TYPES

router = APIRouter(prefix="/api/workflow-stages", tags=["Workflow Stages"])


# ==================== Pydantic Schemas ====================

class WorkflowStageBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=50)
    display_name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    icon: Optional[str] = None
    color: Optional[str] = None
    sort_order: int = 0
    is_active: bool = True
    agent_type_filter: Optional[str] = None
    allowed_transitions: Optional[List[str]] = None
    auto_advance: bool = False
    requires_all_agents: bool = False
    max_agents: Optional[int] = None
    timeout_seconds: Optional[int] = None


class WorkflowStageCreate(WorkflowStageBase):
    pass


class WorkflowStageUpdate(BaseModel):
    display_name: Optional[str] = None
    description: Optional[str] = None
    icon: Optional[str] = None
    color: Optional[str] = None
    sort_order: Optional[int] = None
    is_active: Optional[bool] = None
    agent_type_filter: Optional[str] = None
    allowed_transitions: Optional[List[str]] = None
    auto_advance: Optional[bool] = None
    requires_all_agents: Optional[bool] = None
    max_agents: Optional[int] = None
    timeout_seconds: Optional[int] = None


class WorkflowStageResponse(BaseModel):
    id: str
    name: str
    display_name: str
    description: Optional[str]
    icon: Optional[str]
    color: Optional[str]
    sort_order: int
    is_active: bool
    is_system: bool
    agent_type_filter: Optional[str]
    allowed_transitions: Optional[List[str]]
    auto_advance: bool
    requires_all_agents: bool
    max_agents: Optional[int]
    timeout_seconds: Optional[int]
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True


class AgentTypeBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=50)
    display_name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    icon: Optional[str] = None
    color: Optional[str] = None
    default_stage: Optional[str] = None
    sort_order: int = 0
    is_active: bool = True
    capabilities: Optional[List[str]] = None
    default_config: Optional[dict] = None


class AgentTypeCreate(AgentTypeBase):
    pass


class AgentTypeUpdate(BaseModel):
    display_name: Optional[str] = None
    description: Optional[str] = None
    icon: Optional[str] = None
    color: Optional[str] = None
    default_stage: Optional[str] = None
    sort_order: Optional[int] = None
    is_active: Optional[bool] = None
    capabilities: Optional[List[str]] = None
    default_config: Optional[dict] = None


class AgentTypeResponse(BaseModel):
    id: str
    name: str
    value: str  # Alias for name, for frontend compatibility
    display_name: str
    label: str  # Alias for display_name, for frontend compatibility
    description: Optional[str]
    icon: Optional[str]
    color: Optional[str]
    default_stage: Optional[str]
    sort_order: int
    is_active: bool
    is_system: bool
    capabilities: Optional[List[str]]
    default_config: Optional[dict]
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True


# ==================== WORKFLOW STAGE ENDPOINTS ====================

@router.get("", response_model=List[WorkflowStageResponse])
async def list_workflow_stages(
    include_inactive: bool = Query(False, description="Include inactive stages"),
    db: Session = Depends(get_db)
):
    """
    List all workflow stages.
    
    Returns stages ordered by sort_order.
    By default, only returns active stages.
    """
    query = db.query(WorkflowStage)
    
    if not include_inactive:
        query = query.filter(WorkflowStage.is_active == True)
    
    stages = query.order_by(WorkflowStage.sort_order).all()
    
    return [WorkflowStageResponse(**s.to_dict()) for s in stages]


@router.get("/pipeline")
async def get_pipeline_stages(
    db: Session = Depends(get_db)
):
    """
    Get simplified stage data for frontend pipeline display.
    
    Returns minimal data needed for the pipeline overview UI.
    """
    stages = db.query(WorkflowStage).filter(
        WorkflowStage.is_active == True
    ).order_by(WorkflowStage.sort_order).all()
    
    return [s.to_simple_dict() for s in stages]


@router.get("/{stage_id}", response_model=WorkflowStageResponse)
async def get_workflow_stage(
    stage_id: UUID,
    db: Session = Depends(get_db)
):
    """Get a workflow stage by ID."""
    stage = db.query(WorkflowStage).filter(WorkflowStage.id == stage_id).first()
    
    if not stage:
        raise HTTPException(status_code=404, detail="Workflow stage not found")
    
    return WorkflowStageResponse(**stage.to_dict())


@router.get("/by-name/{name}", response_model=WorkflowStageResponse)
async def get_workflow_stage_by_name(
    name: str,
    db: Session = Depends(get_db)
):
    """Get a workflow stage by name."""
    stage = db.query(WorkflowStage).filter(WorkflowStage.name == name).first()
    
    if not stage:
        raise HTTPException(status_code=404, detail="Workflow stage not found")
    
    return WorkflowStageResponse(**stage.to_dict())


@router.post("", response_model=WorkflowStageResponse)
async def create_workflow_stage(
    stage_data: WorkflowStageCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Create a new workflow stage.
    
    Admin only. System stages cannot be created via API.
    """
    # Check for duplicate name
    existing = db.query(WorkflowStage).filter(
        WorkflowStage.name == stage_data.name
    ).first()
    
    if existing:
        raise HTTPException(
            status_code=400, 
            detail=f"Stage with name '{stage_data.name}' already exists"
        )
    
    # Create stage
    stage = WorkflowStage(
        **stage_data.model_dump(),
        is_system=False,
        created_by=current_user.id
    )
    
    db.add(stage)
    db.commit()
    db.refresh(stage)
    
    return WorkflowStageResponse(**stage.to_dict())


@router.put("/{stage_id}", response_model=WorkflowStageResponse)
async def update_workflow_stage(
    stage_id: UUID,
    stage_data: WorkflowStageUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Update a workflow stage.
    
    Admin only. System stage names cannot be changed.
    """
    stage = db.query(WorkflowStage).filter(WorkflowStage.id == stage_id).first()
    
    if not stage:
        raise HTTPException(status_code=404, detail="Workflow stage not found")
    
    # Update fields
    update_data = stage_data.model_dump(exclude_unset=True)
    
    for key, value in update_data.items():
        setattr(stage, key, value)
    
    db.commit()
    db.refresh(stage)
    
    return WorkflowStageResponse(**stage.to_dict())


@router.delete("/{stage_id}")
async def delete_workflow_stage(
    stage_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Delete a workflow stage (soft delete by setting is_active=False).
    
    Admin only. System stages cannot be deleted.
    """
    stage = db.query(WorkflowStage).filter(WorkflowStage.id == stage_id).first()
    
    if not stage:
        raise HTTPException(status_code=404, detail="Workflow stage not found")
    
    if stage.is_system:
        raise HTTPException(
            status_code=400, 
            detail="System stages cannot be deleted"
        )
    
    # Soft delete
    stage.is_active = False
    db.commit()
    
    return {"message": "Stage deactivated successfully"}


@router.post("/{stage_id}/reorder")
async def reorder_workflow_stage(
    stage_id: UUID,
    new_order: int = Query(..., ge=0),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Reorder a workflow stage.
    
    Moves the stage to the specified sort_order position.
    """
    stage = db.query(WorkflowStage).filter(WorkflowStage.id == stage_id).first()
    
    if not stage:
        raise HTTPException(status_code=404, detail="Workflow stage not found")
    
    old_order = stage.sort_order
    
    # Shift other stages
    if new_order < old_order:
        # Moving up - shift others down
        db.query(WorkflowStage).filter(
            WorkflowStage.sort_order >= new_order,
            WorkflowStage.sort_order < old_order
        ).update({WorkflowStage.sort_order: WorkflowStage.sort_order + 1})
    else:
        # Moving down - shift others up
        db.query(WorkflowStage).filter(
            WorkflowStage.sort_order > old_order,
            WorkflowStage.sort_order <= new_order
        ).update({WorkflowStage.sort_order: WorkflowStage.sort_order - 1})
    
    stage.sort_order = new_order
    db.commit()
    
    return {"message": "Stage reordered successfully", "new_order": new_order}


# ==================== AGENT TYPE ENDPOINTS ====================

@router.get("/agent-types", response_model=List[AgentTypeResponse])
async def list_agent_types(
    include_inactive: bool = Query(False, description="Include inactive types"),
    stage: Optional[str] = Query(None, description="Filter by default stage"),
    db: Session = Depends(get_db)
):
    """
    List all agent types.
    
    Returns types ordered by sort_order.
    By default, only returns active types.
    """
    query = db.query(AgentTypeModel)
    
    if not include_inactive:
        query = query.filter(AgentTypeModel.is_active == True)
    
    if stage:
        query = query.filter(AgentTypeModel.default_stage == stage)
    
    types = query.order_by(AgentTypeModel.sort_order).all()
    
    return [AgentTypeResponse(**t.to_dict()) for t in types]


@router.get("/agent-types/{type_id}", response_model=AgentTypeResponse)
async def get_agent_type(
    type_id: UUID,
    db: Session = Depends(get_db)
):
    """Get an agent type by ID."""
    agent_type = db.query(AgentTypeModel).filter(AgentTypeModel.id == type_id).first()
    
    if not agent_type:
        raise HTTPException(status_code=404, detail="Agent type not found")
    
    return AgentTypeResponse(**agent_type.to_dict())


@router.get("/agent-types/by-name/{name}", response_model=AgentTypeResponse)
async def get_agent_type_by_name(
    name: str,
    db: Session = Depends(get_db)
):
    """Get an agent type by name."""
    agent_type = db.query(AgentTypeModel).filter(AgentTypeModel.name == name).first()
    
    if not agent_type:
        raise HTTPException(status_code=404, detail="Agent type not found")
    
    return AgentTypeResponse(**agent_type.to_dict())


@router.post("/agent-types", response_model=AgentTypeResponse)
async def create_agent_type(
    type_data: AgentTypeCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Create a new agent type.
    
    Admin only.
    """
    # Check for duplicate name
    existing = db.query(AgentTypeModel).filter(
        AgentTypeModel.name == type_data.name
    ).first()
    
    if existing:
        raise HTTPException(
            status_code=400, 
            detail=f"Agent type with name '{type_data.name}' already exists"
        )
    
    # Validate default_stage exists
    if type_data.default_stage:
        stage = db.query(WorkflowStage).filter(
            WorkflowStage.name == type_data.default_stage
        ).first()
        if not stage:
            raise HTTPException(
                status_code=400,
                detail=f"Stage '{type_data.default_stage}' not found"
            )
    
    # Create type
    agent_type = AgentTypeModel(
        **type_data.model_dump(),
        is_system=False
    )
    
    db.add(agent_type)
    db.commit()
    db.refresh(agent_type)
    
    return AgentTypeResponse(**agent_type.to_dict())


@router.put("/agent-types/{type_id}", response_model=AgentTypeResponse)
async def update_agent_type(
    type_id: UUID,
    type_data: AgentTypeUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Update an agent type.
    
    Admin only.
    """
    agent_type = db.query(AgentTypeModel).filter(AgentTypeModel.id == type_id).first()
    
    if not agent_type:
        raise HTTPException(status_code=404, detail="Agent type not found")
    
    # Update fields
    update_data = type_data.model_dump(exclude_unset=True)
    
    # Validate default_stage if provided
    if 'default_stage' in update_data and update_data['default_stage']:
        stage = db.query(WorkflowStage).filter(
            WorkflowStage.name == update_data['default_stage']
        ).first()
        if not stage:
            raise HTTPException(
                status_code=400,
                detail=f"Stage '{update_data['default_stage']}' not found"
            )
    
    for key, value in update_data.items():
        setattr(agent_type, key, value)
    
    db.commit()
    db.refresh(agent_type)
    
    return AgentTypeResponse(**agent_type.to_dict())


@router.delete("/agent-types/{type_id}")
async def delete_agent_type(
    type_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Delete an agent type (soft delete).
    
    Admin only. System types cannot be deleted.
    """
    agent_type = db.query(AgentTypeModel).filter(AgentTypeModel.id == type_id).first()
    
    if not agent_type:
        raise HTTPException(status_code=404, detail="Agent type not found")
    
    if agent_type.is_system:
        raise HTTPException(
            status_code=400, 
            detail="System agent types cannot be deleted"
        )
    
    # Soft delete
    agent_type.is_active = False
    db.commit()
    
    return {"message": "Agent type deactivated successfully"}


# ==================== SEED ENDPOINTS ====================

@router.post("/seed-defaults")
async def seed_default_stages(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Seed default workflow stages and agent types.
    
    Admin only. Use this to initialize or reset to defaults.
    """
    stages_created = 0
    types_created = 0
    
    # Seed workflow stages
    for stage_data in DEFAULT_WORKFLOW_STAGES:
        existing = db.query(WorkflowStage).filter(
            WorkflowStage.name == stage_data["name"]
        ).first()
        
        if not existing:
            stage = WorkflowStage(**stage_data, created_by=current_user.id)
            db.add(stage)
            stages_created += 1
    
    # Seed agent types
    for type_data in DEFAULT_AGENT_TYPES:
        existing = db.query(AgentTypeModel).filter(
            AgentTypeModel.name == type_data["name"]
        ).first()
        
        if not existing:
            agent_type = AgentTypeModel(**type_data)
            db.add(agent_type)
            types_created += 1
    
    db.commit()
    
    return {
        "message": "Defaults seeded successfully",
        "stages_created": stages_created,
        "types_created": types_created
    }
