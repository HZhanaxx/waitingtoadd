-- =====================================================
-- Migration: Add Dynamic Workflow Stages and Agent Types
-- Date: 2024-12
-- Description: Creates tables for dynamic workflow configuration
-- =====================================================

-- Create workflow_stages table
CREATE TABLE IF NOT EXISTS workflow_stages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(50) NOT NULL UNIQUE,
    display_name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(50),
    color VARCHAR(50),
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    is_system BOOLEAN DEFAULT FALSE,
    agent_type_filter VARCHAR(50),
    allowed_transitions JSONB,
    auto_advance BOOLEAN DEFAULT FALSE,
    requires_all_agents BOOLEAN DEFAULT FALSE,
    max_agents INTEGER,
    timeout_seconds INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by UUID
);

-- Create index on sort_order for efficient ordering
CREATE INDEX IF NOT EXISTS idx_workflow_stages_sort_order ON workflow_stages(sort_order);
CREATE INDEX IF NOT EXISTS idx_workflow_stages_is_active ON workflow_stages(is_active);

-- Create agent_types table
CREATE TABLE IF NOT EXISTS agent_types (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(50) NOT NULL UNIQUE,
    display_name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(50),
    color VARCHAR(50),
    default_stage VARCHAR(50),
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    is_system BOOLEAN DEFAULT FALSE,
    capabilities JSONB,
    default_config JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_agent_types_sort_order ON agent_types(sort_order);
CREATE INDEX IF NOT EXISTS idx_agent_types_is_active ON agent_types(is_active);
CREATE INDEX IF NOT EXISTS idx_agent_types_default_stage ON agent_types(default_stage);

-- =====================================================
-- Seed Default Workflow Stages
-- =====================================================

INSERT INTO workflow_stages (name, display_name, description, icon, color, sort_order, is_system, agent_type_filter, allowed_transitions)
VALUES
    ('triage', '分诊', '初始问诊和意图识别阶段', '🎯', '#3B82F6', 1, TRUE, 'triage', '["professional", "search"]'),
    ('professional', '专业', '专业领域数据收集阶段', '👨‍💼', '#10B981', 2, TRUE, 'domain', '["search", "analysis"]'),
    ('search', '搜索', '法条和案例检索阶段', '🔍', '#F59E0B', 3, TRUE, 'search', '["analysis"]'),
    ('analysis', '分析', '数据分析和推荐阶段', '📊', '#8B5CF6', 4, TRUE, 'analyzer', '["generation", "review"]'),
    ('generation', '生成', '文档和报告生成阶段', '📝', '#EC4899', 5, TRUE, 'generation', '["review", "completed"]'),
    ('review', '审核', '专业人员审核阶段', '✅', '#06B6D4', 6, TRUE, 'review', '["completed"]')
ON CONFLICT (name) DO UPDATE SET
    display_name = EXCLUDED.display_name,
    description = EXCLUDED.description,
    icon = EXCLUDED.icon,
    color = EXCLUDED.color,
    sort_order = EXCLUDED.sort_order,
    agent_type_filter = EXCLUDED.agent_type_filter,
    allowed_transitions = EXCLUDED.allowed_transitions,
    updated_at = CURRENT_TIMESTAMP;

-- =====================================================
-- Seed Default Agent Types
-- =====================================================

INSERT INTO agent_types (name, display_name, description, icon, default_stage, sort_order, is_system, capabilities)
VALUES
    ('triage', '分诊Agent', '初始问诊和意图识别', '🎯', 'triage', 1, TRUE, '["greeting", "intent_classification", "routing"]'),
    ('domain', '专业Agent', '领域特定变量收集', '👨‍💼', 'professional', 2, TRUE, '["data_collection", "validation", "domain_knowledge"]'),
    ('fetch', '获取Agent', '对话获取和信息提取', '💬', 'professional', 3, TRUE, '["conversation", "extraction", "clarification"]'),
    ('search', '搜索Agent', '法条和案例检索', '🔍', 'search', 4, TRUE, '["law_search", "case_search", "rag"]'),
    ('analyzer', '分析Agent', '数据分析和推荐', '📊', 'analysis', 5, TRUE, '["analysis", "recommendation", "risk_assessment"]'),
    ('generation', '生成Agent', '文档和报告生成', '📝', 'generation', 6, TRUE, '["document_generation", "template_filling", "formatting"]'),
    ('custom', '自定义Agent', '自定义功能Agent', '⚙️', NULL, 99, TRUE, '[]')
ON CONFLICT (name) DO UPDATE SET
    display_name = EXCLUDED.display_name,
    description = EXCLUDED.description,
    icon = EXCLUDED.icon,
    default_stage = EXCLUDED.default_stage,
    sort_order = EXCLUDED.sort_order,
    capabilities = EXCLUDED.capabilities,
    updated_at = CURRENT_TIMESTAMP;

-- =====================================================
-- Add workflow_stage_id to agents table (optional FK)
-- =====================================================

-- Add column if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'agents' AND column_name = 'workflow_stage_id'
    ) THEN
        ALTER TABLE agents ADD COLUMN workflow_stage_id UUID;
        ALTER TABLE agents ADD CONSTRAINT fk_agents_workflow_stage 
            FOREIGN KEY (workflow_stage_id) REFERENCES workflow_stages(id) ON DELETE SET NULL;
    END IF;
END $$;

-- =====================================================
-- Create updated_at trigger function
-- =====================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply trigger to workflow_stages
DROP TRIGGER IF EXISTS update_workflow_stages_updated_at ON workflow_stages;
CREATE TRIGGER update_workflow_stages_updated_at
    BEFORE UPDATE ON workflow_stages
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Apply trigger to agent_types
DROP TRIGGER IF EXISTS update_agent_types_updated_at ON agent_types;
CREATE TRIGGER update_agent_types_updated_at
    BEFORE UPDATE ON agent_types
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
