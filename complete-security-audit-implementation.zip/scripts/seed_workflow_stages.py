"""
Seed Workflow Stages and Agent Types
=====================================

Run this script to initialize the workflow_stages and agent_types tables
with default data.

Usage:
    python scripts/seed_workflow_stages.py
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy.orm import Session
from database import engine, Base
from models.workflow_stage import (
    WorkflowStage, 
    AgentType,
    DEFAULT_WORKFLOW_STAGES, 
    DEFAULT_AGENT_TYPES
)


def seed_workflow_stages(db: Session) -> int:
    """Seed default workflow stages."""
    created = 0
    
    for stage_data in DEFAULT_WORKFLOW_STAGES:
        existing = db.query(WorkflowStage).filter(
            WorkflowStage.name == stage_data["name"]
        ).first()
        
        if existing:
            print(f"  Stage '{stage_data['name']}' already exists, updating...")
            for key, value in stage_data.items():
                if key != "name":  # Don't update name
                    setattr(existing, key, value)
        else:
            print(f"  Creating stage '{stage_data['name']}'...")
            stage = WorkflowStage(**stage_data)
            db.add(stage)
            created += 1
    
    return created


def seed_agent_types(db: Session) -> int:
    """Seed default agent types."""
    created = 0
    
    for type_data in DEFAULT_AGENT_TYPES:
        existing = db.query(AgentType).filter(
            AgentType.name == type_data["name"]
        ).first()
        
        if existing:
            print(f"  Agent type '{type_data['name']}' already exists, updating...")
            for key, value in type_data.items():
                if key != "name":  # Don't update name
                    setattr(existing, key, value)
        else:
            print(f"  Creating agent type '{type_data['name']}'...")
            agent_type = AgentType(**type_data)
            db.add(agent_type)
            created += 1
    
    return created


def main():
    print("=" * 60)
    print("Seeding Workflow Stages and Agent Types")
    print("=" * 60)
    
    # Create tables if they don't exist
    print("\n1. Creating tables if needed...")
    Base.metadata.create_all(bind=engine)
    
    # Seed data
    from database import SessionLocal
    db = SessionLocal()
    
    try:
        print("\n2. Seeding workflow stages...")
        stages_created = seed_workflow_stages(db)
        
        print("\n3. Seeding agent types...")
        types_created = seed_agent_types(db)
        
        db.commit()
        
        print("\n" + "=" * 60)
        print("SEEDING COMPLETE")
        print("=" * 60)
        print(f"  Workflow stages created: {stages_created}")
        print(f"  Agent types created: {types_created}")
        
        # Show current state
        print("\nCurrent workflow stages:")
        stages = db.query(WorkflowStage).order_by(WorkflowStage.sort_order).all()
        for s in stages:
            status = "✓" if s.is_active else "✗"
            print(f"  {status} {s.sort_order}. {s.icon} {s.display_name} ({s.name})")
        
        print("\nCurrent agent types:")
        types = db.query(AgentType).order_by(AgentType.sort_order).all()
        for t in types:
            status = "✓" if t.is_active else "✗"
            stage = t.default_stage or "none"
            print(f"  {status} {t.icon} {t.display_name} ({t.name}) -> {stage}")
        
    except Exception as e:
        db.rollback()
        print(f"\nERROR: {e}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    main()
