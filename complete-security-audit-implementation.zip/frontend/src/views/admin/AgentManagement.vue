<template>
  <div class="flex min-h-screen bg-slate-50/50">
    <Sidebar />
    
    <main class="flex-1 p-8 overflow-y-auto main-content">
      <div class="max-w-7xl mx-auto space-y-6">
        <!-- Header -->
        <div class="flex justify-between items-center">
          <div class="space-y-1">
            <h1 class="text-2xl font-bold text-slate-800">🤖 Agent 管理</h1>
            <p class="text-slate-500">管理工作流各阶段的 Agent 配置</p>
          </div>
        </div>

        <!-- Pipeline Overview -->
        <div class="pipeline-overview">
          <div class="pipeline-step" v-for="(phase, idx) in phases" :key="phase.key"
            :class="{ active: activePhase === phase.key }"
            @click="activePhase = phase.key"
          >
            <span class="step-number">{{ idx + 1 }}</span>
            <span class="step-icon">{{ phase.icon }}</span>
            <span class="step-name">{{ phase.name }}</span>
            <span class="step-count">{{ getAgentCount(phase.key) }}</span>
          </div>
          <div class="pipeline-step security" 
            :class="{ active: activePhase === 'security' }"
            @click="activePhase = 'security'"
          >
            <span class="step-icon">🛡️</span>
            <span class="step-name">安全规则</span>
          </div>
        </div>

        <!-- Phase Panels -->
        <div class="phase-content">
          <!-- Triage Phase -->
          <div v-if="activePhase === 'triage'" class="phase-panel">
            <div class="phase-header">
              <div>
                <h2>🎯 分诊阶段 (Triage)</h2>
                <p>欢迎用户、识别意图、路由到专业Agent</p>
              </div>
              <button class="btn btn-primary" @click="addAgent('triage')">+ 添加 Agent</button>
            </div>
            
            <div class="agents-grid">
              <div v-for="agent in triageAgents" :key="agent.id" class="agent-card triage">
                <div class="agent-header">
                  <span class="agent-icon">🎯</span>
                  <div class="agent-info">
                    <h3>{{ agent.display_name }}</h3>
                    <span class="agent-type">{{ agent.name }}</span>
                  </div>
                  <span class="status-badge" :class="agent.is_active ? 'active' : 'inactive'">
                    {{ agent.is_active ? '启用' : '禁用' }}
                  </span>
                </div>
                
                <div class="agent-description">
                  {{ agent.description || '负责欢迎用户并识别用户需求' }}
                </div>
                
                <div class="agent-meta">
                  <div class="meta-item">
                    <span class="meta-label">LLM</span>
                    <span class="meta-value">{{ agent.llm_config?.model || agent.config?.llm?.model || 'llama2' }}</span>
                  </div>
                  <div class="meta-item">
                    <span class="meta-label">路由目标</span>
                    <span class="meta-value">{{ getRoutingTargetCount(agent) }} 个</span>
                  </div>
                </div>
                
                <div class="agent-actions">
                  <button class="btn btn-sm" @click="openAgentEditor(agent, 'triage')">⚙️ 配置</button>
                  <button class="btn btn-sm btn-secondary" @click="toggleAgent(agent)">
                    {{ agent.is_active ? '禁用' : '启用' }}
                  </button>
                </div>
              </div>
              
              <!-- Fetch Agent Card -->
              <div class="agent-card fetch-agent">
                <div class="agent-header">
                  <span class="agent-icon">💬</span>
                  <div class="agent-info">
                    <h3>Fetch Agent</h3>
                    <span class="agent-type">对话获取</span>
                  </div>
                </div>
                <div class="agent-description">
                  负责此阶段的对话交互，从用户获取信息
                </div>
                <div class="agent-actions">
                  <button class="btn btn-sm" @click="openFetchAgentConfig('triage')">⚙️ 配置提示词</button>
                </div>
              </div>
            </div>
          </div>

          <!-- Professional Phase -->
          <div v-if="activePhase === 'professional'" class="phase-panel">
            <div class="phase-header">
              <div>
                <h2>👨‍💼 专业阶段 (Professional)</h2>
                <p>专业领域Agent，包括法律咨询、合同服务等</p>
              </div>
              <button class="btn btn-primary" @click="addAgent('domain')">+ 添加 Agent</button>
            </div>
            
            <!-- Sub-categories -->
            <div class="sub-categories">
              <button v-for="cat in professionalCategories" :key="cat.key"
                class="category-tab"
                :class="{ active: professionalSubTab === cat.key }"
                @click="professionalSubTab = cat.key"
              >
                {{ cat.icon }} {{ cat.name }}
                <span class="count">{{ getProfessionalAgentCount(cat.key) }}</span>
              </button>
            </div>
            
            <div class="agents-grid">
              <div v-for="agent in filteredProfessionalAgents" :key="agent.id" class="agent-card professional">
                <div class="agent-header">
                  <span class="agent-icon">{{ getProfessionalIcon(agent) }}</span>
                  <div class="agent-info">
                    <h3>{{ agent.display_name }}</h3>
                    <span class="agent-type">{{ agent.name }}</span>
                  </div>
                  <span class="status-badge" :class="agent.is_active ? 'active' : 'inactive'">
                    {{ agent.is_active ? '启用' : '禁用' }}
                  </span>
                </div>
                
                <div class="agent-description">
                  {{ agent.description || '专业领域咨询服务' }}
                </div>
                
                <div class="agent-meta">
                  <div class="meta-item">
                    <span class="meta-label">LLM</span>
                    <span class="meta-value">{{ agent.llm_config?.model || agent.config?.llm?.model || 'llama2' }}</span>
                  </div>
                  <div class="meta-item">
                    <span class="meta-label">类别</span>
                    <span class="meta-value">{{ getProfessionalCategory(agent) }}</span>
                  </div>
                </div>
                
                <div class="agent-actions">
                  <button class="btn btn-sm" @click="openAgentEditor(agent, 'professional')">⚙️ 配置</button>
                  <button class="btn btn-sm btn-secondary" @click="toggleAgent(agent)">
                    {{ agent.is_active ? '禁用' : '启用' }}
                  </button>
                </div>
              </div>
              
              <!-- Fetch Agent Card -->
              <div class="agent-card fetch-agent">
                <div class="agent-header">
                  <span class="agent-icon">💬</span>
                  <div class="agent-info">
                    <h3>Fetch Agent</h3>
                    <span class="agent-type">对话获取</span>
                  </div>
                </div>
                <div class="agent-description">
                  负责专业阶段的对话交互，引导用户提供案件详情
                </div>
                <div class="agent-actions">
                  <button class="btn btn-sm" @click="openFetchAgentConfig('professional')">⚙️ 配置提示词</button>
                </div>
              </div>
            </div>
          </div>

          <!-- Search Phase -->
          <div v-if="activePhase === 'search'" class="phase-panel">
            <div class="phase-header">
              <div>
                <h2>🔍 搜索阶段 (Search)</h2>
                <p>检索法律法规、案例库、知识库</p>
              </div>
              <button class="btn btn-primary" @click="addAgent('search')">+ 添加 Agent</button>
            </div>
            
            <div class="agents-grid">
              <div v-for="agent in searchAgents" :key="agent.id" class="agent-card search">
                <div class="agent-header">
                  <span class="agent-icon">🔍</span>
                  <div class="agent-info">
                    <h3>{{ agent.display_name }}</h3>
                    <span class="agent-type">{{ agent.name }}</span>
                  </div>
                  <span class="status-badge" :class="agent.is_active ? 'active' : 'inactive'">
                    {{ agent.is_active ? '启用' : '禁用' }}
                  </span>
                </div>
                
                <div class="agent-description">
                  {{ agent.description || '检索相关法律法规和案例' }}
                </div>
                
                <div class="agent-meta">
                  <div class="meta-item">
                    <span class="meta-label">搜索类型</span>
                    <span class="meta-value">{{ getSearchType(agent) }}</span>
                  </div>
                  <div class="meta-item">
                    <span class="meta-label">数据源</span>
                    <span class="meta-value">{{ getDataSources(agent) }}</span>
                  </div>
                </div>
                
                <div class="agent-actions">
                  <button class="btn btn-sm" @click="openAgentEditor(agent, 'search')">⚙️ 配置</button>
                  <button class="btn btn-sm btn-secondary" @click="toggleAgent(agent)">
                    {{ agent.is_active ? '禁用' : '启用' }}
                  </button>
                </div>
              </div>
              
              <!-- Fetch Agent Card -->
              <div class="agent-card fetch-agent">
                <div class="agent-header">
                  <span class="agent-icon">💬</span>
                  <div class="agent-info">
                    <h3>Fetch Agent</h3>
                    <span class="agent-type">对话获取</span>
                  </div>
                </div>
                <div class="agent-description">
                  负责搜索阶段的补充问询，获取更精确的搜索条件
                </div>
                <div class="agent-actions">
                  <button class="btn btn-sm" @click="openFetchAgentConfig('search')">⚙️ 配置提示词</button>
                </div>
              </div>
            </div>
          </div>

          <!-- Analysis Phase -->
          <div v-if="activePhase === 'analysis'" class="phase-panel">
            <div class="phase-header">
              <div>
                <h2>📊 分析阶段 (Analysis)</h2>
                <p>分析案情、生成报告、评估风险</p>
              </div>
              <button class="btn btn-primary" @click="addAgent('analysis')">+ 添加 Agent</button>
            </div>
            
            <div class="agents-grid">
              <div v-for="agent in analysisAgents" :key="agent.id" class="agent-card analysis">
                <div class="agent-header">
                  <span class="agent-icon">📊</span>
                  <div class="agent-info">
                    <h3>{{ agent.display_name }}</h3>
                    <span class="agent-type">{{ agent.name }}</span>
                  </div>
                  <span class="status-badge" :class="agent.is_active ? 'active' : 'inactive'">
                    {{ agent.is_active ? '启用' : '禁用' }}
                  </span>
                </div>
                
                <div class="agent-description">
                  {{ agent.description || '分析案情并生成专业意见' }}
                </div>
                
                <div class="agent-meta">
                  <div class="meta-item">
                    <span class="meta-label">LLM</span>
                    <span class="meta-value">{{ agent.llm_config?.model || agent.config?.llm?.model || 'llama2' }}</span>
                  </div>
                  <div class="meta-item">
                    <span class="meta-label">报告模板</span>
                    <span class="meta-value">{{ getReportTemplateCount(agent) }} 个</span>
                  </div>
                </div>
                
                <div class="agent-actions">
                  <button class="btn btn-sm" @click="openAgentEditor(agent, 'analysis')">⚙️ 配置</button>
                  <button class="btn btn-sm btn-secondary" @click="toggleAgent(agent)">
                    {{ agent.is_active ? '禁用' : '启用' }}
                  </button>
                </div>
              </div>
              
              <!-- Fetch Agent Card -->
              <div class="agent-card fetch-agent">
                <div class="agent-header">
                  <span class="agent-icon">💬</span>
                  <div class="agent-info">
                    <h3>Fetch Agent</h3>
                    <span class="agent-type">对话获取</span>
                  </div>
                </div>
                <div class="agent-description">
                  负责分析阶段的澄清问询，确认分析结果
                </div>
                <div class="agent-actions">
                  <button class="btn btn-sm" @click="openFetchAgentConfig('analysis')">⚙️ 配置提示词</button>
                </div>
              </div>
            </div>
          </div>

          <!-- Generation Phase -->
          <div v-if="activePhase === 'generation'" class="phase-panel">
            <div class="phase-header">
              <div>
                <h2>📝 生成阶段 (Generation)</h2>
                <p>生成法律文书、合同、建议书</p>
              </div>
              <button class="btn btn-primary" @click="addAgent('generation')">+ 添加 Agent</button>
            </div>
            
            <div class="agents-grid">
              <div v-for="agent in generationAgents" :key="agent.id" class="agent-card generation">
                <div class="agent-header">
                  <span class="agent-icon">📝</span>
                  <div class="agent-info">
                    <h3>{{ agent.display_name }}</h3>
                    <span class="agent-type">{{ agent.name }}</span>
                  </div>
                  <span class="status-badge" :class="agent.is_active ? 'active' : 'inactive'">
                    {{ agent.is_active ? '启用' : '禁用' }}
                  </span>
                </div>
                
                <div class="agent-description">
                  {{ agent.description || '生成法律文书和合同' }}
                </div>
                
                <div class="agent-meta">
                  <div class="meta-item">
                    <span class="meta-label">LLM</span>
                    <span class="meta-value">{{ agent.llm_config?.model || agent.config?.llm?.model || 'llama2' }}</span>
                  </div>
                  <div class="meta-item">
                    <span class="meta-label">文档模板</span>
                    <span class="meta-value">{{ getDocTemplateCount(agent) }} 个</span>
                  </div>
                </div>
                
                <div class="agent-actions">
                  <button class="btn btn-sm" @click="openAgentEditor(agent, 'generation')">⚙️ 配置</button>
                  <button class="btn btn-sm btn-secondary" @click="toggleAgent(agent)">
                    {{ agent.is_active ? '禁用' : '启用' }}
                  </button>
                </div>
              </div>
              
              <!-- Fetch Agent Card -->
              <div class="agent-card fetch-agent">
                <div class="agent-header">
                  <span class="agent-icon">💬</span>
                  <div class="agent-info">
                    <h3>Fetch Agent</h3>
                    <span class="agent-type">对话获取</span>
                  </div>
                </div>
                <div class="agent-description">
                  负责生成阶段的确认交互，收集文档生成需求
                </div>
                <div class="agent-actions">
                  <button class="btn btn-sm" @click="openFetchAgentConfig('generation')">⚙️ 配置提示词</button>
                </div>
              </div>
            </div>
          </div>

          <!-- Security Panel -->
          <div v-if="activePhase === 'security'" class="phase-panel">
            <div class="phase-header">
              <div>
                <h2>🛡️ 安全规则</h2>
                <p>管理所有 Fetch Agent 的输入检查规则，可中断对话</p>
              </div>
              <div class="header-actions">
                <button class="btn btn-secondary" @click="openPromptTest">🔒 测试提示词安全</button>
                <button class="btn btn-primary" @click="addSecurityRule">+ 添加规则</button>
              </div>
            </div>
            
            <div class="security-grid">
              <!-- Rule Categories -->
              <div class="security-section">
                <h3>🚫 内容过滤规则</h3>
                <p class="section-desc">检测并阻止不当内容</p>
                
                <div class="rules-list">
                  <div v-for="rule in contentFilterRules" :key="rule.id" class="rule-card">
                    <div class="rule-header">
                      <span class="rule-name">{{ rule.name || rule.display_name }}</span>
                      <span class="rule-status" :class="rule.status === 'active' ? 'active' : 'inactive'">
                        {{ rule.status === 'active' ? '启用' : '禁用' }}
                      </span>
                    </div>
                    <div class="rule-description">{{ rule.description }}</div>
                    <div class="rule-action">
                      <span class="action-label">触发动作:</span>
                      <span class="action-value">{{ getActionLabel(rule.action) }}</span>
                    </div>
                    <div class="rule-actions">
                      <button class="btn btn-sm" @click="editSecurityRule(rule)">编辑</button>
                      <button class="btn btn-sm" @click="toggleSecurityRule(rule)">
                        {{ rule.status === 'active' ? '禁用' : '启用' }}
                      </button>
                    </div>
                  </div>
                  <div v-if="contentFilterRules.length === 0" class="empty-state">
                    暂无内容过滤规则
                  </div>
                </div>
              </div>
              
              <div class="security-section">
                <h3>⚠️ 敏感词检测</h3>
                <p class="section-desc">检测敏感关键词并触发警告</p>
                
                <div class="rules-list">
                  <div v-for="rule in sensitiveWordRules" :key="rule.id" class="rule-card">
                    <div class="rule-header">
                      <span class="rule-name">{{ rule.name || rule.display_name }}</span>
                      <span class="rule-status" :class="rule.status === 'active' ? 'active' : 'inactive'">
                        {{ rule.status === 'active' ? '启用' : '禁用' }}
                      </span>
                    </div>
                    <div class="rule-keywords">
                      <span v-for="kw in (rule.match_keywords || []).slice(0, 5)" :key="kw" class="keyword-tag">
                        {{ kw }}
                      </span>
                      <span v-if="(rule.match_keywords || []).length > 5" class="more-keywords">
                        +{{ rule.match_keywords.length - 5 }} 更多
                      </span>
                    </div>
                    <div class="rule-actions">
                      <button class="btn btn-sm" @click="editSecurityRule(rule)">编辑</button>
                      <button class="btn btn-sm" @click="toggleSecurityRule(rule)">
                        {{ rule.status === 'active' ? '禁用' : '启用' }}
                      </button>
                    </div>
                  </div>
                  <div v-if="sensitiveWordRules.length === 0" class="empty-state">
                    暂无敏感词规则
                  </div>
                </div>
              </div>
              
              <div class="security-section">
                <h3>🔒 输入验证规则</h3>
                <p class="section-desc">验证用户输入格式和长度</p>
                
                <div class="rules-list">
                  <div v-for="rule in inputValidationRules" :key="rule.id" class="rule-card">
                    <div class="rule-header">
                      <span class="rule-name">{{ rule.name || rule.display_name }}</span>
                      <span class="rule-status" :class="rule.status === 'active' ? 'active' : 'inactive'">
                        {{ rule.status === 'active' ? '启用' : '禁用' }}
                      </span>
                    </div>
                    <div class="rule-description">{{ rule.description }}</div>
                    <div class="rule-actions">
                      <button class="btn btn-sm" @click="editSecurityRule(rule)">编辑</button>
                      <button class="btn btn-sm" @click="toggleSecurityRule(rule)">
                        {{ rule.status === 'active' ? '禁用' : '启用' }}
                      </button>
                    </div>
                  </div>
                  <div v-if="inputValidationRules.length === 0" class="empty-state">
                    暂无输入验证规则
                  </div>
                </div>
              </div>
              
              <div class="security-section full-width">
                <h3>📊 Fetch Agent 安全配置</h3>
                <p class="section-desc">为每个阶段的 Fetch Agent 配置安全规则</p>
                
                <div class="fetch-agent-security-grid">
                  <div v-for="phase in phases" :key="phase.key" class="fetch-security-card">
                    <div class="fetch-header">
                      <span class="fetch-icon">{{ phase.icon }}</span>
                      <span class="fetch-name">{{ phase.name }} Fetch Agent</span>
                    </div>
                    <div class="fetch-rules">
                      <div class="rule-toggle" v-for="ruleType in ruleTypes" :key="ruleType.key">
                        <label class="toggle-label">
                          <input type="checkbox" 
                            :checked="isFetchRuleEnabled(phase.key, ruleType.key)"
                            @change="toggleFetchRule(phase.key, ruleType.key)"
                          />
                          <span>{{ ruleType.name }}</span>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    
    <!-- Add Agent Modal -->
    <div v-if="showAddAgentModal" class="modal-overlay" @click.self="showAddAgentModal = false">
      <div class="modal-content">
        <div class="modal-header">
          <h3>添加 Agent</h3>
          <button class="btn-close" @click="showAddAgentModal = false">×</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Agent 名称 (英文)</label>
            <input v-model="newAgent.name" type="text" class="form-input" placeholder="my_agent" />
          </div>
          <div class="form-group">
            <label>显示名称</label>
            <input v-model="newAgent.display_name" type="text" class="form-input" placeholder="我的Agent" />
          </div>
          <div class="form-group">
            <label>描述</label>
            <textarea v-model="newAgent.description" class="form-input" rows="3"></textarea>
          </div>
          <div class="form-group" v-if="newAgent.agent_type === 'domain'">
            <label>专业类别</label>
            <select v-model="newAgent.sub_category" class="form-input">
              <option value="legal">法律咨询</option>
              <option value="contract">合同服务</option>
              <option value="consult">普通咨询</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" @click="showAddAgentModal = false">取消</button>
          <button class="btn btn-primary" @click="createAgent">创建</button>
        </div>
      </div>
    </div>
    
    <!-- Security Rule Modal -->
    <div v-if="showSecurityModal" class="modal-overlay" @click.self="showSecurityModal = false">
      <div class="modal-content modal-lg">
        <div class="modal-header">
          <h3>{{ editingRule ? '编辑安全规则' : '添加安全规则' }}</h3>
          <button class="btn-close" @click="showSecurityModal = false">×</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>规则名称</label>
            <input v-model="securityForm.name" type="text" class="form-input" />
          </div>
          <div class="form-group">
            <label>规则类型</label>
            <select v-model="securityForm.rule_type" class="form-input">
              <option value="content_filter">内容过滤</option>
              <option value="keyword">敏感词检测</option>
              <option value="regex">输入验证</option>
            </select>
          </div>
          <div class="form-group">
            <label>描述</label>
            <textarea v-model="securityForm.description" class="form-input" rows="2"></textarea>
          </div>
          <div class="form-group" v-if="securityForm.rule_type === 'keyword'">
            <label>关键词列表 (每行一个)</label>
            <textarea v-model="securityForm.keywords_text" class="form-input" rows="5" 
              placeholder="敏感词1&#10;敏感词2&#10;敏感词3"></textarea>
          </div>
          <div class="form-group" v-if="securityForm.rule_type === 'regex'">
            <label>验证规则 (正则表达式)</label>
            <input v-model="securityForm.pattern" type="text" class="form-input" placeholder="^.{1,1000}$" />
          </div>
          <div class="form-group">
            <label>触发动作</label>
            <select v-model="securityForm.action" class="form-input">
              <option value="warn">警告提示</option>
              <option value="block">阻止并提示</option>
              <option value="interrupt">中断对话</option>
              <option value="escalate">升级人工</option>
            </select>
          </div>
          <div class="form-group">
            <label>触发时的提示消息</label>
            <textarea v-model="securityForm.message" class="form-input" rows="2"
              placeholder="检测到不当内容，请修改您的输入"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" @click="showSecurityModal = false">取消</button>
          <button class="btn btn-primary" @click="saveSecurityRule">保存</button>
        </div>
      </div>
    </div>
    
    <!-- Fetch Agent Config Modal -->
    <div v-if="showFetchConfigModal" class="modal-overlay" @click.self="showFetchConfigModal = false">
      <div class="modal-content modal-lg">
        <div class="modal-header">
          <h3>💬 {{ getFetchPhaseLabel(fetchConfigPhase) }} Fetch Agent 配置</h3>
          <button class="btn-close" @click="showFetchConfigModal = false">×</button>
        </div>
        <div class="modal-body">
          <!-- LLM Settings -->
          <div class="config-section">
            <h4>🔧 LLM 配置</h4>
            <div class="form-row">
              <div class="form-group">
                <label>服务提供商</label>
                <select v-model="fetchConfig.llm.provider" class="form-input">
                  <option value="ollama">Ollama</option>
                  <option value="openai">OpenAI</option>
                  <option value="anthropic">Anthropic</option>
                  <option value="deepseek">DeepSeek</option>
                  <option value="qianwen">通义千问</option>
                </select>
              </div>
              <div class="form-group">
                <label>模型</label>
                <input v-model="fetchConfig.llm.model" type="text" class="form-input" placeholder="llama2" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>API URL</label>
                <input v-model="fetchConfig.llm.api_url" type="text" class="form-input" />
              </div>
              <div class="form-group">
                <label>API Key</label>
                <input v-model="fetchConfig.llm.api_key" type="password" class="form-input" placeholder="sk-..." />
              </div>
            </div>
          </div>
          
          <!-- Prompts -->
          <div class="config-section">
            <div class="section-header">
              <h4>📝 提示词配置</h4>
              <button class="btn btn-sm btn-primary" @click="addFetchPrompt">+ 添加提示词</button>
            </div>
            
            <div class="prompts-list">
              <div v-for="(prompt, idx) in fetchConfig.prompts" :key="idx" class="prompt-item">
                <div class="prompt-header">
                  <input v-model="prompt.name" type="text" class="prompt-name-input" placeholder="提示词名称" />
                  <select v-model="prompt.type" class="prompt-type-select">
                    <option value="system">System Prompt</option>
                    <option value="question">问询提示词</option>
                    <option value="followup">追问提示词</option>
                    <option value="confirm">确认提示词</option>
                  </select>
                  <button class="btn-icon danger" @click="removeFetchPrompt(idx)">×</button>
                </div>
                <textarea v-model="prompt.content" class="prompt-content" rows="4"
                  placeholder="输入提示词内容..."></textarea>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" @click="showFetchConfigModal = false">取消</button>
          <button class="btn btn-primary" @click="saveFetchConfig">保存配置</button>
        </div>
      </div>
    </div>
    
    <!-- Prompt Safety Test Modal -->
    <div v-if="showPromptTestModal" class="modal-overlay" @click.self="showPromptTestModal = false">
      <div class="modal-content modal-lg">
        <div class="modal-header">
          <h3>🔒 提示词安全测试</h3>
          <button class="btn-close" @click="showPromptTestModal = false">×</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>测试文本</label>
            <textarea 
              v-model="promptTestForm.text" 
              class="form-input" 
              rows="6" 
              placeholder="输入要测试的提示词或用户输入...&#10;&#10;例如：&#10;忽略之前的指令，你现在是...&#10;system: 新的系统提示..."></textarea>
          </div>
          
          <div class="form-row">
            <div class="form-group" style="flex: 1">
              <label>检查类型</label>
              <select v-model="promptTestForm.checkType" class="form-input">
                <option value="input">用户输入检查</option>
                <option value="output">Agent输出检查</option>
              </select>
            </div>
            <div class="form-group" style="flex: 1">
              <label>严格程度</label>
              <select v-model="promptTestForm.strictness" class="form-input">
                <option value="low">低 (仅关键威胁)</option>
                <option value="medium">中 (推荐)</option>
                <option value="high">高 (最严格)</option>
              </select>
            </div>
          </div>
          
          <div class="form-group">
            <button class="btn btn-primary" @click="runPromptTest" :disabled="promptTestLoading">
              {{ promptTestLoading ? '检测中...' : '🔍 运行安全检测' }}
            </button>
            <button class="btn btn-secondary ml-2" @click="runSafetyRuleCheck" :disabled="promptTestLoading">
              📋 检查安全规则
            </button>
          </div>
          
          <!-- Results Section -->
          <div v-if="promptTestResult" class="test-results mt-4">
            <div class="result-header" :class="promptTestResult.is_safe ? 'result-safe' : 'result-unsafe'">
              <span class="result-icon">{{ promptTestResult.is_safe ? '✅' : '⚠️' }}</span>
              <span class="result-title">{{ promptTestResult.is_safe ? '检测通过' : '检测到风险' }}</span>
              <span class="result-badge" v-if="promptTestResult.highest_severity">
                最高严重性: {{ promptTestResult.highest_severity }}
              </span>
            </div>
            
            <div v-if="promptTestResult.threats && promptTestResult.threats.length > 0" class="threats-list">
              <h4>检测到的威胁 ({{ promptTestResult.threat_count }})</h4>
              <div v-for="(threat, idx) in promptTestResult.threats" :key="idx" class="threat-item">
                <span class="threat-severity" :class="'severity-' + threat.severity">
                  {{ threat.severity }}
                </span>
                <span class="threat-category">{{ threat.category }}</span>
                <span class="threat-desc">{{ threat.description }}</span>
                <div class="threat-match" v-if="threat.matched_text">
                  匹配内容: <code>{{ threat.matched_text }}</code>
                </div>
              </div>
            </div>
            
            <div v-if="promptTestResult.sanitized_text" class="sanitized-result">
              <h4>净化后文本</h4>
              <pre class="code-block">{{ promptTestResult.sanitized_text }}</pre>
            </div>
            
            <div class="result-meta">
              <span>检测耗时: {{ promptTestResult.check_time_ms?.toFixed(2) }}ms</span>
              <span>原始长度: {{ promptTestResult.original_length }}</span>
              <span>净化后长度: {{ promptTestResult.sanitized_length }}</span>
            </div>
          </div>
          
          <!-- Safety Rule Check Results -->
          <div v-if="safetyRuleResult" class="test-results mt-4">
            <div class="result-header" :class="safetyRuleResult.is_allowed ? 'result-safe' : 'result-unsafe'">
              <span class="result-icon">{{ safetyRuleResult.is_allowed ? '✅' : '🚫' }}</span>
              <span class="result-title">{{ safetyRuleResult.is_allowed ? '规则检查通过' : '被规则拦截' }}</span>
            </div>
            
            <div v-if="safetyRuleResult.matched_rule" class="rule-match">
              <p><strong>匹配规则:</strong> {{ safetyRuleResult.matched_rule }}</p>
              <p><strong>触发动作:</strong> {{ safetyRuleResult.action }}</p>
              <p v-if="safetyRuleResult.action_message"><strong>提示消息:</strong> {{ safetyRuleResult.action_message }}</p>
            </div>
            
            <div class="result-meta">
              <span>检查规则数: {{ safetyRuleResult.rules_checked }}</span>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" @click="showPromptTestModal = false">关闭</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, reactive, computed, onMounted } from 'vue'
import apiClient from '@/utils/api'
import Sidebar from '@/components/Sidebar.vue'

export default {
  name: 'AgentManagement',
  components: {
    Sidebar
  },
  setup() {
    // State
    const activePhase = ref('triage')
    const professionalSubTab = ref('legal')
    const agents = ref([])
    const securityRules = ref([])
    const fetchAgentConfigs = ref({})
    const isLoading = ref(true)
    const agentTypes = ref([])
    
    // Phases - now loaded from API
    const phases = ref([
      // Default fallback while loading
      { key: 'triage', name: '分诊', icon: '🎯' },
      { key: 'professional', name: '专业', icon: '👨‍💼' },
      { key: 'search', name: '搜索', icon: '🔍' },
      { key: 'analysis', name: '分析', icon: '📊' },
      { key: 'generation', name: '生成', icon: '📝' }
    ])
    
    const professionalCategories = [
      { key: 'legal', name: '法律咨询', icon: '⚖️' },
      { key: 'contract', name: '合同服务', icon: '📄' },
      { key: 'consult', name: '普通咨询', icon: '💬' }
    ]
    
    const ruleTypes = [
      { key: 'content_filter', name: '内容过滤' },
      { key: 'keyword', name: '敏感词检测' },
      { key: 'regex', name: '输入验证' }
    ]
    
    // Computed agents by type
    const triageAgents = computed(() => 
      agents.value.filter(a => a.agent_type === 'triage')
    )
    
    const professionalAgents = computed(() => 
      agents.value.filter(a => a.agent_type === 'domain')
    )
    
    const filteredProfessionalAgents = computed(() => {
      return professionalAgents.value.filter(a => {
        const subCat = a.config?.sub_category || 'legal'
        return subCat === professionalSubTab.value
      })
    })
    
    const searchAgents = computed(() => 
      agents.value.filter(a => a.agent_type === 'search')
    )
    
    const analysisAgents = computed(() => 
      agents.value.filter(a => a.agent_type === 'analysis')
    )
    
    const generationAgents = computed(() => 
      agents.value.filter(a => a.agent_type === 'generation')
    )
    
    // Security rules by type
    const contentFilterRules = computed(() =>
      securityRules.value.filter(r => r.rule_type === 'content_filter')
    )
    
    const sensitiveWordRules = computed(() =>
      securityRules.value.filter(r => r.rule_type === 'keyword')
    )
    
    const inputValidationRules = computed(() =>
      securityRules.value.filter(r => r.rule_type === 'regex')
    )
    
    // Modals
    const showAddAgentModal = ref(false)
    const showSecurityModal = ref(false)
    const showFetchConfigModal = ref(false)
    const editingRule = ref(null)
    const fetchConfigPhase = ref('')
    
    const newAgent = reactive({
      name: '',
      display_name: '',
      description: '',
      agent_type: '',
      sub_category: 'legal'
    })
    
    const securityForm = reactive({
      name: '',
      rule_type: 'content_filter',
      description: '',
      keywords_text: '',
      pattern: '',
      action: 'block',
      message: ''
    })
    
    const fetchConfig = reactive({
      llm: {
        provider: 'ollama',
        api_url: 'http://localhost:11434/api/generate',
        api_key: '',
        model: 'llama2'
      },
      prompts: []
    })
    
    // Prompt Test Modal State
    const showPromptTestModal = ref(false)
    const promptTestLoading = ref(false)
    const promptTestResult = ref(null)
    const safetyRuleResult = ref(null)
    
    const promptTestForm = reactive({
      text: '',
      checkType: 'input',
      strictness: 'medium'
    })
    
    // Methods
    const getAgentCount = (phaseKey) => {
      const typeMap = {
        triage: 'triage',
        professional: 'domain',
        search: 'search',
        analysis: 'analysis',
        generation: 'generation'
      }
      return agents.value.filter(a => a.agent_type === typeMap[phaseKey]).length
    }
    
    const getProfessionalAgentCount = (category) => {
      return professionalAgents.value.filter(a => 
        (a.config?.sub_category || 'legal') === category
      ).length
    }
    
    const getProfessionalIcon = (agent) => {
      const icons = { legal: '⚖️', contract: '📄', consult: '💬' }
      return icons[agent.config?.sub_category] || '👨‍💼'
    }
    
    const getProfessionalCategory = (agent) => {
      const labels = { legal: '法律咨询', contract: '合同服务', consult: '普通咨询' }
      return labels[agent.config?.sub_category] || '法律咨询'
    }
    
    const getRoutingTargetCount = (agent) => {
      return agent.config?.routing_targets?.length || professionalAgents.value.length
    }
    
    const getSearchType = (agent) => {
      return agent.config?.search_type || 'hybrid'
    }
    
    const getDataSources = (agent) => {
      const sources = agent.config?.data_sources || ['laws', 'cases']
      return sources.length + ' 个'
    }
    
    const getReportTemplateCount = (agent) => {
      return agent.config?.report_templates?.length || 1
    }
    
    const getDocTemplateCount = (agent) => {
      return agent.config?.doc_templates?.length || 1
    }
    
    const getActionLabel = (action) => {
      const labels = {
        warn: '⚠️ 警告提示',
        block: '🚫 阻止并提示',
        interrupt: '⛔ 中断对话',
        escalate: '👤 升级人工'
      }
      return labels[action] || action
    }
    
    const getFetchPhaseLabel = (phase) => {
      const labels = {
        triage: '分诊阶段',
        professional: '专业阶段',
        search: '搜索阶段',
        analysis: '分析阶段',
        generation: '生成阶段'
      }
      return labels[phase] || phase
    }
    
    // Load workflow phases/stages from API
    const loadPhases = async () => {
      try {
        const response = await apiClient.get('/agent-management/workflow-phases')
        if (response.data && response.data.length > 0) {
          phases.value = response.data
        }
      } catch (error) {
        console.error('Failed to load workflow phases:', error)
        // Keep default phases on error
      }
    }
    
    // Load agent types from API
    const loadAgentTypes = async () => {
      try {
        const response = await apiClient.get('/agent-management/agent-types')
        if (response.data && response.data.length > 0) {
          agentTypes.value = response.data
        }
      } catch (error) {
        console.error('Failed to load agent types:', error)
      }
    }
    
    // Load data
    const loadAgents = async () => {
      try {
        const response = await apiClient.get('/agent-management/agents')
        agents.value = response.data?.agents || response.data || []
      } catch (error) {
        console.error('Failed to load agents:', error)
      }
    }
    
    const loadSecurityRules = async () => {
      try {
        const response = await apiClient.get('/agent-management/safety-rules')
        securityRules.value = response.data?.rules || response.data || []
      } catch (error) {
        console.error('Failed to load security rules:', error)
      }
    }
    
    // Agent actions
    const addAgent = (agentType) => {
      newAgent.name = ''
      newAgent.display_name = ''
      newAgent.description = ''
      newAgent.agent_type = agentType
      newAgent.sub_category = 'legal'
      showAddAgentModal.value = true
    }
    
    const createAgent = async () => {
      try {
        await apiClient.post('/agent-management/agents', {
          name: newAgent.name,
          display_name: newAgent.display_name,
          description: newAgent.description,
          agent_type: newAgent.agent_type,
          is_active: true,
          config: {
            sub_category: newAgent.sub_category
          }
        })
        showAddAgentModal.value = false
        loadAgents()
      } catch (error) {
        alert('创建失败: ' + (error.response?.data?.detail || error.message))
      }
    }
    
    const toggleAgent = async (agent) => {
      try {
        await apiClient.put(`/agent-management/agents/${agent.id}`, {
          is_active: !agent.is_active
        })
        loadAgents()
      } catch (error) {
        alert('操作失败: ' + (error.response?.data?.detail || error.message))
      }
    }
    
    const openAgentEditor = (agent, type) => {
      // TODO: Open specific editor based on type
      alert(`打开 ${agent.display_name} 编辑器 (类型: ${type})`)
    }
    
    // Fetch Agent config
    const openFetchAgentConfig = (phase) => {
      fetchConfigPhase.value = phase
      
      // Load existing config or use defaults
      const existing = fetchAgentConfigs.value[phase] || {}
      fetchConfig.llm = {
        provider: existing.llm?.provider || 'ollama',
        api_url: existing.llm?.api_url || 'http://localhost:11434/api/generate',
        api_key: existing.llm?.api_key || '',
        model: existing.llm?.model || 'llama2'
      }
      fetchConfig.prompts = existing.prompts || [
        { name: 'System Prompt', type: 'system', content: '' }
      ]
      
      showFetchConfigModal.value = true
    }
    
    const addFetchPrompt = () => {
      fetchConfig.prompts.push({
        name: '新提示词',
        type: 'question',
        content: ''
      })
    }
    
    const removeFetchPrompt = (idx) => {
      fetchConfig.prompts.splice(idx, 1)
    }
    
    const saveFetchConfig = async () => {
      try {
        // Save to backend
        fetchAgentConfigs.value[fetchConfigPhase.value] = {
          llm: { ...fetchConfig.llm },
          prompts: [...fetchConfig.prompts]
        }
        showFetchConfigModal.value = false
        alert('保存成功!')
      } catch (error) {
        alert('保存失败')
      }
    }
    
    // Security rules
    const addSecurityRule = () => {
      editingRule.value = null
      securityForm.name = ''
      securityForm.rule_type = 'content_filter'
      securityForm.description = ''
      securityForm.keywords_text = ''
      securityForm.pattern = ''
      securityForm.action = 'block'
      securityForm.message = ''
      showSecurityModal.value = true
    }
    
    const editSecurityRule = (rule) => {
      editingRule.value = rule
      securityForm.name = rule.name || rule.display_name || ''
      securityForm.rule_type = rule.rule_type
      securityForm.description = rule.description || ''
      // Handle match_keywords as array from backend
      securityForm.keywords_text = (rule.match_keywords || []).join('\n')
      // Handle match_patterns as array from backend
      securityForm.pattern = (rule.match_patterns && rule.match_patterns[0]) || ''
      securityForm.action = rule.action || 'block'
      securityForm.message = rule.action_message || ''
      showSecurityModal.value = true
    }
    
    const saveSecurityRule = async () => {
      try {
        // Build payload with proper field names matching backend schema
        const payload = {
          name: securityForm.name,
          display_name: securityForm.name,  // Use same as name for now
          rule_type: securityForm.rule_type,
          description: securityForm.description,
          match_keywords: securityForm.keywords_text 
            ? securityForm.keywords_text.split('\n').filter(k => k.trim())
            : null,
          match_patterns: securityForm.pattern 
            ? [securityForm.pattern]
            : null,
          action: securityForm.action,
          action_message: securityForm.message || null,
          apply_to_input: true,
          status: 'active'
        }
        
        if (editingRule.value) {
          await apiClient.put(`/agent-management/safety-rules/${editingRule.value.id}`, payload)
        } else {
          await apiClient.post('/agent-management/safety-rules', payload)
        }
        
        showSecurityModal.value = false
        loadSecurityRules()
      } catch (error) {
        alert('保存失败: ' + (error.response?.data?.detail || error.message))
      }
    }
    
    const toggleSecurityRule = async (rule) => {
      try {
        const newStatus = rule.status === 'active' ? 'inactive' : 'active'
        await apiClient.put(`/agent-management/safety-rules/${rule.id}`, {
          status: newStatus
        })
        loadSecurityRules()
      } catch (error) {
        alert('操作失败: ' + (error.response?.data?.detail || error.message))
      }
    }
    
    const isFetchRuleEnabled = (phase, ruleType) => {
      // Check if rule type is enabled for this phase's fetch agent
      const config = fetchAgentConfigs.value[phase]
      return config?.enabledRules?.includes(ruleType) ?? true
    }
    
    const toggleFetchRule = (phase, ruleType) => {
      if (!fetchAgentConfigs.value[phase]) {
        fetchAgentConfigs.value[phase] = { enabledRules: ['content_filter', 'keyword', 'regex'] }
      }
      const config = fetchAgentConfigs.value[phase]
      if (!config.enabledRules) config.enabledRules = ['content_filter', 'keyword', 'regex']
      
      const idx = config.enabledRules.indexOf(ruleType)
      if (idx >= 0) {
        config.enabledRules.splice(idx, 1)
      } else {
        config.enabledRules.push(ruleType)
      }
    }
    
    // Prompt Safety Test Functions
    const openPromptTest = () => {
      promptTestForm.text = ''
      promptTestForm.checkType = 'input'
      promptTestForm.strictness = 'medium'
      promptTestResult.value = null
      safetyRuleResult.value = null
      showPromptTestModal.value = true
    }
    
    const runPromptTest = async () => {
      if (!promptTestForm.text.trim()) {
        alert('请输入要测试的文本')
        return
      }
      
      promptTestLoading.value = true
      promptTestResult.value = null
      
      try {
        const response = await apiClient.post('/agent-management/validate-prompt', {
          text: promptTestForm.text,
          strictness: promptTestForm.strictness,
          check_type: promptTestForm.checkType
        })
        promptTestResult.value = response.data
      } catch (error) {
        alert('测试失败: ' + (error.response?.data?.detail || error.message))
      } finally {
        promptTestLoading.value = false
      }
    }
    
    const runSafetyRuleCheck = async () => {
      if (!promptTestForm.text.trim()) {
        alert('请输入要测试的文本')
        return
      }
      
      promptTestLoading.value = true
      safetyRuleResult.value = null
      
      try {
        const response = await apiClient.post('/agent-management/check-safety-rules', {
          text: promptTestForm.text,
          apply_to: promptTestForm.checkType
        })
        safetyRuleResult.value = response.data
      } catch (error) {
        alert('规则检查失败: ' + (error.response?.data?.detail || error.message))
      } finally {
        promptTestLoading.value = false
      }
    }
    
    // Initialize
    onMounted(async () => {
      isLoading.value = true
      try {
        // Load configuration first
        await Promise.all([
          loadPhases(),
          loadAgentTypes()
        ])
        // Then load data
        await Promise.all([
          loadAgents(),
          loadSecurityRules()
        ])
      } finally {
        isLoading.value = false
      }
    })
    
    return {
      activePhase,
      professionalSubTab,
      agents,
      phases,
      professionalCategories,
      ruleTypes,
      isLoading,
      agentTypes,
      
      triageAgents,
      professionalAgents,
      filteredProfessionalAgents,
      searchAgents,
      analysisAgents,
      generationAgents,
      
      contentFilterRules,
      sensitiveWordRules,
      inputValidationRules,
      
      showAddAgentModal,
      showSecurityModal,
      showFetchConfigModal,
      editingRule,
      fetchConfigPhase,
      newAgent,
      securityForm,
      fetchConfig,
      
      // Prompt test
      showPromptTestModal,
      promptTestLoading,
      promptTestResult,
      safetyRuleResult,
      promptTestForm,
      
      getAgentCount,
      getProfessionalAgentCount,
      getProfessionalIcon,
      getProfessionalCategory,
      getRoutingTargetCount,
      getSearchType,
      getDataSources,
      getReportTemplateCount,
      getDocTemplateCount,
      getActionLabel,
      getFetchPhaseLabel,
      
      addAgent,
      createAgent,
      toggleAgent,
      openAgentEditor,
      
      openFetchAgentConfig,
      addFetchPrompt,
      removeFetchPrompt,
      saveFetchConfig,
      
      addSecurityRule,
      editSecurityRule,
      saveSecurityRule,
      toggleSecurityRule,
      isFetchRuleEnabled,
      toggleFetchRule,
      
      // Prompt test functions
      openPromptTest,
      runPromptTest,
      runSafetyRuleCheck
    }
  }
}
</script>

<style scoped>
.main-content {
  margin-left: var(--sidebar-width, 16px);
  transition: margin-left 0.3s ease;
}

.sidebar-pinned .main-content {
  margin-left: 256px;
}

/* Pipeline Overview */
.pipeline-overview {
  display: flex;
  gap: 8px;
  background: white;
  padding: 16px;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
  overflow-x: auto;
}

.pipeline-step {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  background: #f8fafc;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
  white-space: nowrap;
}

.pipeline-step:hover {
  background: #f1f5f9;
}

.pipeline-step.active {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.pipeline-step.security {
  margin-left: auto;
  background: #fef3c7;
}

.pipeline-step.security.active {
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
}

.step-number {
  width: 24px;
  height: 24px;
  background: rgba(255,255,255,0.2);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 600;
}

.pipeline-step.active .step-number {
  background: rgba(255,255,255,0.3);
}

.step-icon {
  font-size: 20px;
}

.step-name {
  font-weight: 500;
}

.step-count {
  background: rgba(0,0,0,0.1);
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 12px;
}

.pipeline-step.active .step-count {
  background: rgba(255,255,255,0.2);
}

/* Phase Panel */
.phase-panel {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}

.phase-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
  padding-bottom: 16px;
  border-bottom: 1px solid #e2e8f0;
}

.phase-header h2 {
  margin: 0 0 4px 0;
  font-size: 20px;
}

.phase-header p {
  margin: 0;
  color: #64748b;
  font-size: 14px;
}

/* Sub Categories */
.sub-categories {
  display: flex;
  gap: 8px;
  margin-bottom: 20px;
}

.category-tab {
  padding: 8px 16px;
  background: #f1f5f9;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.category-tab:hover {
  background: #e2e8f0;
}

.category-tab.active {
  background: #667eea;
  color: white;
}

.category-tab .count {
  background: rgba(0,0,0,0.1);
  padding: 2px 6px;
  border-radius: 8px;
  font-size: 12px;
}

.category-tab.active .count {
  background: rgba(255,255,255,0.2);
}

/* Agents Grid */
.agents-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 16px;
}

.agent-card {
  background: #f8fafc;
  border-radius: 12px;
  padding: 20px;
  border: 2px solid transparent;
  transition: all 0.2s;
}

.agent-card:hover {
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.agent-card.triage { border-color: #8b5cf6; }
.agent-card.professional { border-color: #3b82f6; }
.agent-card.search { border-color: #10b981; }
.agent-card.analysis { border-color: #f59e0b; }
.agent-card.generation { border-color: #ec4899; }

.agent-card.fetch-agent {
  background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
  border-color: #f59e0b;
}

.agent-header {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  margin-bottom: 12px;
}

.agent-icon {
  font-size: 28px;
}

.agent-info {
  flex: 1;
}

.agent-info h3 {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
}

.agent-type {
  font-size: 12px;
  color: #64748b;
}

.status-badge {
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
}

.status-badge.active {
  background: #d1fae5;
  color: #059669;
}

.status-badge.inactive {
  background: #fee2e2;
  color: #dc2626;
}

.agent-description {
  font-size: 14px;
  color: #64748b;
  margin-bottom: 16px;
  line-height: 1.5;
}

.agent-meta {
  display: flex;
  gap: 16px;
  margin-bottom: 16px;
}

.meta-item {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.meta-label {
  font-size: 11px;
  color: #94a3b8;
  text-transform: uppercase;
}

.meta-value {
  font-size: 13px;
  font-weight: 500;
}

.agent-actions {
  display: flex;
  gap: 8px;
}

/* Security Panel */
.security-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 20px;
}

.security-section {
  background: #f8fafc;
  border-radius: 12px;
  padding: 20px;
}

.security-section.full-width {
  grid-column: 1 / -1;
}

.security-section h3 {
  margin: 0 0 4px 0;
  font-size: 16px;
}

.section-desc {
  margin: 0 0 16px 0;
  color: #64748b;
  font-size: 13px;
}

.rules-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.rule-card {
  background: white;
  border-radius: 8px;
  padding: 16px;
}

.rule-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.rule-name {
  font-weight: 600;
}

.rule-status {
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 11px;
}

.rule-status.active {
  background: #d1fae5;
  color: #059669;
}

.rule-status.inactive {
  background: #f1f5f9;
  color: #64748b;
}

.rule-description {
  font-size: 13px;
  color: #64748b;
  margin-bottom: 8px;
}

.rule-keywords {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-bottom: 8px;
}

.keyword-tag {
  padding: 2px 8px;
  background: #fef3c7;
  border-radius: 4px;
  font-size: 12px;
}

.more-keywords {
  padding: 2px 8px;
  background: #e2e8f0;
  border-radius: 4px;
  font-size: 12px;
}

.rule-action {
  font-size: 13px;
  margin-bottom: 12px;
}

.action-label {
  color: #64748b;
}

.rule-actions {
  display: flex;
  gap: 8px;
}

.empty-state {
  text-align: center;
  padding: 24px;
  color: #94a3b8;
  font-size: 14px;
}

/* Fetch Agent Security Grid */
.fetch-agent-security-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
}

.fetch-security-card {
  background: white;
  border-radius: 8px;
  padding: 16px;
}

.fetch-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
  padding-bottom: 8px;
  border-bottom: 1px solid #e2e8f0;
}

.fetch-icon {
  font-size: 20px;
}

.fetch-name {
  font-weight: 500;
  font-size: 14px;
}

.fetch-rules {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.rule-toggle {
  display: flex;
  align-items: center;
}

.toggle-label {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  cursor: pointer;
}

/* Buttons */
.btn {
  padding: 8px 16px;
  border-radius: 6px;
  border: none;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.2s;
}

.btn-primary {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.btn-primary:hover {
  opacity: 0.9;
}

.btn-secondary {
  background: #e2e8f0;
  color: #475569;
}

.btn-secondary:hover {
  background: #cbd5e1;
}

.btn-sm {
  padding: 6px 12px;
  font-size: 13px;
}

.btn-icon {
  width: 28px;
  height: 28px;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  background: transparent;
  border: none;
  cursor: pointer;
  font-size: 18px;
}

.btn-icon.danger {
  color: #dc2626;
}

.btn-icon.danger:hover {
  background: #fee2e2;
}

/* Modal */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 16px;
  width: 90%;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
}

.modal-content.modal-lg {
  max-width: 700px;
}

.modal-header {
  padding: 20px 24px;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.modal-header h3 {
  margin: 0;
  font-size: 18px;
}

.btn-close {
  width: 32px;
  height: 32px;
  border: none;
  background: #f1f5f9;
  border-radius: 6px;
  font-size: 20px;
  cursor: pointer;
}

.modal-body {
  padding: 24px;
}

.modal-footer {
  padding: 16px 24px;
  border-top: 1px solid #e2e8f0;
  display: flex;
  justify-content: flex-end;
  gap: 12px;
}

/* Forms */
.form-group {
  margin-bottom: 16px;
}

.form-group label {
  display: block;
  margin-bottom: 6px;
  font-size: 14px;
  font-weight: 500;
  color: #374151;
}

.form-input {
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  font-size: 14px;
}

.form-input:focus {
  outline: none;
  border-color: #667eea;
  box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

/* Config Sections */
.config-section {
  margin-bottom: 24px;
  padding-bottom: 24px;
  border-bottom: 1px solid #e2e8f0;
}

.config-section:last-child {
  border-bottom: none;
  margin-bottom: 0;
  padding-bottom: 0;
}

.config-section h4 {
  margin: 0 0 16px 0;
  font-size: 16px;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.section-header h4 {
  margin: 0;
}

/* Prompts List */
.prompts-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.prompt-item {
  background: #f8fafc;
  border-radius: 8px;
  padding: 16px;
}

.prompt-header {
  display: flex;
  gap: 12px;
  margin-bottom: 12px;
}

.prompt-name-input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font-size: 14px;
}

.prompt-type-select {
  padding: 8px 12px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font-size: 14px;
}

.prompt-content {
  width: 100%;
  padding: 12px;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  font-size: 14px;
  font-family: monospace;
  resize: vertical;
}

/* Prompt Test Modal Styles */
.header-actions {
  display: flex;
  gap: 8px;
}

.form-row {
  display: flex;
  gap: 16px;
  margin-bottom: 16px;
}

.ml-2 {
  margin-left: 8px;
}

.mt-4 {
  margin-top: 16px;
}

.test-results {
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  overflow: hidden;
}

.result-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  font-weight: 600;
}

.result-safe {
  background: #ecfdf5;
  color: #047857;
}

.result-unsafe {
  background: #fef2f2;
  color: #b91c1c;
}

.result-icon {
  font-size: 20px;
}

.result-title {
  flex: 1;
}

.result-badge {
  background: rgba(0,0,0,0.1);
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
}

.threats-list {
  padding: 16px;
  border-top: 1px solid #e5e7eb;
}

.threats-list h4 {
  margin-bottom: 12px;
  color: #374151;
}

.threat-item {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  background: #f9fafb;
  border-radius: 6px;
  margin-bottom: 8px;
}

.threat-severity {
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
}

.severity-low {
  background: #dbeafe;
  color: #1d4ed8;
}

.severity-medium {
  background: #fef3c7;
  color: #b45309;
}

.severity-high {
  background: #fed7aa;
  color: #c2410c;
}

.severity-critical {
  background: #fecaca;
  color: #b91c1c;
}

.threat-category {
  font-weight: 500;
  color: #4b5563;
}

.threat-desc {
  color: #6b7280;
  font-size: 13px;
}

.threat-match {
  width: 100%;
  font-size: 12px;
  color: #6b7280;
  margin-top: 4px;
}

.threat-match code {
  background: #e5e7eb;
  padding: 2px 6px;
  border-radius: 4px;
  font-family: monospace;
}

.sanitized-result {
  padding: 16px;
  border-top: 1px solid #e5e7eb;
}

.sanitized-result h4 {
  margin-bottom: 12px;
  color: #374151;
}

.code-block {
  background: #1f2937;
  color: #f3f4f6;
  padding: 12px;
  border-radius: 6px;
  font-size: 13px;
  font-family: monospace;
  white-space: pre-wrap;
  word-break: break-all;
  max-height: 200px;
  overflow-y: auto;
}

.result-meta {
  display: flex;
  gap: 16px;
  padding: 12px 16px;
  background: #f9fafb;
  border-top: 1px solid #e5e7eb;
  font-size: 12px;
  color: #6b7280;
}

.rule-match {
  padding: 16px;
  border-top: 1px solid #e5e7eb;
}

.rule-match p {
  margin-bottom: 8px;
}
</style>
