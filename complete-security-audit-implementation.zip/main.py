"""
Legal Assistant API - Main Application
=======================================

FastAPI application with LangGraph-based questionnaire workflow.
No n8n dependency - everything runs in-process.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from config import settings
from database import engine, Base
from routers import auth, profile, admin, professional_api, cases, questionnaire, verification
from routers.workflow import router as workflow_router
from routers.workflow_extended import router as workflow_extended_router
from routers.document import router as document_router
from routers.contract import router as contract_router
from routers.work_document import router as work_document_router
from routers.ai_generation import router as ai_router
from routers.professional_case import router as professional_case_router
from routers.templates import router as templates_router
from routers.case_work import router as case_work_router
from routers.variables import router as variables_router

# === NEW: Document Workspace V2 Routers ===
from routers.law_articles import router as law_articles_router
from routers.case_analysis import router as case_analysis_router
from routers.platform_variables import router as platform_variables_router

# === NEW: Agent Management Router ===
from routers.agent_management import router as agent_management_router

# === NEW: Workflow Stages Router (Dynamic Configuration) ===
from routers.workflow_stages import router as workflow_stages_router

# === NEW: Conversation Router (Mother Point Collection) ===
from routers.conversation import router as conversation_router

# === NEW: Professional Case Data Router ===
from routers.professional_case_data import router as professional_case_data_router

# === NEW: Legal Data System Routers (Vector Search + Client-Aware Ranking) ===
from routers.case_records import router as case_records_router
from routers.data_loader import router as data_loader_router
from routers.admin_data import router as admin_data_router
from routers.triage_management import router as triage_management_router
from routers.professional_management import router as professional_management_router
from routers.rag_management import router as rag_management_router
from routers.analysis_management import router as analysis_management_router
from routers.generation_management import router as generation_management_router
from routers.workflow_management import router as workflow_management_router

from utils.redis_client import redis_client


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan events"""
    # Startup
    print("=" * 60)
    print("Starting Legal Assistant API...")
    print("=" * 60)
    print(f"API Server: http://localhost:8000")
    print(f"Frontend: http://localhost:3000")
    print(f"API Docs: http://localhost:8000/docs")
    print(f"LangGraph Workflow: Enabled")
    print(f"Elasticsearch Law Search: Enabled")
    print("=" * 60)

    # Create database tables
    Base.metadata.create_all(bind=engine)

    # Initialize Redis connection
    await redis_client.connect()
    print("Redis connected")

    # Check Elasticsearch connection (optional)
    try:
        from elasticsearch import Elasticsearch
        import os
        es_host = os.getenv("ELASTICSEARCH_HOST", "localhost")
        es_port = os.getenv("ELASTICSEARCH_PORT", "9200")
        es = Elasticsearch([f"http://{es_host}:{es_port}"])
        if es.ping():
            print(f"Elasticsearch connected ({es_host}:{es_port})")
        else:
            print("Elasticsearch not available (using mock data)")
    except Exception as e:
        print(f"Elasticsearch not configured: {e}")

    yield

    # Shutdown
    print("Shutting down...")
    await redis_client.close()


# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Legal Assistant API with LangGraph-powered questionnaire workflow.",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routers
app.include_router(auth.router)
app.include_router(profile.router)
app.include_router(professional_api.router)
app.include_router(cases.router)
app.include_router(admin.router)
app.include_router(questionnaire.router)
app.include_router(workflow_router)
app.include_router(workflow_extended_router)
app.include_router(verification.router)
app.include_router(document_router)
app.include_router(contract_router)
app.include_router(work_document_router)
app.include_router(ai_router)
app.include_router(professional_case_router)
app.include_router(templates_router)
app.include_router(case_work_router)              # /api/case-work/*
app.include_router(variables_router)              # /api/variables/*

# === NEW: Document Workspace V2 Routers ===
app.include_router(law_articles_router)        # /api/law-articles/*
app.include_router(case_analysis_router)       # /api/case-analysis/*
app.include_router(platform_variables_router)  # /api/platform-variables/*

# === NEW: Agent Management Router ===
app.include_router(agent_management_router)    # /api/agent-management/*

# === NEW: Workflow Stages Router (Dynamic Configuration) ===
app.include_router(workflow_stages_router)     # /api/workflow-stages/*

# === NEW: Conversation Router (Mother Point Collection) ===
app.include_router(conversation_router)        # /api/conversation/*

# === NEW: Professional Case Data Router ===
app.include_router(professional_case_data_router)  # /api/professional/cases/*

# === NEW: Legal Data System Routes (Vector Search + Client-Aware Ranking) ===
app.include_router(case_records_router)            # /api/case-records/*
app.include_router(data_loader_router)             # /api/admin/data-loader/*
app.include_router(admin_data_router)              # /api/admin/data/*
app.include_router(triage_management_router)       # /api/admin/triage/*
app.include_router(professional_management_router) # /api/admin/professional/*
app.include_router(rag_management_router)          # /api/admin/rag/*
app.include_router(analysis_management_router)     # /api/admin/analysis/*
app.include_router(generation_management_router)   # /api/admin/generation/*
app.include_router(workflow_management_router)     # /api/admin/workflow/*


@app.get("/")
async def root():
    """API root endpoint"""
    return {
        "message": "Legal Assistant API",
        "version": settings.APP_VERSION,
        "status": "running",
        "docs": "/docs"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        redis_status = await redis_client.ping()
        
        # Check Elasticsearch
        es_status = "not configured"
        try:
            from elasticsearch import Elasticsearch
            import os
            es_host = os.getenv("ELASTICSEARCH_HOST", "localhost")
            es_port = os.getenv("ELASTICSEARCH_PORT", "9200")
            es = Elasticsearch([f"http://{es_host}:{es_port}"])
            es_status = "connected" if es.ping() else "disconnected"
        except:
            pass
        
        return {
            "status": "healthy",
            "redis": "connected" if redis_status else "disconnected",
            "database": "connected",
            "elasticsearch": es_status
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e)
        }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG
    )
