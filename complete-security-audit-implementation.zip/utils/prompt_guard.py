"""
Prompt Guard
============

Centralized prompt safety module for protecting against prompt injection attacks.

Features:
- Enhanced input sanitization with multiple detection layers
- Unicode and encoding bypass detection
- Output validation for agent responses
- Integration with SafetyRule database
- Configurable strictness levels
- Comprehensive logging of detected attacks

Usage:
    from utils.prompt_guard import PromptGuard, sanitize_input, validate_output
    
    guard = PromptGuard(strictness="high")
    result = guard.check_input(user_message)
    if result.is_safe:
        # Process message
    else:
        # Handle blocked message
"""
import re
import unicodedata
from typing import Any, Dict, List, Optional, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import logging

# Setup logging
logger = logging.getLogger(__name__)


# ==================== Enums and Data Classes ====================

class StrictnessLevel(str, Enum):
    """Strictness levels for prompt protection"""
    LOW = "low"        # Basic protection, fewer false positives
    MEDIUM = "medium"  # Balanced protection (default)
    HIGH = "high"      # Maximum protection, may have false positives
    CUSTOM = "custom"  # Use custom patterns only


class ThreatCategory(str, Enum):
    """Categories of detected threats"""
    ROLE_INJECTION = "role_injection"
    INSTRUCTION_OVERRIDE = "instruction_override"
    JAILBREAK = "jailbreak"
    SPECIAL_TOKEN = "special_token"
    CODE_INJECTION = "code_injection"
    UNICODE_EXPLOIT = "unicode_exploit"
    OUTPUT_MANIPULATION = "output_manipulation"
    SENSITIVE_DATA = "sensitive_data"
    UNKNOWN = "unknown"


@dataclass
class ThreatMatch:
    """Details of a detected threat"""
    category: ThreatCategory
    pattern: str
    matched_text: str
    position: int
    severity: str  # "low", "medium", "high", "critical"
    description: str = ""


@dataclass
class CheckResult:
    """Result of a safety check"""
    is_safe: bool
    threats: List[ThreatMatch] = field(default_factory=list)
    sanitized_text: Optional[str] = None
    original_text: Optional[str] = None
    strictness: str = "medium"
    check_time_ms: float = 0.0
    
    @property
    def threat_count(self) -> int:
        return len(self.threats)
    
    @property
    def highest_severity(self) -> Optional[str]:
        if not self.threats:
            return None
        severity_order = {"low": 1, "medium": 2, "high": 3, "critical": 4}
        return max(self.threats, key=lambda t: severity_order.get(t.severity, 0)).severity
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_safe": self.is_safe,
            "threat_count": self.threat_count,
            "highest_severity": self.highest_severity,
            "threats": [
                {
                    "category": t.category.value,
                    "pattern": t.pattern,
                    "matched_text": t.matched_text[:100],  # Truncate for safety
                    "position": t.position,
                    "severity": t.severity,
                    "description": t.description
                }
                for t in self.threats
            ],
            "sanitized_text": self.sanitized_text,
            "strictness": self.strictness,
            "check_time_ms": self.check_time_ms
        }


# ==================== Pattern Definitions ====================

# Role injection patterns
ROLE_INJECTION_PATTERNS = [
    # English role markers
    (r'(?i)^\s*(system|assistant|human|user|ai|bot)\s*[:：]', "high", "Role marker at start"),
    (r'(?i)\b(system|assistant|human|user)\s*[:：]\s*["\']?', "high", "Role marker with quote"),
    (r'(?i)\[\s*(system|user|assistant|human)\s*\]', "high", "Bracketed role marker"),
    
    # Chinese role markers
    (r'^\s*(系统|助手|用户|人类|AI|机器人)\s*[:：]', "high", "Chinese role marker"),
    (r'(系统|助手|用户)\s*[:：]\s*[「"'"]', "high", "Chinese role with quote"),
    
    # Multi-turn injection
    (r'(?i)<\|(system|user|assistant|im_start|im_end)\|>', "critical", "Special token injection"),
    (r'(?i)\[INST\]|\[/INST\]', "critical", "Llama instruction token"),
    (r'(?i)<<\s*SYS\s*>>|<<\s*/SYS\s*>>', "critical", "Llama system token"),
    (r'(?i)###\s*(System|Instruction|Human|Assistant|User)', "high", "Markdown role marker"),
]

# Instruction override patterns
INSTRUCTION_OVERRIDE_PATTERNS = [
    # English
    (r'(?i)ignore\s+(all\s+)?(previous|above|prior|earlier)\s+(instructions?|prompts?|rules?|context)', "critical", "Ignore instruction attempt"),
    (r'(?i)disregard\s+(all\s+)?(previous|above|prior)', "critical", "Disregard instruction"),
    (r'(?i)forget\s+(everything|all|what)\s+(you|i)\s+(said|told|know)', "high", "Forget instruction"),
    (r'(?i)override\s+(previous|system|all)\s+(instruction|rule|prompt)', "critical", "Override attempt"),
    (r'(?i)new\s+(instruction|rule|prompt|task)\s*[:：]', "high", "New instruction injection"),
    (r'(?i)your\s+(actual|real|true|new)\s+(instruction|task|purpose)', "high", "Actual instruction claim"),
    (r'(?i)stop\s+being\s+(helpful|assistant|ai)', "medium", "Identity change attempt"),
    (r'(?i)from\s+now\s+on[,\s]+(you|ignore|act|pretend)', "high", "Behavioral change"),
    
    # Chinese
    (r'忽略(上述|以上|之前的?|前面的?)(指令|提示|规则|说明|要求)', "critical", "Chinese ignore instruction"),
    (r'无视(之前|以上|上述)(的?)(指令|规则)', "critical", "Chinese disregard"),
    (r'(你现在是|你的新角色是|从现在开始你是)', "high", "Chinese role change"),
    (r'新(指令|任务|规则)\s*[:：]', "high", "Chinese new instruction"),
]

# Jailbreak patterns
JAILBREAK_PATTERNS = [
    # Known jailbreak techniques
    (r'(?i)\bDAN\b.*mode', "critical", "DAN mode jailbreak"),
    (r'(?i)jailbreak|jail\s*break', "critical", "Jailbreak keyword"),
    (r'(?i)bypass\s+(filter|safety|restriction|rule)', "critical", "Bypass attempt"),
    (r'(?i)developer\s+mode|dev\s+mode', "high", "Developer mode"),
    (r'(?i)maintenance\s+mode', "high", "Maintenance mode"),
    (r'(?i)unfiltered\s+mode', "high", "Unfiltered mode"),
    
    # Roleplay exploitation
    (r'(?i)pretend\s+(you\s+)?(are|to\s+be|that\s+you)', "medium", "Pretend instruction"),
    (r'(?i)act\s+as\s+(if|though)\s+you', "medium", "Act as instruction"),
    (r'(?i)role\s*play\s+(as|that)', "medium", "Roleplay instruction"),
    (r'(?i)imagine\s+(you\s+)?(are|were|being)', "low", "Imagine scenario"),
    (r'(?i)simulate\s+(being|a|an)', "medium", "Simulation request"),
    
    # Prompt leaking
    (r'(?i)reveal\s+(your|the)\s+(system|initial|original)\s+prompt', "high", "Prompt reveal attempt"),
    (r'(?i)show\s+(me\s+)?(your|the)\s+(instructions?|prompt)', "high", "Show prompt attempt"),
    (r'(?i)what\s+(are|were)\s+your\s+(original|initial)\s+instructions?', "high", "Original instructions query"),
    (r'(?i)repeat\s+(your|the)\s+(system|initial)\s+(prompt|message)', "high", "Repeat prompt attempt"),
    
    # Chinese jailbreak
    (r'越狱|解锁|破解限制', "critical", "Chinese jailbreak"),
    (r'绕过(过滤|限制|规则)', "critical", "Chinese bypass"),
]

# Special token patterns
SPECIAL_TOKEN_PATTERNS = [
    (r'<\|endoftext\|>', "critical", "End of text token"),
    (r'<\|pad\|>', "high", "Padding token"),
    (r'<\|startoftext\|>', "critical", "Start of text token"),
    (r'<\|sep\|>', "high", "Separator token"),
    (r'<extra_id_\d+>', "high", "T5 extra ID token"),
    (r'\[PAD\]|\[CLS\]|\[SEP\]|\[MASK\]|\[UNK\]', "high", "BERT special token"),
    (r'<s>|</s>|<pad>', "high", "Sentence token"),
]

# Code injection patterns
CODE_INJECTION_PATTERNS = [
    (r'```(python|javascript|bash|shell|sql|php|exec)[\s\S]*?```', "medium", "Code block"),
    (r'(?i)exec\s*\(|eval\s*\(|system\s*\(', "high", "Code execution function"),
    (r'(?i)import\s+(os|sys|subprocess)', "high", "Dangerous import"),
    (r'(?i)\$\{.*?\}', "medium", "Variable interpolation"),
    (r'(?i){{.*?}}', "medium", "Template injection"),
    (r'(?i)<script[\s>]', "high", "Script tag"),
]

# Unicode exploit patterns (confusable characters)
UNICODE_EXPLOIT_PATTERNS = [
    # Invisible characters
    (r'[\u200b-\u200f\u2060-\u206f]', "high", "Zero-width/invisible character"),
    (r'[\u00ad]', "medium", "Soft hyphen"),
    (r'[\ufeff]', "medium", "BOM character"),
    
    # Direction override
    (r'[\u202a-\u202e]', "critical", "Bidirectional text override"),
    (r'[\u2066-\u2069]', "critical", "Bidirectional isolate"),
    
    # Homoglyph attacks (common confusables)
    (r'[\u0430\u0435\u043e\u0440\u0441\u0443\u0445]', "medium", "Cyrillic confusable"),  # а е о р с у х
    (r'[\u03bf\u03c1]', "medium", "Greek confusable"),  # ο ρ
]

# Output validation patterns
OUTPUT_MANIPULATION_PATTERNS = [
    (r'(?i)^(system|assistant):', "high", "Output role injection"),
    (r'(?i)\[end\s+of\s+(response|output|message)\]', "medium", "Fake end marker"),
    (r'(?i)---+\s*(new|actual|real)\s+(response|output)', "high", "Response injection"),
    (r'(?i)<\|im_end\|>.*<\|im_start\|>', "critical", "Token injection in output"),
]


# ==================== Helper Functions ====================

def normalize_unicode(text: str) -> str:
    """
    Normalize Unicode text to detect homoglyph attacks.
    
    Converts confusable characters to their ASCII equivalents.
    """
    # NFKC normalization handles many confusables
    normalized = unicodedata.normalize('NFKC', text)
    
    # Additional manual mappings for common confusables
    confusable_map = {
        # Cyrillic to Latin
        'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'у': 'y', 'х': 'x',
        'А': 'A', 'Е': 'E', 'О': 'O', 'Р': 'P', 'С': 'C', 'У': 'Y', 'Х': 'X',
        # Greek to Latin
        'ο': 'o', 'Ο': 'O', 'ρ': 'p', 'Ρ': 'P',
        # Other
        'ℓ': 'l', '𝐚': 'a', '𝐛': 'b', '𝐜': 'c',
    }
    
    for confusable, replacement in confusable_map.items():
        normalized = normalized.replace(confusable, replacement)
    
    return normalized


def remove_invisible_chars(text: str) -> str:
    """Remove invisible and zero-width characters."""
    # Remove zero-width characters
    text = re.sub(r'[\u200b-\u200f\u2060-\u206f\ufeff\u00ad]', '', text)
    # Remove bidirectional overrides
    text = re.sub(r'[\u202a-\u202e\u2066-\u2069]', '', text)
    return text


def truncate_for_logging(text: str, max_length: int = 500) -> str:
    """Truncate text safely for logging."""
    if len(text) <= max_length:
        return text
    return text[:max_length] + f"... [truncated, total {len(text)} chars]"


# ==================== Main PromptGuard Class ====================

class PromptGuard:
    """
    Main class for prompt protection and validation.
    
    Usage:
        guard = PromptGuard(strictness="high")
        result = guard.check_input(user_message)
        
        if not result.is_safe:
            print(f"Blocked: {result.highest_severity} severity threat detected")
        else:
            safe_text = result.sanitized_text
    """
    
    def __init__(
        self,
        strictness: str = "medium",
        max_length: int = 10000,
        custom_patterns: List[Tuple[str, str, str]] = None,
        enable_unicode_normalization: bool = True,
        enable_logging: bool = True
    ):
        """
        Initialize PromptGuard.
        
        Args:
            strictness: Protection level ("low", "medium", "high", "custom")
            max_length: Maximum allowed input length
            custom_patterns: Additional patterns as (regex, severity, description) tuples
            enable_unicode_normalization: Normalize Unicode for homoglyph detection
            enable_logging: Log detected threats
        """
        self.strictness = StrictnessLevel(strictness)
        self.max_length = max_length
        self.custom_patterns = custom_patterns or []
        self.enable_unicode_normalization = enable_unicode_normalization
        self.enable_logging = enable_logging
        
        # Build pattern sets based on strictness
        self._build_patterns()
    
    def _build_patterns(self):
        """Build pattern sets based on strictness level."""
        self.patterns: Dict[ThreatCategory, List[Tuple[str, str, str]]] = {}
        
        if self.strictness == StrictnessLevel.LOW:
            # Only critical patterns
            self.patterns[ThreatCategory.ROLE_INJECTION] = [
                p for p in ROLE_INJECTION_PATTERNS if p[1] == "critical"
            ]
            self.patterns[ThreatCategory.INSTRUCTION_OVERRIDE] = [
                p for p in INSTRUCTION_OVERRIDE_PATTERNS if p[1] == "critical"
            ]
            self.patterns[ThreatCategory.JAILBREAK] = [
                p for p in JAILBREAK_PATTERNS if p[1] == "critical"
            ]
            self.patterns[ThreatCategory.SPECIAL_TOKEN] = SPECIAL_TOKEN_PATTERNS
            
        elif self.strictness == StrictnessLevel.MEDIUM:
            # Critical and high patterns
            self.patterns[ThreatCategory.ROLE_INJECTION] = [
                p for p in ROLE_INJECTION_PATTERNS if p[1] in ("critical", "high")
            ]
            self.patterns[ThreatCategory.INSTRUCTION_OVERRIDE] = [
                p for p in INSTRUCTION_OVERRIDE_PATTERNS if p[1] in ("critical", "high")
            ]
            self.patterns[ThreatCategory.JAILBREAK] = [
                p for p in JAILBREAK_PATTERNS if p[1] in ("critical", "high")
            ]
            self.patterns[ThreatCategory.SPECIAL_TOKEN] = SPECIAL_TOKEN_PATTERNS
            self.patterns[ThreatCategory.CODE_INJECTION] = [
                p for p in CODE_INJECTION_PATTERNS if p[1] == "high"
            ]
            
        elif self.strictness == StrictnessLevel.HIGH:
            # All patterns
            self.patterns[ThreatCategory.ROLE_INJECTION] = ROLE_INJECTION_PATTERNS
            self.patterns[ThreatCategory.INSTRUCTION_OVERRIDE] = INSTRUCTION_OVERRIDE_PATTERNS
            self.patterns[ThreatCategory.JAILBREAK] = JAILBREAK_PATTERNS
            self.patterns[ThreatCategory.SPECIAL_TOKEN] = SPECIAL_TOKEN_PATTERNS
            self.patterns[ThreatCategory.CODE_INJECTION] = CODE_INJECTION_PATTERNS
            self.patterns[ThreatCategory.UNICODE_EXPLOIT] = UNICODE_EXPLOIT_PATTERNS
            
        else:  # CUSTOM
            # Only custom patterns
            pass
        
        # Always add custom patterns if provided
        if self.custom_patterns:
            self.patterns[ThreatCategory.UNKNOWN] = self.custom_patterns
    
    def check_input(
        self,
        text: str,
        context: Dict[str, Any] = None
    ) -> CheckResult:
        """
        Check user input for prompt injection attempts.
        
        Args:
            text: User input to check
            context: Optional context (user_id, session_id, etc.)
            
        Returns:
            CheckResult with safety assessment and sanitized text
        """
        import time
        start_time = time.time()
        
        if not text:
            return CheckResult(
                is_safe=True,
                sanitized_text="",
                original_text="",
                strictness=self.strictness.value
            )
        
        original_text = text
        threats: List[ThreatMatch] = []
        
        # Length check
        if len(text) > self.max_length:
            text = text[:self.max_length]
            threats.append(ThreatMatch(
                category=ThreatCategory.UNKNOWN,
                pattern="length_exceeded",
                matched_text=f"Input truncated from {len(original_text)} to {self.max_length}",
                position=self.max_length,
                severity="low",
                description="Input exceeded maximum length"
            ))
        
        # Unicode normalization
        if self.enable_unicode_normalization:
            normalized_text = normalize_unicode(text)
            clean_text = remove_invisible_chars(text)
            
            if clean_text != text:
                threats.append(ThreatMatch(
                    category=ThreatCategory.UNICODE_EXPLOIT,
                    pattern="invisible_chars",
                    matched_text="[invisible characters removed]",
                    position=0,
                    severity="medium",
                    description="Invisible characters detected and removed"
                ))
                text = clean_text
        else:
            normalized_text = text
        
        # Check all pattern categories
        for category, pattern_list in self.patterns.items():
            for pattern, severity, description in pattern_list:
                try:
                    # Check both original and normalized text
                    for check_text in [text, normalized_text]:
                        matches = list(re.finditer(pattern, check_text, re.IGNORECASE | re.DOTALL))
                        for match in matches:
                            threats.append(ThreatMatch(
                                category=category,
                                pattern=pattern[:50],  # Truncate pattern for storage
                                matched_text=match.group()[:100],  # Truncate matched text
                                position=match.start(),
                                severity=severity,
                                description=description
                            ))
                except re.error as e:
                    logger.warning(f"Invalid regex pattern: {pattern}, error: {e}")
        
        # Determine if safe based on threats
        is_safe = True
        if threats:
            severity_weights = {"low": 1, "medium": 2, "high": 3, "critical": 4}
            total_severity = sum(severity_weights.get(t.severity, 0) for t in threats)
            
            # Block if any critical threat or high severity total
            if any(t.severity == "critical" for t in threats):
                is_safe = False
            elif total_severity >= 6:  # e.g., 2 high or 3 medium threats
                is_safe = False
            elif self.strictness == StrictnessLevel.HIGH and total_severity >= 3:
                is_safe = False
        
        # Sanitize text by removing/replacing threats
        sanitized_text = self._sanitize(text, threats)
        
        check_time = (time.time() - start_time) * 1000
        
        result = CheckResult(
            is_safe=is_safe,
            threats=threats,
            sanitized_text=sanitized_text,
            original_text=original_text[:1000],  # Truncate for storage
            strictness=self.strictness.value,
            check_time_ms=check_time
        )
        
        # Log threats if enabled
        if self.enable_logging and threats:
            self._log_threats(result, context)
        
        return result
    
    def check_output(
        self,
        text: str,
        context: Dict[str, Any] = None
    ) -> CheckResult:
        """
        Validate agent output for injection attempts.
        
        Some attacks try to inject content into the output that
        could affect future turns or user perception.
        """
        import time
        start_time = time.time()
        
        if not text:
            return CheckResult(is_safe=True, sanitized_text="")
        
        threats: List[ThreatMatch] = []
        
        # Check output manipulation patterns
        for pattern, severity, description in OUTPUT_MANIPULATION_PATTERNS:
            try:
                matches = list(re.finditer(pattern, text, re.IGNORECASE | re.DOTALL))
                for match in matches:
                    threats.append(ThreatMatch(
                        category=ThreatCategory.OUTPUT_MANIPULATION,
                        pattern=pattern[:50],
                        matched_text=match.group()[:100],
                        position=match.start(),
                        severity=severity,
                        description=description
                    ))
            except re.error:
                pass
        
        # Check for HTML/script injection in output
        html_patterns = [
            (r'<script[^>]*>[\s\S]*?</script>', "critical", "Script tag in output"),
            (r'<iframe[^>]*>', "high", "Iframe tag in output"),
            (r'javascript:', "high", "JavaScript URI in output"),
            (r'on\w+\s*=\s*["\']', "medium", "Event handler in output"),
        ]
        
        for pattern, severity, description in html_patterns:
            try:
                matches = list(re.finditer(pattern, text, re.IGNORECASE))
                for match in matches:
                    threats.append(ThreatMatch(
                        category=ThreatCategory.OUTPUT_MANIPULATION,
                        pattern=pattern[:50],
                        matched_text=match.group()[:100],
                        position=match.start(),
                        severity=severity,
                        description=description
                    ))
            except re.error:
                pass
        
        is_safe = not any(t.severity in ("critical", "high") for t in threats)
        sanitized_text = self._sanitize_output(text, threats) if not is_safe else text
        
        check_time = (time.time() - start_time) * 1000
        
        return CheckResult(
            is_safe=is_safe,
            threats=threats,
            sanitized_text=sanitized_text,
            original_text=text[:1000],
            strictness=self.strictness.value,
            check_time_ms=check_time
        )
    
    def _sanitize(self, text: str, threats: List[ThreatMatch]) -> str:
        """Sanitize text by removing/replacing detected threats."""
        sanitized = text
        
        # Remove invisible characters
        sanitized = remove_invisible_chars(sanitized)
        
        # Replace matched patterns with [FILTERED]
        for threat in threats:
            if threat.matched_text and len(threat.matched_text) > 3:
                # Replace the actual matched text
                sanitized = sanitized.replace(threat.matched_text, '[FILTERED]')
        
        # Clean up multiple [FILTERED] markers
        sanitized = re.sub(r'(\[FILTERED\]\s*)+', '[FILTERED] ', sanitized)
        
        # Remove excessive whitespace
        sanitized = re.sub(r'\n{3,}', '\n\n', sanitized)
        sanitized = re.sub(r' {5,}', '    ', sanitized)
        
        # Remove control characters except newlines and tabs
        sanitized = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', sanitized)
        
        return sanitized.strip()
    
    def _sanitize_output(self, text: str, threats: List[ThreatMatch]) -> str:
        """Sanitize output text."""
        sanitized = text
        
        # Remove HTML tags
        sanitized = re.sub(r'<script[^>]*>[\s\S]*?</script>', '', sanitized, flags=re.IGNORECASE)
        sanitized = re.sub(r'<iframe[^>]*>[\s\S]*?</iframe>', '', sanitized, flags=re.IGNORECASE)
        
        # Remove role injection in output
        sanitized = re.sub(r'(?i)^(system|assistant):', '', sanitized)
        
        return sanitized.strip()
    
    def _log_threats(self, result: CheckResult, context: Dict[str, Any] = None):
        """Log detected threats."""
        context = context or {}
        
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "is_safe": result.is_safe,
            "threat_count": result.threat_count,
            "highest_severity": result.highest_severity,
            "strictness": result.strictness,
            "check_time_ms": result.check_time_ms,
            "user_id": context.get("user_id"),
            "session_id": context.get("session_id"),
            "input_preview": truncate_for_logging(result.original_text or "", 200),
            "threats": [
                {
                    "category": t.category.value,
                    "severity": t.severity,
                    "description": t.description
                }
                for t in result.threats[:5]  # Limit to first 5 threats
            ]
        }
        
        if result.is_safe:
            logger.info(f"Prompt check passed with warnings: {log_entry}")
        else:
            logger.warning(f"Prompt check BLOCKED: {log_entry}")


# ==================== Convenience Functions ====================

# Global default instance
_default_guard: Optional[PromptGuard] = None


def get_default_guard() -> PromptGuard:
    """Get the default PromptGuard instance."""
    global _default_guard
    if _default_guard is None:
        _default_guard = PromptGuard(strictness="medium")
    return _default_guard


def sanitize_input(
    text: str,
    max_length: int = 2000,
    strictness: str = "medium"
) -> str:
    """
    Convenience function to sanitize user input.
    
    Args:
        text: User input to sanitize
        max_length: Maximum allowed length
        strictness: Protection level
        
    Returns:
        Sanitized text
    """
    guard = PromptGuard(strictness=strictness, max_length=max_length)
    result = guard.check_input(text)
    return result.sanitized_text or ""


def check_input(
    text: str,
    strictness: str = "medium",
    context: Dict[str, Any] = None
) -> CheckResult:
    """
    Convenience function to check user input.
    
    Args:
        text: User input to check
        strictness: Protection level
        context: Optional context for logging
        
    Returns:
        CheckResult with safety assessment
    """
    guard = PromptGuard(strictness=strictness)
    return guard.check_input(text, context)


def validate_output(
    text: str,
    context: Dict[str, Any] = None
) -> CheckResult:
    """
    Convenience function to validate agent output.
    
    Args:
        text: Agent output to validate
        context: Optional context for logging
        
    Returns:
        CheckResult with safety assessment
    """
    guard = get_default_guard()
    return guard.check_output(text, context)


def is_safe(text: str, strictness: str = "medium") -> bool:
    """
    Quick check if text is safe.
    
    Args:
        text: Text to check
        strictness: Protection level
        
    Returns:
        True if safe, False otherwise
    """
    return check_input(text, strictness).is_safe


# ==================== Database Integration ====================

def evaluate_safety_rules(
    text: str,
    rules: List[Dict[str, Any]],
    apply_to: str = "input"  # "input" or "output"
) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
    """
    Evaluate text against database safety rules.
    
    Args:
        text: Text to evaluate
        rules: List of SafetyRule dicts from database
        apply_to: Whether checking input or output
        
    Returns:
        Tuple of (is_allowed, matched_rule, action_message)
    """
    if not rules:
        return True, None, None
    
    text_lower = text.lower()
    
    for rule in sorted(rules, key=lambda r: -r.get("priority", 0)):
        # Check if rule applies
        if apply_to == "input" and not rule.get("apply_to_input", True):
            continue
        if apply_to == "output" and not rule.get("apply_to_output", False):
            continue
        
        # Check status
        if rule.get("status") not in ("active", "testing"):
            continue
        
        matched = False
        matched_content = None
        
        # Check keyword matches
        keywords = rule.get("match_keywords") or []
        for keyword in keywords:
            if keyword.lower() in text_lower:
                matched = True
                matched_content = keyword
                break
        
        # Check pattern matches
        if not matched:
            patterns = rule.get("match_patterns") or []
            for pattern in patterns:
                try:
                    if re.search(pattern, text, re.IGNORECASE):
                        matched = True
                        matched_content = pattern
                        break
                except re.error:
                    continue
        
        if matched:
            action = rule.get("action", "block")
            
            # Testing mode - just log
            if rule.get("status") == "testing":
                logger.info(f"Safety rule '{rule.get('name')}' matched (testing mode)")
                continue
            
            if action == "block":
                return False, rule, rule.get("action_message", "此消息已被安全规则拦截")
            elif action == "warn":
                logger.warning(f"Safety rule '{rule.get('name')}' matched: {matched_content}")
                # Continue processing but log
            elif action == "log_only":
                logger.info(f"Safety rule '{rule.get('name')}' matched: {matched_content}")
    
    return True, None, None
