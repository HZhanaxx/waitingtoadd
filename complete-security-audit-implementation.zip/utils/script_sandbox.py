"""
Script Sandbox
==============

Provides safe execution environment for user-defined scripts and conditions.
This replaces raw exec()/eval() to prevent Remote Code Execution (RCE) attacks.

Security Features:
- Whitelist of allowed builtins (no file access, no imports)
- Restricted global namespace
- Timeout protection
- Input/output size limits
- Dangerous pattern detection

Usage:
    from utils.script_sandbox import SafeScriptExecutor
    
    executor = SafeScriptExecutor()
    result = executor.execute_condition("amount > 1000", {"amount": 1500})
    result = executor.execute_script("result = input['a'] + input['b']", {"a": 1, "b": 2})
"""
import re
import ast
import time
from typing import Any, Dict, Optional, Tuple, List
from dataclasses import dataclass
from enum import Enum


class ScriptType(str, Enum):
    """Types of scripts that can be executed"""
    CONDITION = "condition"  # Boolean expression
    TRANSFORM = "transform"  # Data transformation
    VALIDATION = "validation"  # Input validation


@dataclass
class ExecutionResult:
    """Result of script execution"""
    success: bool
    output: Any = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    warnings: List[str] = None
    
    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []


# ==================== SECURITY CONFIGURATION ====================

# Whitelist of safe builtin functions
SAFE_BUILTINS = {
    # Type checking
    'isinstance': isinstance,
    'type': type,
    'len': len,
    'bool': bool,
    'int': int,
    'float': float,
    'str': str,
    'list': list,
    'dict': dict,
    'tuple': tuple,
    'set': set,
    
    # Basic operations
    'abs': abs,
    'min': min,
    'max': max,
    'sum': sum,
    'round': round,
    'sorted': sorted,
    'reversed': reversed,
    'enumerate': enumerate,
    'zip': zip,
    'range': range,
    'map': map,
    'filter': filter,
    
    # String operations
    'ord': ord,
    'chr': chr,
    
    # Boolean
    'True': True,
    'False': False,
    'None': None,
    
    # Comparison
    'all': all,
    'any': any,
}

# Dangerous patterns that should NEVER be allowed
DANGEROUS_PATTERNS = [
    # Import statements
    r'\bimport\s+',
    r'\bfrom\s+\w+\s+import\b',
    r'__import__\s*\(',
    
    # Attribute access to dangerous modules
    r'\b(os|sys|subprocess|shutil|pathlib)\b',
    r'\b(socket|urllib|requests|http)\b',
    r'\b(pickle|marshal|shelve)\b',
    r'\b(ctypes|cffi|ffi)\b',
    
    # Dangerous builtins
    r'\b(exec|eval|compile|open|input|print)\s*\(',
    r'\b(__builtins__|__class__|__bases__|__subclasses__)\b',
    r'\b(__globals__|__code__|__func__)\b',
    r'\b(globals|locals|vars|dir)\s*\(',
    r'\bgetattr\s*\(',
    r'\bsetattr\s*\(',
    r'\bdelattr\s*\(',
    r'\bhasattr\s*\(',
    
    # File operations
    r'\b(read|write|delete|remove|unlink)\b.*\bfile\b',
    r'\.read\s*\(|\.write\s*\(',
    
    # Command execution
    r'\bsystem\s*\(',
    r'\bpopen\s*\(',
    r'\bspawn\s*\(',
    r'\bcall\s*\(',
    r'\brun\s*\(',
    
    # Code objects
    r'\.co_\w+',
    r'\.func_\w+',
    r'\.f_\w+',
    
    # Lambda with dangerous operations
    r'lambda.*__',
]

# Maximum limits
MAX_SCRIPT_LENGTH = 5000  # Characters
MAX_INPUT_SIZE = 100000  # Characters for stringified input
MAX_EXECUTION_TIME_MS = 1000  # 1 second timeout
MAX_OUTPUT_SIZE = 50000  # Characters for stringified output


class ScriptSecurityError(Exception):
    """Raised when script contains dangerous code"""
    pass


class ScriptTimeoutError(Exception):
    """Raised when script execution times out"""
    pass


class SafeScriptExecutor:
    """
    Safely executes user-defined scripts in a sandboxed environment.
    
    This class provides controlled execution of:
    - Condition expressions (e.g., "amount > 1000 and category == 'A'")
    - Transform scripts (e.g., data transformation logic)
    - Validation rules (e.g., input validation patterns)
    """
    
    def __init__(
        self,
        max_script_length: int = MAX_SCRIPT_LENGTH,
        max_execution_time_ms: float = MAX_EXECUTION_TIME_MS,
        additional_allowed: Dict[str, Any] = None
    ):
        """
        Initialize the executor.
        
        Args:
            max_script_length: Maximum allowed script length in characters
            max_execution_time_ms: Maximum execution time in milliseconds
            additional_allowed: Additional safe functions/values to allow
        """
        self.max_script_length = max_script_length
        self.max_execution_time_ms = max_execution_time_ms
        
        # Build safe globals
        self.safe_globals = {"__builtins__": SAFE_BUILTINS.copy()}
        
        if additional_allowed:
            for name, value in additional_allowed.items():
                if self._is_safe_value(name, value):
                    self.safe_globals[name] = value
    
    def _is_safe_value(self, name: str, value: Any) -> bool:
        """Check if a value is safe to add to globals"""
        # Don't allow names starting with underscore
        if name.startswith('_'):
            return False
        
        # Check type of value
        if callable(value):
            # Only allow specific known-safe callables
            return False
        
        # Allow primitive types
        if isinstance(value, (int, float, str, bool, type(None), list, dict, tuple, set)):
            return True
        
        return False
    
    def _check_dangerous_patterns(self, script: str) -> List[str]:
        """
        Check script for dangerous patterns.
        
        Args:
            script: The script to check
            
        Returns:
            List of matched dangerous patterns (empty if safe)
        """
        found_patterns = []
        
        for pattern in DANGEROUS_PATTERNS:
            if re.search(pattern, script, re.IGNORECASE):
                found_patterns.append(pattern)
        
        return found_patterns
    
    def _validate_ast(self, script: str) -> Tuple[bool, Optional[str]]:
        """
        Validate script AST for dangerous constructs.
        
        Args:
            script: The script to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        try:
            tree = ast.parse(script, mode='exec')
        except SyntaxError as e:
            return False, f"Syntax error: {e.msg} at line {e.lineno}"
        
        # Walk the AST and check for dangerous nodes
        for node in ast.walk(tree):
            # Check for imports
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                return False, "Import statements are not allowed"
            
            # Check for dangerous function calls
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name):
                    if node.func.id in ('exec', 'eval', 'compile', 'open', '__import__'):
                        return False, f"Function '{node.func.id}' is not allowed"
                elif isinstance(node.func, ast.Attribute):
                    if node.func.attr in ('__class__', '__bases__', '__subclasses__'):
                        return False, f"Access to '{node.func.attr}' is not allowed"
            
            # Check for attribute access to dunders
            if isinstance(node, ast.Attribute):
                if node.attr.startswith('__') and node.attr.endswith('__'):
                    if node.attr not in ('__len__', '__str__', '__repr__', '__iter__'):
                        return False, f"Access to '{node.attr}' is not allowed"
        
        return True, None
    
    def validate_script(self, script: str) -> Tuple[bool, Optional[str]]:
        """
        Validate a script for security issues.
        
        Args:
            script: The script to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        # Check length
        if len(script) > self.max_script_length:
            return False, f"Script exceeds maximum length of {self.max_script_length} characters"
        
        # Check for dangerous patterns
        dangerous = self._check_dangerous_patterns(script)
        if dangerous:
            return False, f"Script contains dangerous patterns: {dangerous[0]}"
        
        # Validate AST
        is_valid, error = self._validate_ast(script)
        if not is_valid:
            return False, error
        
        return True, None
    
    def execute_condition(
        self,
        condition: str,
        context: Dict[str, Any] = None
    ) -> ExecutionResult:
        """
        Execute a boolean condition expression.
        
        Args:
            condition: Boolean expression (e.g., "amount > 1000")
            context: Variable context for the expression
            
        Returns:
            ExecutionResult with boolean output
        """
        start_time = time.time()
        
        try:
            # Validate
            is_valid, error = self.validate_script(condition)
            if not is_valid:
                return ExecutionResult(
                    success=False,
                    error=f"Validation failed: {error}",
                    execution_time_ms=(time.time() - start_time) * 1000
                )
            
            # Prepare locals
            local_vars = context.copy() if context else {}
            
            # Execute as expression
            try:
                # Parse as expression first
                ast.parse(condition, mode='eval')
                result = eval(condition, self.safe_globals.copy(), local_vars)
            except SyntaxError:
                # If not a simple expression, try exec
                exec(condition, self.safe_globals.copy(), local_vars)
                result = local_vars.get('result', local_vars.get('output', True))
            
            execution_time = (time.time() - start_time) * 1000
            
            # Check timeout
            if execution_time > self.max_execution_time_ms:
                return ExecutionResult(
                    success=False,
                    error="Execution timeout exceeded",
                    execution_time_ms=execution_time
                )
            
            return ExecutionResult(
                success=True,
                output=bool(result),
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            return ExecutionResult(
                success=False,
                error=f"Execution error: {str(e)}",
                execution_time_ms=(time.time() - start_time) * 1000
            )
    
    def execute_script(
        self,
        script: str,
        input_data: Dict[str, Any] = None
    ) -> ExecutionResult:
        """
        Execute a transformation script.
        
        The script should set a 'result' or 'output' variable.
        The input data is available as 'input' in the script.
        
        Args:
            script: Python script to execute
            input_data: Input data available as 'input' variable
            
        Returns:
            ExecutionResult with the output value
        """
        start_time = time.time()
        
        try:
            # Validate
            is_valid, error = self.validate_script(script)
            if not is_valid:
                return ExecutionResult(
                    success=False,
                    error=f"Validation failed: {error}",
                    execution_time_ms=(time.time() - start_time) * 1000
                )
            
            # Prepare execution environment
            local_vars = {"input": input_data or {}}
            
            # Execute
            exec(script, self.safe_globals.copy(), local_vars)
            
            # Get result
            output = local_vars.get('result', local_vars.get('output', None))
            
            execution_time = (time.time() - start_time) * 1000
            
            # Check timeout
            if execution_time > self.max_execution_time_ms:
                return ExecutionResult(
                    success=False,
                    error="Execution timeout exceeded",
                    execution_time_ms=execution_time
                )
            
            return ExecutionResult(
                success=True,
                output=output,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            return ExecutionResult(
                success=False,
                error=f"Execution error: {str(e)}",
                execution_time_ms=(time.time() - start_time) * 1000
            )
    
    def execute_validation(
        self,
        rule: str,
        value: Any
    ) -> ExecutionResult:
        """
        Execute a validation rule against a value.
        
        Args:
            rule: Validation expression (value available as 'value')
            value: The value to validate
            
        Returns:
            ExecutionResult with boolean indicating validity
        """
        return self.execute_condition(rule, {"value": value})


# ==================== CONVENIENCE FUNCTIONS ====================

# Global executor instance
_executor = None


def get_executor() -> SafeScriptExecutor:
    """Get the global script executor instance."""
    global _executor
    if _executor is None:
        _executor = SafeScriptExecutor()
    return _executor


def safe_execute_condition(
    condition: str,
    context: Dict[str, Any] = None
) -> ExecutionResult:
    """
    Safely execute a condition expression.
    
    Args:
        condition: Boolean expression to evaluate
        context: Variable context
        
    Returns:
        ExecutionResult
    """
    return get_executor().execute_condition(condition, context)


def safe_execute_script(
    script: str,
    input_data: Dict[str, Any] = None
) -> ExecutionResult:
    """
    Safely execute a transformation script.
    
    Args:
        script: Python script (should set 'result' or 'output')
        input_data: Input data (available as 'input')
        
    Returns:
        ExecutionResult
    """
    return get_executor().execute_script(script, input_data)


def validate_script(script: str) -> Tuple[bool, Optional[str]]:
    """
    Validate a script for security issues.
    
    Args:
        script: The script to validate
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    return get_executor().validate_script(script)
