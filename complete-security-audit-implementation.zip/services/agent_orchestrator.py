"""
Agent Orchestrator Service
==========================

Manages multi-agent workflows for case processing.
Handles agent routing, coordination, and handoffs.

Now supports dynamic workflow stages loaded from database.
"""
import uuid
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime
from enum import Enum
from dataclasses import dataclass, field
from sqlalchemy.orm import Session
from sqlalchemy import and_

from models.agent import Agent
from models.mother_point import MotherPoint, AgentMotherPoint, MotherPointResponse
from services.question_generator import QuestionGenerator
from services.mother_point_session import ConversationSessionManager, MotherPointSession


# ==================== Agent Types ====================

class AgentRole(str, Enum):
    """
    Agent roles in the workflow.
    
    Note: For dynamic roles, use the agent_types database table.
    """
    ROUTER = "router"           # Routes to appropriate domain agents
    DOMAIN = "domain"           # Handles specific domain (e.g., 医疗费)
    FETCH = "fetch"             # Fetches info via conversation
    ANALYZER = "analyzer"       # Analyzes collected data
    SUMMARIZER = "summarizer"   # Generates summaries
    DOCUMENT = "document"       # Generates documents


class WorkflowStage(str, Enum):
    """
    Legacy workflow stages enum.
    
    DEPRECATED: Use WorkflowStageManager for dynamic stages.
    This enum is maintained for backward compatibility only.
    New code should use get_workflow_stages() function.
    """
    INTAKE = "intake"           # Initial data collection
    ANALYSIS = "analysis"       # AI analysis
    REVIEW = "review"           # Professional review
    DOCUMENT_GEN = "document_generation"
    ASSIGNMENT = "assignment"   # Professional assignment
    PROCESSING = "processing"   # Case processing
    COMPLETED = "completed"


# ==================== Dynamic Stage Manager ====================

class WorkflowStageManager:
    """
    Manages workflow stages dynamically from database.
    
    Use this instead of the hardcoded WorkflowStage enum
    for dynamic stage configuration.
    """
    
    def __init__(self, db: Session):
        self.db = db
        self._stages_cache = None
        self._cache_time = None
    
    def get_stages(self, force_refresh: bool = False) -> List[Dict[str, Any]]:
        """
        Get all active workflow stages from database.
        
        Caches results for performance. Set force_refresh=True to bypass cache.
        """
        # Import here to avoid circular imports
        from models.workflow_stage import WorkflowStage as WorkflowStageModel
        
        # Check cache (5 minute TTL)
        if not force_refresh and self._stages_cache and self._cache_time:
            if (datetime.now() - self._cache_time).seconds < 300:
                return self._stages_cache
        
        stages = self.db.query(WorkflowStageModel).filter(
            WorkflowStageModel.is_active == True
        ).order_by(WorkflowStageModel.sort_order).all()
        
        self._stages_cache = [s.to_dict() for s in stages]
        self._cache_time = datetime.now()
        
        return self._stages_cache
    
    def get_stage_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Get a specific stage by name."""
        stages = self.get_stages()
        return next((s for s in stages if s['name'] == name), None)
    
    def get_next_stages(self, current_stage: str) -> List[str]:
        """Get allowed next stages from a given stage."""
        stage = self.get_stage_by_name(current_stage)
        if stage and stage.get('allowed_transitions'):
            return stage['allowed_transitions']
        return []
    
    def get_stage_for_agent_type(self, agent_type: str) -> Optional[str]:
        """Get the default stage for an agent type."""
        stages = self.get_stages()
        for stage in stages:
            if stage.get('agent_type_filter') == agent_type:
                return stage['name']
        return None
    
    def is_valid_stage(self, stage_name: str) -> bool:
        """Check if a stage name is valid."""
        return self.get_stage_by_name(stage_name) is not None
    
    def get_first_stage(self) -> Optional[str]:
        """Get the first stage in the workflow."""
        stages = self.get_stages()
        if stages:
            return stages[0]['name']
        return None
    
    def get_final_stages(self) -> List[str]:
        """Get stages that have no outgoing transitions (final stages)."""
        stages = self.get_stages()
        final = []
        for stage in stages:
            transitions = stage.get('allowed_transitions', [])
            if not transitions or transitions == ['completed']:
                final.append(stage['name'])
        return final


def get_workflow_stages(db: Session) -> List[Dict[str, Any]]:
    """
    Convenience function to get workflow stages.
    
    Use this instead of the WorkflowStage enum for dynamic stages.
    """
    manager = WorkflowStageManager(db)
    return manager.get_stages()


def get_stage_manager(db: Session) -> WorkflowStageManager:
    """Get a WorkflowStageManager instance."""
    return WorkflowStageManager(db)


# ==================== Data Classes ====================

@dataclass
class AgentContext:
    """Context passed between agents"""
    conversation_id: str
    user_id: Optional[str] = None
    case_id: Optional[str] = None
    current_stage: WorkflowStage = WorkflowStage.INTAKE
    collected_data: Dict[str, Any] = field(default_factory=dict)
    agent_history: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self):
        return {
            "conversation_id": self.conversation_id,
            "user_id": self.user_id,
            "case_id": self.case_id,
            "current_stage": self.current_stage.value,
            "collected_data": self.collected_data,
            "agent_history": self.agent_history,
            "metadata": self.metadata
        }


@dataclass
class AgentDecision:
    """Decision made by an agent"""
    action: str  # "continue", "handoff", "complete", "error"
    next_agent_id: Optional[str] = None
    message: Optional[str] = None
    data: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0


# ==================== Router Agent ====================

class RouterAgent:
    """
    Routes conversations to appropriate domain agents.
    Determines which mother points are relevant based on user input.
    """
    
    def __init__(self, db: Session):
        self.db = db
    
    def route(
        self,
        context: AgentContext,
        user_message: str
    ) -> AgentDecision:
        """
        Determine which domain agent should handle the request.
        
        Args:
            context: Current agent context
            user_message: User's message
        
        Returns:
            AgentDecision with next agent
        """
        # Get all domain agents
        domain_agents = self.db.query(Agent).filter(
            Agent.agent_type == 'domain',
            Agent.is_active == True
        ).order_by(Agent.sort_order).all()
        
        if not domain_agents:
            return AgentDecision(
                action="error",
                message="No domain agents available"
            )
        
        # Simple routing: return first domain agent
        # In production, use LLM to determine best agent based on user message
        first_agent = domain_agents[0]
        
        return AgentDecision(
            action="handoff",
            next_agent_id=str(first_agent.id),
            message=f"正在转接到{first_agent.display_name}...",
            confidence=0.9
        )
    
    def get_relevant_mother_points(
        self,
        user_message: str,
        case_category: str = "traffic_accident"
    ) -> List[Dict[str, Any]]:
        """
        Determine which mother points are relevant based on user input.
        
        Args:
            user_message: User's initial message
            case_category: Case category
        
        Returns:
            List of relevant mother points
        """
        # Get all active mother points for this category
        mother_points = self.db.query(MotherPoint).filter(
            MotherPoint.status == 'active',
            MotherPoint.category == case_category
        ).order_by(MotherPoint.sort_order).all()
        
        # Start with required ones
        required = [mp for mp in mother_points if mp.is_required]
        optional = [mp for mp in mother_points if not mp.is_required]
        
        # In production, use LLM to analyze user message and filter optional ones
        # For now, include all
        
        return [mp.to_dict() for mp in (required + optional)]


# ==================== Domain Agent Handler ====================

class DomainAgentHandler:
    """
    Handles domain-specific data collection using mother points.
    """
    
    def __init__(self, db: Session, agent_id: str):
        self.db = db
        self.agent_id = agent_id
        self.agent = self.db.query(Agent).filter(
            Agent.id == uuid.UUID(agent_id)
        ).first()
        self.question_generator = QuestionGenerator()
    
    def get_assigned_mother_points(self) -> List[Dict[str, Any]]:
        """Get mother points assigned to this agent."""
        assignments = self.db.query(AgentMotherPoint).filter(
            AgentMotherPoint.agent_id == uuid.UUID(self.agent_id),
            AgentMotherPoint.enabled == True
        ).order_by(AgentMotherPoint.sort_order).all()
        
        mother_points = []
        for assignment in assignments:
            mp = self.db.query(MotherPoint).filter(
                MotherPoint.id == assignment.mother_point_id,
                MotherPoint.status == 'active'
            ).first()
            if mp:
                mp_dict = mp.to_dict()
                # Apply any overrides from assignment
                if assignment.override_config:
                    mp_dict.update(assignment.override_config)
                mother_points.append(mp_dict)
        
        return mother_points
    
    async def process_message(
        self,
        context: AgentContext,
        user_message: str,
        session_manager: ConversationSessionManager
    ) -> Tuple[str, AgentDecision]:
        """
        Process a user message within this domain.
        
        Args:
            context: Agent context
            user_message: User's message
            session_manager: Session manager for this conversation
        
        Returns:
            Tuple of (response_message, decision)
        """
        # Get current session
        current_session = session_manager.get_current_session(context.conversation_id)
        
        if not current_session:
            # All mother points completed
            return (
                "数据收集完成！",
                AgentDecision(
                    action="complete",
                    data=context.collected_data
                )
            )
        
        # Process would be handled by conversation router
        # This is a simplified version
        response = f"[{self.agent.display_name}] 正在处理您的回答..."
        
        return (
            response,
            AgentDecision(action="continue")
        )


# ==================== Agent Orchestrator ====================

class AgentOrchestrator:
    """
    Orchestrates multi-agent workflows.
    
    Flow:
    1. Router agent determines domain
    2. Domain agents collect data via mother points
    3. Analyzer agent processes collected data
    4. Document agent generates documents
    5. Assignment agent handles professional matching
    """
    
    def __init__(self, db: Session):
        self.db = db
        self.router = RouterAgent(db)
        self._domain_handlers: Dict[str, DomainAgentHandler] = {}
        self._active_contexts: Dict[str, AgentContext] = {}
    
    def start_workflow(
        self,
        user_id: str,
        case_category: str = "traffic_accident",
        initial_message: str = None
    ) -> Tuple[str, AgentContext]:
        """
        Start a new workflow.
        
        Args:
            user_id: User's UUID
            case_category: Category of the case
            initial_message: Optional initial message
        
        Returns:
            Tuple of (conversation_id, context)
        """
        conversation_id = str(uuid.uuid4())
        
        context = AgentContext(
            conversation_id=conversation_id,
            user_id=user_id,
            current_stage=WorkflowStage.INTAKE,
            metadata={
                "case_category": case_category,
                "started_at": datetime.now().isoformat()
            }
        )
        
        self._active_contexts[conversation_id] = context
        
        return conversation_id, context
    
    def get_workflow_agents(
        self,
        case_category: str = "traffic_accident"
    ) -> Dict[str, List[Dict[str, Any]]]:
        """
        Get all agents involved in a workflow.
        
        Returns:
            Dict of agent_type -> list of agents
        """
        agents = self.db.query(Agent).filter(
            Agent.is_active == True
        ).all()
        
        result = {
            "router": [],
            "domain": [],
            "analyzer": [],
            "summarizer": [],
            "document": []
        }
        
        for agent in agents:
            agent_type = agent.agent_type
            if agent_type in result:
                result[agent_type].append(agent.to_dict())
        
        return result
    
    def get_workflow_status(
        self,
        conversation_id: str
    ) -> Dict[str, Any]:
        """
        Get status of a workflow.
        
        Args:
            conversation_id: The conversation ID
        
        Returns:
            Workflow status
        """
        context = self._active_contexts.get(conversation_id)
        
        if not context:
            return {"error": "Workflow not found"}
        
        # Get mother point responses
        responses = self.db.query(MotherPointResponse).filter(
            MotherPointResponse.session_id.like(f"{conversation_id}%")
        ).all()
        
        completed = sum(1 for r in responses if r.is_complete)
        total = len(responses)
        
        return {
            "conversation_id": conversation_id,
            "current_stage": context.current_stage.value,
            "progress": {
                "completed_mother_points": completed,
                "total_mother_points": total,
                "percentage": int((completed / total) * 100) if total > 0 else 0
            },
            "agent_history": context.agent_history,
            "started_at": context.metadata.get("started_at"),
            "case_id": context.case_id
        }
    
    def advance_stage(
        self,
        conversation_id: str,
        new_stage: WorkflowStage
    ) -> AgentContext:
        """
        Advance workflow to next stage.
        
        Args:
            conversation_id: The conversation ID
            new_stage: The new stage
        
        Returns:
            Updated context
        """
        context = self._active_contexts.get(conversation_id)
        if not context:
            raise ValueError("Workflow not found")
        
        context.current_stage = new_stage
        context.metadata["stage_changed_at"] = datetime.now().isoformat()
        
        return context
    
    def get_next_agent(
        self,
        conversation_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        Determine the next agent in the workflow.
        
        Args:
            conversation_id: The conversation ID
        
        Returns:
            Next agent info or None if complete
        """
        context = self._active_contexts.get(conversation_id)
        if not context:
            return None
        
        stage = context.current_stage
        
        if stage == WorkflowStage.INTAKE:
            # Get domain agents
            domain_agents = self.db.query(Agent).filter(
                Agent.agent_type == 'domain',
                Agent.is_active == True
            ).order_by(Agent.sort_order).all()
            
            # Find first unprocessed domain agent
            for agent in domain_agents:
                if str(agent.id) not in context.agent_history:
                    return agent.to_dict()
            
            # All domain agents done, move to analysis
            self.advance_stage(conversation_id, WorkflowStage.ANALYSIS)
            return self.get_next_agent(conversation_id)
        
        elif stage == WorkflowStage.ANALYSIS:
            # Get analyzer agent
            analyzer = self.db.query(Agent).filter(
                Agent.agent_type == 'analyzer',
                Agent.is_active == True
            ).first()
            
            if analyzer and str(analyzer.id) not in context.agent_history:
                return analyzer.to_dict()
            
            self.advance_stage(conversation_id, WorkflowStage.DOCUMENT_GEN)
            return self.get_next_agent(conversation_id)
        
        elif stage == WorkflowStage.DOCUMENT_GEN:
            # Get document agent
            doc_agent = self.db.query(Agent).filter(
                Agent.agent_type == 'document',
                Agent.is_active == True
            ).first()
            
            if doc_agent and str(doc_agent.id) not in context.agent_history:
                return doc_agent.to_dict()
            
            self.advance_stage(conversation_id, WorkflowStage.ASSIGNMENT)
            return self.get_next_agent(conversation_id)
        
        elif stage == WorkflowStage.ASSIGNMENT:
            # Ready for assignment
            self.advance_stage(conversation_id, WorkflowStage.COMPLETED)
            return None
        
        return None
    
    def complete_agent(
        self,
        conversation_id: str,
        agent_id: str,
        result_data: Dict[str, Any] = None
    ):
        """
        Mark an agent as complete in the workflow.
        
        Args:
            conversation_id: The conversation ID
            agent_id: The agent ID
            result_data: Data produced by the agent
        """
        context = self._active_contexts.get(conversation_id)
        if not context:
            return
        
        context.agent_history.append(agent_id)
        
        if result_data:
            context.collected_data.update(result_data)


# ==================== Workflow Builder ====================

class WorkflowBuilder:
    """
    Builds custom workflows from configuration.
    """
    
    def __init__(self, db: Session):
        self.db = db
    
    def build_intake_workflow(
        self,
        case_category: str,
        mother_point_ids: List[str] = None
    ) -> Dict[str, Any]:
        """
        Build an intake workflow configuration.
        
        Args:
            case_category: Case category
            mother_point_ids: Optional specific mother points
        
        Returns:
            Workflow configuration
        """
        # Get mother points
        if mother_point_ids:
            mother_points = self.db.query(MotherPoint).filter(
                MotherPoint.id.in_([uuid.UUID(id) for id in mother_point_ids]),
                MotherPoint.status == 'active'
            ).order_by(MotherPoint.sort_order).all()
        else:
            mother_points = self.db.query(MotherPoint).filter(
                MotherPoint.category == case_category,
                MotherPoint.status == 'active'
            ).order_by(MotherPoint.sort_order).all()
        
        # Build workflow
        steps = []
        for mp in mother_points:
            steps.append({
                "type": "mother_point",
                "mother_point_id": str(mp.id),
                "name": mp.name,
                "display_name": mp.display_name,
                "is_required": mp.is_required,
                "key_points_count": len(mp.key_points or [])
            })
        
        return {
            "case_category": case_category,
            "stages": [
                {
                    "name": "intake",
                    "display_name": "信息收集",
                    "steps": steps
                },
                {
                    "name": "analysis",
                    "display_name": "AI分析",
                    "steps": [{"type": "analyze"}]
                },
                {
                    "name": "document_generation",
                    "display_name": "文档生成",
                    "steps": [{"type": "generate_documents"}]
                },
                {
                    "name": "assignment",
                    "display_name": "专业对接",
                    "steps": [{"type": "assign_professional"}]
                }
            ],
            "total_steps": len(steps) + 3,
            "estimated_time": f"{len(steps) * 3 + 5}分钟"
        }


# ==================== Convenience Functions ====================

def create_orchestrator(db: Session) -> AgentOrchestrator:
    """Create an agent orchestrator instance."""
    return AgentOrchestrator(db)


def get_workflow_for_category(
    db: Session,
    case_category: str
) -> Dict[str, Any]:
    """Get workflow configuration for a case category."""
    builder = WorkflowBuilder(db)
    return builder.build_intake_workflow(case_category)
