"""
Base Agent - Headless Architecture
===================================

Pure headless implementation - ALL configuration from database.

The agent code contains NO business logic or prompts.
Everything is loaded from:
- agent_prompts table
- agent_router_rules table
- agent_llm_configs table
- agent_checklist_tree table

If database is empty, falls back to config/agent_defaults.py with WARNING.
Production systems should always run seed scripts first.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from datetime import datetime
from enum import Enum
import uuid
import logging
import re

from sqlalchemy.orm import Session
from sqlalchemy import text

from config import settings  # Import centralized config
from models.agent_session import AgentSession, SessionState, WorkflowPhase
from models.agent_prompt import AgentPrompt
from models.agent_llm_config import AgentLLMConfig
from models.agent_token_usage import AgentTokenUsage, record_token_usage
from services.llm_service import call_ollama
from services.navigator_service import NavigatorService, NavigatorResult
from services.agent_config_service import AgentConfigService

# Setup logging
logger = logging.getLogger(__name__)


# ===========================================
# Prompt Injection Protection
# ===========================================

# Import the centralized prompt guard module
from utils.prompt_guard import (
    PromptGuard,
    sanitize_input as _sanitize_input,
    check_input,
    validate_output,
    CheckResult,
    StrictnessLevel
)

# Default guard instance for this module
_module_guard = PromptGuard(strictness="medium", enable_logging=True)


def sanitize_for_prompt(
    text: str, 
    max_length: int = 2000,
    strictness: str = "medium",
    context: Dict[str, Any] = None
) -> str:
    """
    Sanitize user input before including in LLM prompts.
    
    This function protects against prompt injection attacks by:
    1. Truncating to max length
    2. Removing role/instruction markers that could hijack the prompt
    3. Detecting Unicode exploits and encoding bypasses
    4. Filtering jailbreak attempts
    5. Removing special tokens
    
    Uses the centralized PromptGuard module for comprehensive protection.
    
    Args:
        text: User input to sanitize
        max_length: Maximum allowed length (default 2000 chars)
        strictness: Protection level ("low", "medium", "high")
        context: Optional context for logging (user_id, session_id)
        
    Returns:
        Sanitized text safe for inclusion in prompts
    """
    if not text:
        return ""
    
    # Use the prompt guard for comprehensive checking
    guard = PromptGuard(
        strictness=strictness,
        max_length=max_length,
        enable_logging=True
    )
    
    result = guard.check_input(text, context)
    
    return result.sanitized_text or ""


def check_prompt_safety(
    text: str,
    strictness: str = "medium",
    context: Dict[str, Any] = None
) -> CheckResult:
    """
    Check user input for prompt injection without sanitizing.
    
    Use this when you need detailed information about detected threats.
    
    Args:
        text: User input to check
        strictness: Protection level ("low", "medium", "high")
        context: Optional context for logging
        
    Returns:
        CheckResult with is_safe, threats, and sanitized_text
    """
    guard = PromptGuard(strictness=strictness, enable_logging=True)
    return guard.check_input(text, context)


def validate_agent_output(
    text: str,
    context: Dict[str, Any] = None
) -> CheckResult:
    """
    Validate agent output for potential injection or manipulation.
    
    Some attacks attempt to inject content into agent responses
    that could affect future conversation turns.
    
    Args:
        text: Agent output to validate
        context: Optional context for logging
        
    Returns:
        CheckResult with validation results
    """
    return validate_output(text, context)


def sanitize_collected_data(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Sanitize all string values in collected data before using in prompts.
    
    Args:
        data: Dictionary of collected data
        
    Returns:
        Sanitized dictionary
    """
    if not data:
        return {}
    
    sanitized = {}
    for key, value in data.items():
        if isinstance(value, str):
            sanitized[key] = sanitize_for_prompt(value, max_length=1000)
        elif isinstance(value, dict):
            sanitized[key] = sanitize_collected_data(value)
        elif isinstance(value, list):
            sanitized[key] = [
                sanitize_for_prompt(v, max_length=1000) if isinstance(v, str) else v
                for v in value
            ]
        else:
            sanitized[key] = value
    return sanitized


class ResponseType(Enum):
    """Type of agent response."""
    TEXT = "text"
    QUESTION = "question"
    OPTIONS = "options"
    CONFIRMATION = "confirmation"
    TRANSITION = "transition"
    COMPLETE = "complete"
    ERROR = "error"


@dataclass
class AgentResponse:
    """Standardized response from any agent."""
    message: str
    message_type: ResponseType = ResponseType.TEXT
    options: Optional[List[Dict[str, Any]]] = None
    metadata: Optional[Dict[str, Any]] = None
    should_transition: bool = False
    transition_to_agent: Optional[str] = None
    transition_to_phase: Optional[str] = None
    transition_reason: Optional[str] = None
    collected_data: Optional[Dict[str, Any]] = None
    completion_stats: Optional[Dict[str, int]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "message": self.message,
            "message_type": self.message_type.value,
            "options": self.options,
            "metadata": self.metadata,
            "should_transition": self.should_transition,
            "transition_to_agent": self.transition_to_agent,
            "transition_to_phase": self.transition_to_phase,
            "transition_reason": self.transition_reason,
            "collected_data": self.collected_data,
            "completion_stats": self.completion_stats,
        }


class BaseAgent(ABC):
    """
    Base Agent - Headless Architecture
    
    ALL configuration comes from database:
    - Prompts: agent_prompts table
    - Router rules: agent_router_rules table
    - LLM config: agent_llm_configs table
    - Checklist: agent_checklist_tree table
    
    NO hardcoded prompts or business logic in code.
    """
    
    # Subclasses must define their type
    AGENT_TYPE: str = "base"
    
    def __init__(self, agent_id: str, db: Session):
        self.agent_id = agent_id
        self.db = db
        
        # Services - initialized lazily
        self._navigator: Optional[NavigatorService] = None
        self._config_service: Optional[AgentConfigService] = None
        
        # Cached config from DB
        self._prompts: Dict[str, str] = {}
        self._router_rules: List[Dict] = []
        self._llm_config: Optional[Dict] = None
        
        # Track if we're using fallback defaults
        self._using_defaults = False
    
    async def initialize(self):
        """Load all configuration from database."""
        await self._load_prompts()
        await self._load_router_rules()
        await self._load_llm_config()
        
        if self._using_defaults:
            logger.warning(
                f"Agent {self.AGENT_TYPE} ({self.agent_id}) is using fallback defaults. "
                "Run seed script to populate database for production."
            )
    
    # ==================== Config Loading (DB First) ====================
    
    async def _load_prompts(self):
        """Load prompts from database. Fallback to defaults only if empty."""
        try:
            # Validate agent_id is a valid UUID
            try:
                agent_uuid = uuid.UUID(self.agent_id)
            except (ValueError, TypeError) as e:
                logger.error(f"Invalid agent_id format: {self.agent_id} - {e}")
                self._load_default_prompts()
                return
            
            prompts = self.db.query(AgentPrompt).filter(
                AgentPrompt.agent_id == agent_uuid,
                AgentPrompt.is_active == True
            ).all()
            
            if prompts:
                self._prompts = {p.prompt_key: p.prompt_template for p in prompts}
                logger.debug(f"Loaded {len(prompts)} prompts from database for {self.AGENT_TYPE}")
            else:
                # Fallback to defaults
                self._load_default_prompts()
                
        except Exception as e:
            logger.error(f"Error loading prompts: {e}")
            self._load_default_prompts()
    
    def _load_default_prompts(self):
        """Load defaults from config file - NOT from agent code."""
        try:
            from agent_config.agent_defaults import get_all_defaults
            self._prompts = get_all_defaults(self.AGENT_TYPE)
            self._using_defaults = True
            logger.warning(f"Using default prompts for {self.AGENT_TYPE} - database is empty")
        except ImportError:
            logger.error("Could not load default prompts - config/agent_defaults.py missing")
            self._prompts = {}
    
    async def _load_router_rules(self):
        """Load router rules from database."""
        try:
            result = self.db.execute(text("""
                SELECT rule_name, condition_type, condition_value, 
                       target_agent_id, target_phase, priority, metadata
                FROM agent_router_rules
                WHERE agent_id = :agent_id AND is_active = true
                ORDER BY priority ASC
            """), {"agent_id": self.agent_id})
            
            self._router_rules = [
                {
                    "rule_name": row[0],
                    "condition_type": row[1],
                    "condition_value": row[2],
                    "target_agent_id": str(row[3]) if row[3] else None,
                    "target_phase": row[4],
                    "priority": row[5],
                    "metadata": row[6] or {}
                }
                for row in result
            ]
            
            logger.debug(f"Loaded {len(self._router_rules)} router rules for {self.AGENT_TYPE}")
            
        except Exception as e:
            logger.error(f"Error loading router rules: {e}")
            self._router_rules = []
    
    async def _load_llm_config(self):
        """Load LLM configuration from database."""
        try:
            config = self.db.query(AgentLLMConfig).filter(
                AgentLLMConfig.agent_id == uuid.UUID(self.agent_id),
                AgentLLMConfig.is_active == True
            ).first()
            
            if config:
                self._llm_config = {
                    "model_name": config.model_name,
                    "temperature": config.temperature,
                    "max_tokens": config.max_tokens,
                    "top_p": config.top_p,
                    "timeout": config.timeout_seconds,
                }
            else:
                # Default LLM config - use centralized settings
                self._llm_config = {
                    "model_name": settings.OLLAMA_MODEL,
                    "temperature": 0.7,
                    "max_tokens": 2000,
                    "top_p": 0.9,
                    "timeout": 60,
                }
                logger.info(f"Using default LLM config for {self.AGENT_TYPE}: {settings.OLLAMA_MODEL}")
                
        except Exception as e:
            logger.error(f"Error loading LLM config: {e}")
            # Fallback to centralized settings
            self._llm_config = {"model_name": settings.OLLAMA_MODEL, "temperature": 0.7}
    
    # ==================== Prompt Access ====================
    
    def get_prompt(self, key: str, variables: Optional[Dict[str, Any]] = None) -> str:
        """
        Get prompt by key and format with variables.
        
        Always uses database prompts. Falls back to defaults only if DB empty.
        """
        template = self._prompts.get(key, "")
        
        if not template:
            logger.warning(f"Prompt '{key}' not found for {self.AGENT_TYPE}")
            return ""
        
        if variables:
            try:
                return template.format(**variables)
            except KeyError as e:
                logger.warning(f"Missing variable {e} in prompt '{key}'")
                return template
        
        return template
    
    def has_prompt(self, key: str) -> bool:
        """Check if a prompt exists."""
        return key in self._prompts
    
    # ==================== Router Rules ====================
    
    def get_router_rule(self, condition_type: str, condition_value: str = None) -> Optional[Dict]:
        """Find matching router rule."""
        for rule in self._router_rules:
            if rule["condition_type"] == condition_type:
                if condition_value is None or rule["condition_value"] == condition_value:
                    return rule
        return None
    
    def get_transition_target(self, reason: str) -> Optional[Dict[str, str]]:
        """Get transition target based on reason."""
        rule = self.get_router_rule("transition", reason)
        if rule:
            return {
                "agent_id": rule["target_agent_id"],
                "phase": rule["target_phase"]
            }
        return None
    
    # ==================== Services ====================
    
    @property
    def navigator(self) -> NavigatorService:
        """Get Navigator service (lazy init)."""
        if self._navigator is None:
            self._navigator = NavigatorService(self.db)
        return self._navigator
    
    @property
    def config_service(self) -> AgentConfigService:
        """Get Config service (lazy init)."""
        if self._config_service is None:
            self._config_service = AgentConfigService(self.db)
        return self._config_service
    
    # ==================== LLM Calls ====================
    
    async def call_llm(
        self,
        prompt: str,
        session: AgentSession,
        purpose: str = "general",
        system_prompt: Optional[str] = None,
        expect_json: bool = False
    ) -> tuple[str, Dict[str, int]]:
        """
        Call LLM with tracking and configuration from database.
        
        Returns: (response_text, token_usage)
        """
        if system_prompt is None:
            system_prompt = self.get_prompt("system_prompt")
        
        config = self._llm_config or {}
        
        # Use centralized settings as fallback for model name
        model_name = config.get("model_name") or settings.OLLAMA_MODEL
        
        try:
            response = await call_ollama(
                prompt=prompt,
                system_prompt=system_prompt,
                model=model_name,
                temperature=config.get("temperature", 0.7),
                max_tokens=config.get("max_tokens", 2000),
            )
            
            # Track token usage
            token_usage = {
                "prompt_tokens": len(prompt) // 4,
                "completion_tokens": len(response) // 4,
                "total_tokens": (len(prompt) + len(response)) // 4
            }
            
            # Record to database
            try:
                record_token_usage(
                    db=self.db,
                    agent_id=uuid.UUID(self.agent_id),
                    session_id=session.id,
                    model_name=model_name,
                    prompt_tokens=token_usage["prompt_tokens"],
                    completion_tokens=token_usage["completion_tokens"],
                    purpose=purpose
                )
            except Exception as e:
                logger.warning(f"Failed to record token usage: {e}")
            
            return response, token_usage
            
        except Exception as e:
            logger.error(f"LLM call failed: {e}")
            return "", {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    
    # ==================== Session Management ====================
    
    def update_session_data(self, session: AgentSession, key: str, value: Any):
        """Update collected data in session."""
        if session.collected_data is None:
            session.collected_data = {}
        session.collected_data[key] = value
        session.updated_at = datetime.utcnow()
    
    def get_session_data(self, session: AgentSession, key: str, default: Any = None) -> Any:
        """Get data from session."""
        if session.collected_data is None:
            return default
        return session.collected_data.get(key, default)
    
    # ==================== Abstract Methods ====================
    
    @abstractmethod
    async def get_initial_message(self, session: AgentSession) -> AgentResponse:
        """Get the initial message when this agent starts."""
        pass
    
    @abstractmethod
    async def process_message(
        self,
        session: AgentSession,
        message: str,
        context: Optional[Dict[str, Any]] = None
    ) -> AgentResponse:
        """Process a user message and return response."""
        pass
    
    # ==================== Utility Methods ====================
    
    def create_transition_response(
        self,
        message: str,
        target_agent_id: str,
        target_phase: str,
        reason: str
    ) -> AgentResponse:
        """Create a response that triggers agent transition."""
        return AgentResponse(
            message=message,
            message_type=ResponseType.TRANSITION,
            should_transition=True,
            transition_to_agent=target_agent_id,
            transition_to_phase=target_phase,
            transition_reason=reason
        )
    
    def create_options_response(
        self,
        message: str,
        options: List[Dict[str, str]]
    ) -> AgentResponse:
        """Create a response with selectable options."""
        return AgentResponse(
            message=message,
            message_type=ResponseType.OPTIONS,
            options=options
        )
    
    def create_question_response(
        self,
        question: str,
        hint: Optional[str] = None,
        input_type: str = "text"
    ) -> AgentResponse:
        """Create a question response."""
        return AgentResponse(
            message=question,
            message_type=ResponseType.QUESTION,
            metadata={
                "hint": hint,
                "input_type": input_type
            }
        )
