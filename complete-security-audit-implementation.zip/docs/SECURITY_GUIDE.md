# Security Configuration Guide

Comprehensive guide for configuring the security features of the Legal Assistant Agent Studio.

## Table of Contents

1. [Overview](#overview)
2. [Prompt Protection](#prompt-protection)
3. [Safety Rules](#safety-rules)
4. [Script Sandbox](#script-sandbox)
5. [Environment Security](#environment-security)
6. [Best Practices](#best-practices)
7. [Monitoring & Logging](#monitoring--logging)

---

## Overview

The Agent Studio includes multiple layers of security:

1. **Prompt Protection** - Detects and blocks prompt injection attacks
2. **Safety Rules** - Configurable rules for content filtering
3. **Script Sandbox** - Safe execution of admin-defined scripts
4. **Environment Security** - Secure configuration management

---

## Prompt Protection

### Strictness Levels

The `PromptGuard` module supports three strictness levels:

| Level | Description | Use Case |
|-------|-------------|----------|
| `low` | Only critical threats | High-throughput, low false-positive |
| `medium` | Critical + High severity | **Recommended** for most applications |
| `high` | All patterns | Maximum security, may have false positives |

### Configuration Examples

**Python - Direct Usage:**
```python
from utils.prompt_guard import PromptGuard, sanitize_input

# Default (medium strictness)
safe_text = sanitize_input(user_message)

# High strictness for sensitive operations
guard = PromptGuard(strictness="high", max_length=5000)
result = guard.check_input(user_message)

if not result.is_safe:
    print(f"Blocked: {result.highest_severity}")
    for threat in result.threats:
        print(f"  - {threat.category}: {threat.description}")
else:
    process_message(result.sanitized_text)
```

**API Usage:**
```bash
curl -X POST http://localhost:8000/api/agent-management/validate-prompt \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "User input here",
    "strictness": "high",
    "check_type": "input"
  }'
```

### Threat Categories

| Category | Examples | Default Severity |
|----------|----------|-----------------|
| `role_injection` | `system:`, `[INST]`, `助手:` | high-critical |
| `instruction_override` | `ignore previous`, `新指令:` | critical |
| `jailbreak` | `DAN mode`, `bypass filter` | critical |
| `special_token` | `<\|endoftext\|>`, `[PAD]` | critical |
| `code_injection` | `exec()`, `import os` | high |
| `unicode_exploit` | Zero-width chars, homoglyphs | medium-high |
| `output_manipulation` | Fake response markers | medium-high |

### Adding Custom Patterns

```python
from utils.prompt_guard import PromptGuard

# Add custom patterns
custom_patterns = [
    (r"my_forbidden_phrase", "high", "Custom blocked phrase"),
    (r"(?i)internal\s+api\s+key", "critical", "API key leak attempt"),
]

guard = PromptGuard(
    strictness="medium",
    custom_patterns=custom_patterns
)
```

### Unicode Protection

The guard automatically detects:
- **Zero-width characters** (hidden text)
- **Bidirectional overrides** (text direction manipulation)
- **Homoglyphs** (lookalike characters from other alphabets)

```python
# Example: Cyrillic 'а' looks like Latin 'a'
text = "system: ignore previous"  # With Cyrillic 'а'
result = guard.check_input(text)
# Detects both the Cyrillic character AND the role injection
```

---

## Safety Rules

### Rule Types

| Type | Description | Use Case |
|------|-------------|----------|
| `input_filter` | Filter/block user inputs | Content moderation |
| `output_filter` | Filter agent outputs | Response validation |
| `jailbreak` | Detect jailbreak attempts | Security |
| `language` | Language detection | Enforce language policy |
| `moderation` | Content moderation | Policy enforcement |
| `rate_limit` | Rate limiting | Abuse prevention |
| `length_limit` | Message length limits | Resource protection |

### Creating Rules via API

**Keyword-based Rule:**
```json
{
  "name": "block_competitor_mentions",
  "display_name": "竞争对手过滤",
  "rule_type": "keyword",
  "description": "Block mentions of competitor companies",
  "match_keywords": ["Competitor A", "Competitor B"],
  "action": "block",
  "action_message": "Please refrain from mentioning competitor products.",
  "priority": 50,
  "status": "active",
  "apply_to_input": true,
  "apply_to_output": true
}
```

**Pattern-based Rule:**
```json
{
  "name": "validate_phone_number",
  "display_name": "电话号码验证",
  "rule_type": "regex",
  "description": "Validate phone number format",
  "match_patterns": ["^\\d{11}$"],
  "action": "warn",
  "action_message": "Please enter a valid 11-digit phone number.",
  "priority": 30,
  "status": "active"
}
```

### Rule Priority

Rules are evaluated in priority order (higher first). When a rule matches:

1. **block** - Stop processing, return error message
2. **warn** - Log warning, continue processing
3. **modify** - Apply modification script, continue
4. **log_only** - Log match, continue without action
5. **confirm** - Require user confirmation

### Testing Rules

Before activating a rule, test it:

```bash
# Check if text would be blocked
curl -X POST http://localhost:8000/api/agent-management/check-safety-rules \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Test message with Competitor A",
    "apply_to": "input"
  }'
```

### Rule Status Lifecycle

```
draft → testing → active → inactive
```

- **draft** - Not evaluated
- **testing** - Evaluated but only logs (no blocking)
- **active** - Fully enforced
- **inactive** - Disabled

---

## Script Sandbox

### Security Features

The `SafeScriptExecutor` provides:

1. **Whitelist-only builtins** - No file access, no imports
2. **AST validation** - Checks code structure before execution
3. **Regex pattern blocking** - Detects dangerous keywords
4. **Execution timeout** - Default 1000ms limit
5. **Size limits** - Script: 5000 chars, Input: 100KB, Output: 50KB

### Allowed Operations

```python
# Safe operations
result = input['amount'] * 1.1
result = sum(input['values'])
result = len(input['items'])
result = input.get('key', 'default')

# Conditional evaluation
result = input['amount'] > 1000
result = 'keyword' in input['text'].lower()
```

### Blocked Operations

```python
# These will be blocked:
import os                      # No imports
open('/etc/passwd')            # No file access
exec("print('hi')")            # No dynamic code
__builtins__                   # No access to internals
subprocess.run(['ls'])         # No subprocess
```

### Testing Scripts

**Via API:**
```bash
# Test script execution
curl -X POST http://localhost:8000/api/agent-management/test-script \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "script": "result = input[\"amount\"] * 1.1",
    "script_type": "transform",
    "test_input": {"amount": 100}
  }'

# Validate without execution
curl -X POST http://localhost:8000/api/agent-management/validate-script \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "script": "import os",
    "script_type": "transform"
  }'
```

**Via Admin UI:**
1. Go to Agent Management → Security Rules
2. Click "🔒 测试提示词安全"
3. Enter script and test input
4. Click "Run Safety Check"

---

## Environment Security

### Required Environment Variables

Create a `.env` file with these required variables:

```bash
# REQUIRED - Generate with: openssl rand -base64 64
SECRET_KEY=your_64_char_secret_key_here

# REQUIRED - PostgreSQL connection
DATABASE_URL=postgresql://user:password@localhost:5432/legal_assistant

# Optional but recommended
REDIS_URL=redis://localhost:6379
ELASTICSEARCH_HOST=localhost
ELASTICSEARCH_PORT=9200
```

### SECRET_KEY Requirements

- **Minimum 32 characters**
- Generated securely: `openssl rand -base64 64`
- Never use placeholder values
- Never commit to version control

**Validation:**
The application will fail to start if:
- SECRET_KEY is missing
- SECRET_KEY is less than 32 characters
- SECRET_KEY contains placeholder values like "change_me"

### Database URL Requirements

- Must be a valid PostgreSQL connection string
- Format: `postgresql://user:password@host:port/database`
- Application validates format on startup

---

## Best Practices

### 1. Defense in Depth

Use multiple security layers:
```
User Input → Rate Limit → Safety Rules → Prompt Guard → Agent → Output Filter
```

### 2. Start with Testing Mode

Always test new rules before activating:
```json
{
  "status": "testing",
  "log_matches": true
}
```

Review logs, then change to `active`.

### 3. Use Appropriate Strictness

| Environment | Recommended Strictness |
|-------------|----------------------|
| Development | `low` |
| Staging | `medium` |
| Production | `medium` or `high` |

### 4. Monitor and Adjust

- Review safety logs regularly
- Adjust rules based on false positives
- Update patterns for new attack vectors

### 5. Secure Admin Access

- Use strong admin passwords
- Implement IP whitelisting if possible
- Enable 2FA for admin accounts
- Regular audit of admin actions

### 6. Keep Dependencies Updated

```bash
pip install --upgrade pydantic fastapi sqlalchemy
```

### 7. Regular Security Audits

- Review safety rule effectiveness monthly
- Test prompt injection resistance quarterly
- Penetration testing annually

---

## Monitoring & Logging

### Safety Event Logs

All security events are logged to the `safety_logs` table:

```sql
SELECT 
  rule_name,
  action_taken,
  was_blocked,
  COUNT(*) as count
FROM safety_logs
WHERE created_at > NOW() - INTERVAL '24 hours'
GROUP BY rule_name, action_taken, was_blocked
ORDER BY count DESC;
```

### Log Fields

| Field | Description |
|-------|-------------|
| `rule_id` | UUID of matched rule |
| `rule_name` | Name of matched rule |
| `user_id` | User who triggered |
| `session_id` | Session identifier |
| `input_preview` | First 500 chars of input |
| `matched_content` | What triggered the rule |
| `action_taken` | Action performed |
| `was_blocked` | Whether blocked |
| `created_at` | Timestamp |

### Viewing Logs via API

```bash
# Get recent safety logs
curl http://localhost:8000/api/agent-management/safety-logs \
  -H "Authorization: Bearer $TOKEN"

# Filter by rule
curl "http://localhost:8000/api/agent-management/safety-logs?rule_id=<uuid>" \
  -H "Authorization: Bearer $TOKEN"
```

### Alert Configuration

For high-priority rules, enable alerts:
```json
{
  "alert_on_match": true,
  "priority": 100
}
```

Configure alert delivery via your monitoring system (e.g., Prometheus, DataDog, PagerDuty).

---

## Troubleshooting

### False Positives

If legitimate inputs are being blocked:

1. Check which pattern matched:
   ```bash
   curl -X POST /api/agent-management/validate-prompt \
     -d '{"text": "blocked text", "strictness": "high"}'
   ```

2. Lower strictness for that operation
3. Add exceptions to safety rules
4. Use custom patterns to exclude false positives

### Performance Issues

If prompt validation is slow:

1. Check input length (reduce if >10KB)
2. Reduce number of active rules
3. Use `low` strictness for high-throughput paths
4. Cache validation results for repeated inputs

### Rule Not Working

1. Verify rule status is `active`
2. Check priority order
3. Verify `apply_to_input` or `apply_to_output` is set correctly
4. Test rule directly via API
5. Check logs for matches

---

## Quick Reference

### Strictness Comparison

| Pattern Type | Low | Medium | High |
|--------------|-----|--------|------|
| Critical threats | ✓ | ✓ | ✓ |
| High severity | ✗ | ✓ | ✓ |
| Medium severity | ✗ | ✗ | ✓ |
| Low severity | ✗ | ✗ | ✓ |
| Unicode detection | ✗ | ✗ | ✓ |

### Safety Rule Actions

| Action | Blocks | Logs | User Message |
|--------|--------|------|--------------|
| block | ✓ | ✓ | ✓ |
| warn | ✗ | ✓ | ✓ |
| modify | ✗ | ✓ | ✗ |
| log_only | ✗ | ✓ | ✗ |
| confirm | ✗ | ✓ | ✓ |
