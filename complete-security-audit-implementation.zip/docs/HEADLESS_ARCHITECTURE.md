# Headless Agent Architecture - Complete Implementation

## Overview

This document describes the complete refactoring from hardcoded agent logic to a **database-driven "headless" architecture** where ALL business logic is stored in the database and controlled via Admin UI.

## Architecture Comparison

### Before (V1 - Hardcoded)
```
┌─────────────────────────────────────────────────────┐
│  Python Agent Code                                  │
│  ┌─────────────────────────────────────────────┐   │
│  │ MOTHER_POINTS = {                           │   │
│  │   "medical_expenses": {...},                │   │
│  │   "lost_income": {...}                      │   │
│  │ }                                           │   │
│  │                                             │   │
│  │ if answer == "no":                          │   │
│  │     skip_children()                         │   │
│  │                                             │   │
│  │ COMPENSATION_RULES = {...}                  │   │
│  └─────────────────────────────────────────────┘   │
│  Business logic hardcoded in Python                 │
└─────────────────────────────────────────────────────┘
```

### After (V2 - Headless)
```
┌─────────────────────────────────────────────────────┐
│  Database (The Brain)                               │
│  ┌─────────────────────────────────────────────┐   │
│  │ agent_checklist_tree          │ Questions   │   │
│  │ agent_compensation_rules      │ Rules       │   │
│  │ agent_legal_rights            │ Rights      │   │
│  │ agent_risk_factors            │ Risks       │   │
│  │ agent_router_rules            │ Routing     │   │
│  │ agent_document_types          │ Templates   │   │
│  │ agent_variable_mappings       │ Extraction  │   │
│  └─────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────┘
          │
          ▼
┌─────────────────────────────────────────────────────┐
│  Python Engine (The Engine)                         │
│  ┌─────────────────────────────────────────────┐   │
│  │ Navigator Service                           │   │
│  │   - get_next_target()                       │   │
│  │   - check_gatekeeper_logic()                │   │
│  │   - record_answer()                         │   │
│  │                                             │   │
│  │ Config Service                              │   │
│  │   - get_prompts()                           │   │
│  │   - calculate_compensation()                │   │
│  │   - detect_risks()                          │   │
│  └─────────────────────────────────────────────┘   │
│  Generic engine that executes DB instructions       │
└─────────────────────────────────────────────────────┘
          │
          ▼
┌─────────────────────────────────────────────────────┐
│  Admin UI (The Pilot)                               │
│  ┌─────────────────────────────────────────────┐   │
│  │ Tree Editor        │ Question hierarchy     │   │
│  │ Config Management  │ Rules, rights, risks   │   │
│  │ Prompt Editor      │ All prompts            │   │
│  │ Router Rules       │ Triage routing         │   │
│  └─────────────────────────────────────────────┘   │
│  No-code interface to control agent behavior        │
└─────────────────────────────────────────────────────┘
```

## Files Created/Updated

### Phase 1: Database Schema (~594 lines)

| File | Lines | Purpose |
|------|-------|---------|
| `migrations/009_configurable_agent_settings.sql` | 352 | Document types, variable mappings, rules tables |
| `migrations/010_checklist_tree_navigator.sql` | 242 | Checklist tree, progress tracking, router rules |

### Phase 2: SQLAlchemy Models (~958 lines)

| File | Lines | Purpose |
|------|-------|---------|
| `models/agent_config.py` | 603 | Config models (doc types, rules, rights, risks) |
| `models/checklist_tree.py` | 355 | Tree node, progress, router rule models |

### Phase 3: Core Services (~1,178 lines)

| File | Lines | Purpose |
|------|-------|---------|
| `services/agent_config_service.py` | 583 | Config loading with caching |
| `services/navigator_service.py` | 596 | **THE CORE ALGORITHM** - tree traversal |

### Phase 4: V2 Agents (~2,182 lines)

| File | Lines | Purpose |
|------|-------|---------|
| `services/agents/base_agent_v2.py` | 427 | Base class with Navigator/Config integration |
| `services/agents/professional_agent_v2.py` | 431 | Domain Q&A using Navigator |
| `services/agents/triage_agent_v2.py` | 399 | Routing using DB rules |
| `services/agents/analysis_agent_v2.py` | 382 | Analysis using DB rules |
| `services/agents/generation_agent_v2.py` | 543 | Document generation using DB mappings |

### Phase 5: API Routers (~1,478 lines)

| File | Lines | Purpose |
|------|-------|---------|
| `routers/agent_config.py` | 852 | CRUD for all config types |
| `routers/checklist_tree.py` | 626 | Tree management API |

### Phase 6: Admin UI (~2,340 lines)

| File | Lines | Purpose |
|------|-------|---------|
| `frontend/src/views/admin/TreeEditor.vue` | 364 | Visual tree editor |
| `frontend/src/components/TreeNode.vue` | 122 | Tree node component |
| `frontend/src/views/admin/DocumentTypeManagement.vue` | 271 | Document types CRUD |
| `frontend/src/views/admin/VariableMappingManagement.vue` | 289 | Variable mappings CRUD |
| `frontend/src/views/admin/CompensationRuleManagement.vue` | 334 | Compensation rules CRUD |
| `frontend/src/views/admin/LegalRightManagement.vue` | 301 | Legal rights CRUD |
| `frontend/src/views/admin/RiskFactorManagement.vue` | 326 | Risk factors CRUD |
| `frontend/src/views/admin/CaseTypeConfigManagement.vue` | 333 | Case type config CRUD |

### Phase 7: Seed Scripts (~1,233 lines)

| File | Lines | Purpose |
|------|-------|---------|
| `scripts/seed_agent_configs.py` | 721 | Seed config data |
| `scripts/seed_checklist_tree.py` | 512 | Seed tree structure |

### Phase 8: Updated Files

| File | Change |
|------|--------|
| `services/agents/__init__.py` | Export V2 agents, factory functions with USE_V2_AGENTS toggle |
| `main.py` | Register new routers |
| `frontend/src/router/index.js` | Add admin routes |
| `frontend/src/views/AdminDashboard.vue` | Add navigation cards |

## Total Lines: ~9,963

---

## The Navigator Algorithm

The heart of the headless system:

```python
async def get_next_target(session_id, agent_id, case_type):
    """
    THE CORE ALGORITHM
    
    Replaces hardcoded MOTHER_POINTS iteration.
    
    1. Fetch tree from agent_checklist_tree
    2. Fetch progress from session_checklist_progress
    3. For each Mother Point (ordered):
       a. If PENDING → Return as target
       b. If ANSWERED:
          - Check gatekeeper_logic
          - If skip_children triggered → Mark children skipped
          - Else → Process children recursively
    4. All done → Return is_complete=True
    """
```

### Gatekeeper Logic Example

Database field `gatekeeper_logic`:
```json
{
    "trigger_condition": {"value": "no", "operator": "equals"},
    "action": "skip_children"
}
```

When user answers "no" to "是否受伤?", all injury-related sub-questions are automatically skipped.

---

## Database Tables Created

```
Configuration Tables
├── agent_document_types          # Document templates
├── agent_variable_mappings       # Data extraction rules
├── agent_compensation_rules      # Compensation calculation
├── agent_legal_rights            # Legal rights definitions
├── agent_risk_factors            # Risk detection rules
└── agent_case_type_configs       # Per-case-type workflow

Checklist & Navigator Tables
├── agent_checklist_tree          # Question hierarchy
├── session_checklist_progress    # Per-point progress
├── agent_router_rules            # Triage routing
└── agent_workflow_transitions    # State machine
```

---

## Using V1 vs V2 Agents

```python
# In services/agents/__init__.py
USE_V2_AGENTS = True  # Set to True to use headless architecture

# Automatic routing based on flag
agent = await get_agent_for_type("professional", agent_id, db)

# Force V2
agent = await get_agent_for_type("professional", agent_id, db, use_v2=True)

# Force V1 (legacy)
agent = await get_agent_for_type("professional", agent_id, db, use_v2=False)
```

---

## Admin UI Pages

| Route | Description |
|-------|-------------|
| `/admin/tree-editor` | Visual tree editor for questions |
| `/admin/config/document-types` | Document template management |
| `/admin/config/variable-mappings` | Variable extraction rules |
| `/admin/config/compensation-rules` | Compensation formulas |
| `/admin/config/legal-rights` | Legal rights definitions |
| `/admin/config/risk-factors` | Risk detection rules |
| `/admin/config/case-types` | Case type workflow config |

---

## Setup Instructions

```bash
# 1. Run migrations
psql -U user -d database -f migrations/009_configurable_agent_settings.sql
psql -U user -d database -f migrations/010_checklist_tree_navigator.sql

# 2. Seed configuration data
python scripts/seed_agent_configs.py

# 3. Seed checklist tree
python scripts/seed_checklist_tree.py

# 4. Enable V2 agents (already True by default)
# In services/agents/__init__.py: USE_V2_AGENTS = True

# 5. Start server
uvicorn main:app --reload
```

---

## What Admins Can Now Do (Without Code Changes)

1. ✅ Add new case types (e.g., "医疗纠纷")
2. ✅ Configure agent workflow order per case type
3. ✅ Add/edit/reorder questions in the checklist tree
4. ✅ Set gatekeeper logic (skip questions based on answers)
5. ✅ Update variable extraction rules
6. ✅ Modify compensation calculation formulas
7. ✅ Add legal rights with trigger conditions
8. ✅ Configure risk detection rules
9. ✅ Set statute of limitations
10. ✅ Customize prompts and messages
11. ✅ Enable/disable configurations without deletion

---

## Key Files for Understanding the System

1. **`services/navigator_service.py`** - The core algorithm
2. **`services/agents/professional_agent_v2.py`** - How agents use Navigator
3. **`models/checklist_tree.py`** - Data models
4. **`frontend/src/views/admin/TreeEditor.vue`** - Admin UI

---

## Backwards Compatibility

- V1 agents (`TriageAgent`, `ProfessionalAgent`, etc.) still work
- Set `USE_V2_AGENTS = False` to use legacy hardcoded agents
- Both can coexist during migration
