# Phase 2 Implementation Prompt: Dynamic Configuration

## Context

I have completed Phase 1 (Critical Security Fixes) of my mentor's audit recommendations. The changes included:
- Moving SECRET_KEY and DATABASE_URL to .env file with validation
- Creating a SafeScriptExecutor sandbox to replace raw exec()/eval()
- Adding script validation endpoint

Now I need to implement Phase 2: Dynamic Configuration.

## Mentor's Original Comments for Phase 2

### 2A. Hard-coded vs. Dynamic Storage Audit

**Missing Dynamic Feature:** The `AgentRole` and `WorkflowStage` in `agent_orchestrator.py` are hardcoded Enums.

**Improvement:** If you want a truly dynamic "Agent Studio," the stages (Intake, Analysis, etc.) should be stored in a `workflow_stages` table, allowing admins to define new phases without a code deployment.

### 2B. UI Hardcoding

**Audit:** In `AgentManagement.vue`, the "Phases" (Triage, Professional, etc.) are hardcoded in the phases array.

**Problem:** If an admin adds a new `AgentType` in the database, it will not appear in the UI pipeline overview.

**Recommendation:** Fetch the available `AgentType` values from the backend `/api/agent-management/agent-types` endpoint rather than hardcoding them in Vue.

### 3A. The "Fetch Agent" Gap

**Usability Issue:** It is unclear if "Fetch Agent" is a specific subtype or just a UI representation.

**Resolution:** Ensure the `AgentType` Enum in `models/agent.py` is updated to include FETCH if it requires unique logic.

## Tasks for Phase 2

1. **Create `workflow_stages` database table** (`models/workflow_stage.py`):
   - id (UUID)
   - name (unique identifier like "intake", "analysis")
   - display_name (Chinese display name)
   - description
   - icon (emoji or icon class)
   - sort_order
   - is_active (boolean)
   - created_at, updated_at

2. **Create migration SQL** for the new table

3. **Create API endpoints** (`routers/workflow_stages.py`):
   - GET `/api/workflow-stages` - List all active stages
   - POST `/api/workflow-stages` - Create new stage (admin only)
   - PUT `/api/workflow-stages/{id}` - Update stage (admin only)
   - DELETE `/api/workflow-stages/{id}` - Soft delete stage (admin only)

4. **Update `AgentType` enum** in `models/agent.py`:
   - Add FETCH type if needed for the "Fetch Agent" functionality
   - OR clarify that Fetch Agent uses existing type with specific configuration

5. **Update `agent_orchestrator.py`**:
   - Replace hardcoded `WorkflowStage` enum with database lookup
   - Make the orchestrator work with dynamically defined stages

6. **Update `/api/agent-management/agent-types`** endpoint:
   - Return types from database instead of hardcoded list
   - Include phase/stage information

7. **Update `AgentManagement.vue`**:
   - Replace hardcoded `phases` array with API call to `/api/workflow-stages`
   - Fetch agent types from API
   - Add loading state while fetching

8. **Seed default workflow stages** in a migration/seed script

## Current File Locations

- `models/agent.py` - AgentType enum
- `services/agent_orchestrator.py` - WorkflowStage enum
- `routers/agent_management.py` - agent-types endpoint
- `frontend/src/views/admin/AgentManagement.vue` - hardcoded phases

## Expected Deliverables

1. New files:
   - `models/workflow_stage.py`
   - `routers/workflow_stages.py`
   - `migrations/ADD_WORKFLOW_STAGES.sql`
   - `scripts/seed_workflow_stages.py`

2. Modified files:
   - `models/agent.py` (if adding FETCH type)
   - `services/agent_orchestrator.py`
   - `routers/agent_management.py`
   - `frontend/src/views/admin/AgentManagement.vue`
   - `main.py` (register new router)

Please implement Phase 2 following the same pattern as Phase 1, creating a summary document and providing a prompt for Phase 3 when done.
