# Phase 2 Implementation Summary: Dynamic Configuration

## ✅ Completed Tasks

### 1. Workflow Stages Database Table

**Created:** `models/workflow_stage.py`

New database models for dynamic workflow configuration:
- `WorkflowStage` - Defines pipeline phases (分诊, 专业, 搜索, etc.)
- `AgentType` - Defines agent types (triage, domain, fetch, etc.)

**Key Features:**
- `sort_order` for ordering stages in pipeline
- `agent_type_filter` links stages to agent types
- `allowed_transitions` defines valid next stages
- `is_system` prevents deletion of core stages
- `is_active` for soft delete

---

### 2. Migration SQL

**Created:** `migrations/ADD_WORKFLOW_STAGES.sql`

- Creates `workflow_stages` table
- Creates `agent_types` table  
- Seeds default stages and types
- Adds optional FK from `agents` to `workflow_stages`
- Creates `updated_at` triggers

**To run migration:**
```bash
psql -d your_database -f migrations/ADD_WORKFLOW_STAGES.sql
```

---

### 3. API Endpoints

**Created:** `routers/workflow_stages.py`

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/workflow-stages` | GET | List all stages |
| `/api/workflow-stages/pipeline` | GET | Simplified data for UI |
| `/api/workflow-stages/{id}` | GET | Get stage by ID |
| `/api/workflow-stages/by-name/{name}` | GET | Get stage by name |
| `/api/workflow-stages` | POST | Create stage (admin) |
| `/api/workflow-stages/{id}` | PUT | Update stage (admin) |
| `/api/workflow-stages/{id}` | DELETE | Soft delete (admin) |
| `/api/workflow-stages/{id}/reorder` | POST | Reorder stage |
| `/api/workflow-stages/agent-types` | GET | List agent types |
| `/api/workflow-stages/agent-types/{id}` | GET/POST/PUT/DELETE | CRUD for types |
| `/api/workflow-stages/seed-defaults` | POST | Reset to defaults |

**Updated:** `routers/agent_management.py`

Added two new endpoints with database lookup:
- `GET /api/agent-management/agent-types` - Now fetches from DB
- `GET /api/agent-management/workflow-phases` - New endpoint for pipeline UI

Both endpoints have fallback to hardcoded defaults if database tables don't exist yet.

---

### 4. Agent Type Updates

**Modified:** `models/agent.py`

Added new agent types to enum:
```python
class AgentType(str, enum.Enum):
    TRIAGE = "triage"
    DOMAIN = "domain"
    FETCH = "fetch"          # NEW - 获取Agent
    SEARCH = "search"
    ANALYZER = "analyzer"
    GENERATION = "generation" # NEW - 生成Agent
    CUSTOM = "custom"
```

**Note:** The enum is maintained for backward compatibility. New types should be added to `agent_types` database table.

---

### 5. Dynamic Stage Manager

**Modified:** `services/agent_orchestrator.py`

Added `WorkflowStageManager` class:
```python
manager = WorkflowStageManager(db)
stages = manager.get_stages()
next_stages = manager.get_next_stages("triage")
stage = manager.get_stage_by_name("analysis")
```

The old `WorkflowStage` enum is marked as deprecated but kept for compatibility.

---

### 6. Frontend Updates

**Modified:** `frontend/src/views/admin/AgentManagement.vue`

- `phases` is now a `ref()` instead of static array
- Added `loadPhases()` function to fetch from API
- Added `loadAgentTypes()` function
- Added `isLoading` state for loading indicator
- `onMounted` now loads phases and types first

```javascript
// Before: Static
const phases = [
  { key: 'triage', name: '分诊', icon: '🎯' },
  ...
]

// After: Dynamic
const phases = ref([...])  // Defaults while loading

const loadPhases = async () => {
  const response = await apiClient.get('/agent-management/workflow-phases')
  if (response.data?.length > 0) {
    phases.value = response.data
  }
}
```

---

### 7. Router Registration

**Modified:** `main.py`

Added new router:
```python
from routers.workflow_stages import router as workflow_stages_router
app.include_router(workflow_stages_router)  # /api/workflow-stages/*
```

---

### 8. Seed Script

**Created:** `scripts/seed_workflow_stages.py`

```bash
# Run to initialize default stages and types
python scripts/seed_workflow_stages.py
```

Output shows current configuration:
```
Current workflow stages:
  ✓ 1. 🎯 分诊 (triage)
  ✓ 2. 👨‍💼 专业 (professional)
  ✓ 3. 🔍 搜索 (search)
  ...
```

---

## 📁 Files Changed Summary

| File | Change Type | Description |
|------|-------------|-------------|
| `models/workflow_stage.py` | NEW | Database models for stages/types |
| `migrations/ADD_WORKFLOW_STAGES.sql` | NEW | Migration SQL |
| `routers/workflow_stages.py` | NEW | API endpoints |
| `scripts/seed_workflow_stages.py` | NEW | Seed script |
| `models/agent.py` | MODIFIED | Added FETCH, GENERATION types |
| `services/agent_orchestrator.py` | MODIFIED | Added WorkflowStageManager |
| `routers/agent_management.py` | MODIFIED | Dynamic agent-types endpoint |
| `frontend/.../AgentManagement.vue` | MODIFIED | Fetch phases from API |
| `main.py` | MODIFIED | Register new router |

---

## 🧪 Testing Checklist

Before proceeding to Phase 3, verify:

- [ ] Run migration SQL successfully
- [ ] Run seed script: `python scripts/seed_workflow_stages.py`
- [ ] API returns stages: `GET /api/workflow-stages`
- [ ] API returns types: `GET /api/workflow-stages/agent-types`
- [ ] Admin can create new stage via API
- [ ] Frontend loads phases dynamically
- [ ] Adding a stage in DB appears in UI (after refresh)
- [ ] FETCH agent type works in agent creation

---

## 🔄 API Usage Examples

**Get pipeline stages for UI:**
```bash
curl http://localhost:8000/api/workflow-stages/pipeline
# Returns: [{"key": "triage", "name": "分诊", "icon": "🎯", ...}, ...]
```

**Create a new stage:**
```bash
curl -X POST http://localhost:8000/api/workflow-stages \
  -H "Content-Type: application/json" \
  -d '{
    "name": "validation",
    "display_name": "验证",
    "icon": "✓",
    "sort_order": 7,
    "agent_type_filter": "validation"
  }'
```

**Get agent types:**
```bash
curl http://localhost:8000/api/agent-management/agent-types
# Returns agent types with stage associations
```

---

## ⚠️ Breaking Changes

None - all changes are backward compatible:
- Enum types still work
- Fallback to hardcoded values if DB tables don't exist
- Frontend gracefully handles missing API

---

## 📌 Next Phase Preview

**Phase 3: Enhanced Prompt Protection** will address:
- Integrating LLM-Guard or similar library
- Strengthening `sanitize_for_prompt` function  
- Adding semantic similarity detection for jailbreak attempts
- Output validation/filtering
