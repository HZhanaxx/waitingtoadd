# Phase 3 Implementation Prompt: Enhanced Prompt Protection & UI Improvements

## Context

I have completed Phase 1 (Critical Security Fixes) and Phase 2 (Dynamic Configuration) of my mentor's audit recommendations:

**Phase 1 completed:**
- Moved SECRET_KEY and DATABASE_URL to .env file with validation
- Created SafeScriptExecutor sandbox to replace raw exec()/eval()
- Added script validation endpoint

**Phase 2 completed:**
- Created workflow_stages and agent_types database tables
- Created API endpoints for dynamic stage/type management
- Updated AgentType enum to include FETCH and GENERATION
- Added WorkflowStageManager for dynamic stage lookup
- Updated frontend to fetch phases from API
- Created seed script for default data

Now I need to implement Phase 3: Enhanced Prompt Protection & UI Improvements.

## Mentor's Original Comments for Phase 3

### 1C. Prompt Injection Protection

**Audit:** The `sanitize_for_prompt` function in `base_agent.py` is a good manual implementation, filtering out role markers like `[INST]` and `system:`.

**Weakness:** Modern LLMs can often bypass simple regex filters.

**Recommendation:** Consider using a dedicated library like LLM-Guard or Prowler for more robust input/output validation.

### 4C. Fetch Agent Configuration

**Missing Logic:** There is no "Test" button in the UI for prompts.

**Recommendation:** Use the `test-script` endpoint to add a "Validate Prompt" feature in the Admin UI so admins can test their templates before deploying them to users.

### 4B. Security Rules Management

**Problem:** The `saveSecurityRule` method in the frontend sends keywords as a split list. Ensure the backend `SafetyRule` model uses a JSONB column to handle this list correctly.

## Tasks for Phase 3

### Part A: Enhanced Prompt Protection

1. **Evaluate LLM-Guard integration feasibility:**
   - Check if LLM-Guard is available and suitable
   - If not available, enhance the existing `sanitize_for_prompt` function

2. **Enhance `sanitize_for_prompt` in `services/agents/base_agent.py`:**
   - Add more injection patterns (Unicode tricks, encoding bypass)
   - Add semantic similarity detection using embeddings (optional)
   - Add output validation for agent responses
   - Add configurable strictness levels

3. **Create `utils/prompt_guard.py`:**
   - Centralize all prompt safety logic
   - Input sanitization
   - Output validation
   - Logging of detected attacks
   - Integration with SafetyRule model

4. **Add safety rule evaluation before agent processing:**
   - Load active SafetyRules from database
   - Evaluate rules against user input
   - Apply configured actions (block, warn, modify)

### Part B: UI Improvements

5. **Add "Test Prompt" button to Admin UI:**
   - In AgentManagement.vue, add test button for prompts
   - Call `/api/agent-management/test-script` endpoint
   - Show results in a modal (success/error, output)

6. **Verify SafetyRule JSONB handling:**
   - Check `match_keywords` field handling in backend
   - Ensure frontend properly formats keyword lists
   - Test round-trip of security rules

7. **Add prompt testing modal component:**
   - Create reusable PromptTestModal.vue
   - Support testing system prompts
   - Support testing with sample user inputs

### Part C: Safety Logging

8. **Implement safety event logging:**
   - Log detected prompt injection attempts
   - Log rule matches and actions taken
   - Create admin view for safety logs

## Current File Locations

- `services/agents/base_agent.py` - `sanitize_for_prompt` function (lines 46-110)
- `models/safety_rule.py` - SafetyRule model with JSONB fields
- `routers/agent_management.py` - test-script endpoint
- `frontend/src/views/admin/AgentManagement.vue` - Admin UI

## Expected Deliverables

### New Files:
- `utils/prompt_guard.py` - Centralized prompt safety module
- `frontend/src/components/admin/PromptTestModal.vue` - Prompt testing modal (if needed)

### Modified Files:
- `services/agents/base_agent.py` - Enhanced sanitization
- `routers/agent_management.py` - Safety rule evaluation endpoint
- `frontend/src/views/admin/AgentManagement.vue` - Test button UI

## Technical Requirements

1. **Prompt Guard should detect:**
   - Role injection (`system:`, `[INST]`, etc.)
   - Instruction override attempts
   - Unicode/encoding bypasses
   - Jailbreak patterns (DAN mode, etc.)
   - Markdown/HTML injection in outputs

2. **Test Prompt UI should:**
   - Allow pasting a system prompt
   - Allow entering test user input
   - Show sanitized version
   - Show any detected issues
   - Show simulated response (optional)

3. **Safety logging should:**
   - Record input preview (truncated)
   - Record matched pattern/rule
   - Record action taken
   - Record timestamp and user/session info

## References

Current sanitize_for_prompt patterns:
```python
injection_patterns = [
    r'(?i)\b(system|assistant|human|user)\s*[:：]',
    r'系统[:：]|助手[:：]|用户[:：]',
    r'(?i)ignore\s+(all\s+)?(previous|above|prior)\s+(instructions?|prompts?|rules?)',
    r'\[INST\].*?\[/INST\]',
    r'<<\s*SYS\s*>>.*?<<\s*/SYS\s*>>',
    # ... more patterns
]
```

Please implement Phase 3 following the same pattern as Phase 1 and 2, creating a summary document and providing a prompt for Phase 4 when done.
