# DOCX Template Conversion Guide
## Converting Word Templates for AI Generation

This guide explains how to convert a standard Word document template into a format that can be filled automatically by the Generation Agent.

---

## Overview

The system uses **docxtpl** (a Python library) which allows **Jinja2 syntax** inside Word documents.

### Before (Original Template)
```
姓名：__________
性别：男£ 女£
出生日期：____年____月____日
```

### After (Jinja2 Template)
```
姓名：{{ plaintiff_name }}
性别：男{{ gender_male }} 女{{ gender_female }}
出生日期：{{ birth_year }}年{{ birth_month }}月{{ birth_day }}日
```

---

## Step 1: Prepare Your Template

### 1.1 Open the Original DOCX
Open your template in Microsoft Word (or LibreOffice Writer).

### 1.2 Identify Fields to Replace

| Field Type | Original | Jinja2 Replacement |
|------------|----------|-------------------|
| Text blanks | `__________` | `{{ variable_name }}` |
| Checkboxes | `男£ 女£` | `男{{ gender_male }} 女{{ gender_female }}` |
| Dates | `____年____月` | `{{ year }}年{{ month }}月` |
| Money | `元` | `{{ amount }}元` |

---

## Step 2: Convert Checkboxes

This is the **critical part** for legal documents.

### Original Checkbox (Wingdings £)
```
是否有医疗费：有£  无£
```

### Converted Checkbox
```
是否有医疗费：有{{ has_medical_fee }}  无{{ no_medical_fee }}
```

### How It Works in Python
```python
# The system will replace these with:
context = {
    "has_medical_fee": "☑" if medical_fee > 0 else "□",
    "no_medical_fee": "□" if medical_fee > 0 else "☑"
}
```

### Checkbox Characters
- **Checked**: ☑ (U+2611) or ☐ with checkmark
- **Unchecked**: □ (U+25A1)

---

## Step 3: Variable Naming Convention

Use **snake_case** for all variables:

```
✅ Good: {{ plaintiff_name }}
✅ Good: {{ medical_fee }}
✅ Good: {{ accident_date }}

❌ Bad: {{ PlaintiffName }}
❌ Bad: {{ Medical Fee }}
❌ Bad: {{ 医疗费 }}
```

### Standard Variable Names for Traffic Accident Cases

| Category | Variable Name | Description |
|----------|--------------|-------------|
| **原告信息** | | |
| | plaintiff_name | 原告姓名 |
| | plaintiff_gender | 性别 (male/female) |
| | plaintiff_id_number | 身份证号 |
| | plaintiff_phone | 联系电话 |
| | plaintiff_address | 住址 |
| | birth_year, birth_month, birth_day | 出生日期 |
| **被告信息** | | |
| | defendant_name | 被告姓名 |
| | defendant_address | 被告地址 |
| | insurance_company | 保险公司 |
| **事故信息** | | |
| | accident_date | 事故日期 |
| | accident_location | 事故地点 |
| | accident_description | 事故经过 |
| | responsibility_ratio | 责任比例 |
| **赔偿项目** | | |
| | medical_fee | 医疗费 |
| | nursing_fee | 护理费 |
| | lost_wages | 误工费 |
| | nutrition_fee | 营养费 |
| | hospital_food_fee | 住院伙食补助费 |
| | transportation_fee | 交通费 |
| | disability_compensation | 残疾赔偿金 |
| | death_compensation | 死亡赔偿金 |
| | mental_damage_fee | 精神损害赔偿金 |
| | total_claim | 索赔总额 |
| **复选框** | | |
| | gender_male | 男性勾选 (☑/□) |
| | gender_female | 女性勾选 (☑/□) |
| | has_medical_records | 有病历 (☑/□) |
| | has_traffic_certificate | 有事故认定书 (☑/□) |
| | accept_mediation | 接受调解 (☑/□) |

---

## Step 4: Example Conversion

### Original Row (Traffic Accident Template)
```
原告（自然人）  |  姓名：
                   性别：男£ 女£
                   出生日期：    年    月    日
                   民族：
                   身份证号码：
                   住址：
                   联系电话：
```

### Converted Row
```
原告（自然人）  |  姓名：{{ plaintiff_name }}
                   性别：男{{ gender_male }} 女{{ gender_female }}
                   出生日期：{{ birth_year }}年{{ birth_month }}月{{ birth_day }}日
                   民族：{{ ethnicity }}
                   身份证号码：{{ plaintiff_id_number }}
                   住址：{{ plaintiff_address }}
                   联系电话：{{ plaintiff_phone }}
```

---

## Step 5: Upload to System

### Option A: Using Admin UI
1. Go to Admin Dashboard → Templates
2. Click "Upload Template"
3. Select your converted .docx file
4. Fill in:
   - Name: "机动车交通事故责任纠纷民事起诉状"
   - Case Type: traffic_accident
   - Category: legal
5. Click Upload

### Option B: Using Script
```bash
python scripts/import_docx_template.py \
    "path/to/template.docx" \
    "机动车交通事故责任纠纷民事起诉状" \
    --case-type traffic_accident
```

---

## Step 6: Configure Variable Mappings

After upload, configure how template variables map to collected data:

### In Admin UI → Template Detail → Edit Mappings

```json
{
  "variable_mappings": {
    "plaintiff_name": "plaintiff_name",
    "plaintiff_address": "plaintiff_address",
    "medical_fee": "medical_fee",
    "accident_date": "accident_date"
  },
  "checkbox_mappings": {
    "gender_male": {
      "condition": "plaintiff_gender",
      "equals": "male"
    },
    "gender_female": {
      "condition": "plaintiff_gender", 
      "equals": "female"
    },
    "has_medical_records": {
      "condition": "has_medical_records"
    }
  }
}
```

---

## Step 7: Test Generation

1. Go to a test case in the system
2. Navigate to Generation phase
3. Select your template
4. Verify the output document

---

## Troubleshooting

### Issue: Checkbox not showing correctly
**Solution**: Make sure you're using Unicode checkbox characters:
- Copy this: ☑ (checked)
- Copy this: □ (unchecked)

### Issue: Variable not being replaced
**Solution**: Check that:
1. Variable name in template matches exactly (case-sensitive)
2. Variable is mapped in `variable_mappings`
3. Data exists in `collected_data`

### Issue: Chinese characters garbled
**Solution**: Ensure the template is saved as UTF-8 encoding in Word.

---

## Complete Example Template

See: `/templates/traffic_accident_complaint_template.docx`

This is a fully converted template ready for use.
