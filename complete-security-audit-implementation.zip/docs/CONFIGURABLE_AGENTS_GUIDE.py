"""
Example: How to Modify Agents to Use Database Configurations
=============================================================

This shows how to update existing agents to load configurations
from the database instead of using hardcoded values.

BEFORE (hardcoded):
    COMPENSATION_RULES = {
        "medical_expenses": {...},
        "lost_income": {...}
    }
    
    async def calculate_compensation(self, data):
        for rule in COMPENSATION_RULES:
            # hardcoded logic

AFTER (database-driven):
    async def calculate_compensation(self, data, case_type):
        config = AgentConfigService(self.db)
        result = await config.calculate_compensation(case_type, data)
"""

# ============================================
# EXAMPLE 1: Analysis Agent Update
# ============================================

class AnalysisAgentUpdated:
    """
    Updated AnalysisAgent that loads configs from database.
    """
    
    # Keep hardcoded values as FALLBACK only
    DEFAULT_COMPENSATION_RULES = {
        "medical_expenses": {
            "name": "医疗费",
            "calculation_type": "fixed",
            "legal_basis": "《民法典》第1179条"
        }
    }
    
    DEFAULT_LEGAL_RIGHTS = {
        "right_to_compensation": {
            "name": "损害赔偿请求权",
            "legal_basis": "《民法典》第1165条"
        }
    }
    
    def __init__(self, db, agent_id):
        self.db = db
        self.agent_id = agent_id
        # Create config service
        from services.agent_config_service import AgentConfigService
        self.config_service = AgentConfigService(db)
    
    async def analyze_case(self, session, case_type: str) -> dict:
        """
        Analyze case using database-driven rules.
        """
        collected_data = session.collected_data or {}
        
        # 1. Calculate compensation using database rules
        compensation = await self.config_service.calculate_compensation(
            case_type=case_type,
            data=collected_data
        )
        
        # 2. Get applicable legal rights
        legal_rights = await self.config_service.get_legal_rights(
            case_type=case_type,
            data=collected_data,
            default_rights=self.DEFAULT_LEGAL_RIGHTS  # Fallback
        )
        
        # 3. Detect risks
        risks = await self.config_service.detect_risks(
            case_type=case_type,
            data=collected_data
        )
        
        return {
            "compensation": compensation,
            "legal_rights": legal_rights,
            "risks": risks,
            "case_strength": self._calculate_case_strength(legal_rights, risks)
        }
    
    def _calculate_case_strength(self, rights, risks):
        """Calculate overall case strength."""
        base_score = 70
        
        # Add points for rights
        base_score += len(rights) * 5
        
        # Subtract points for risks
        for risk in risks:
            if risk.get("severity") == "critical":
                base_score -= 20
            elif risk.get("severity") == "high":
                base_score -= 10
            else:
                base_score -= 5
        
        return max(0, min(100, base_score)) / 100


# ============================================
# EXAMPLE 2: Generation Agent Update
# ============================================

class GenerationAgentUpdated:
    """
    Updated GenerationAgent that loads document types from database.
    """
    
    # Keep as fallback
    DEFAULT_DOCUMENT_TYPES = {
        "complaint": {
            "name": "起诉状",
            "required_variables": ["plaintiff_name", "defendant_name"]
        }
    }
    
    DEFAULT_VARIABLE_MAPPING = {
        "plaintiff_name": ["用户姓名", "原告姓名", "委托人姓名"]
    }
    
    def __init__(self, db, agent_id):
        self.db = db
        self.agent_id = agent_id
        from services.agent_config_service import AgentConfigService
        self.config_service = AgentConfigService(db)
    
    async def get_available_documents(self, case_type: str) -> list:
        """
        Get available document types for a case.
        Loads from database with fallback to defaults.
        """
        doc_types = await self.config_service.get_document_types(
            case_type=case_type,
            default_types=self.DEFAULT_DOCUMENT_TYPES
        )
        
        return [
            {"code": code, **config}
            for code, config in doc_types.items()
        ]
    
    async def extract_template_variables(
        self,
        collected_data: dict,
        document_type: str
    ) -> dict:
        """
        Extract variables using database mappings.
        """
        # Get document config
        doc_config = await self.config_service.get_document_type(document_type)
        
        if not doc_config:
            return {}
        
        # Get required variables
        required = doc_config.get("required_variables", [])
        optional = doc_config.get("optional_variables", [])
        all_vars = required + optional
        
        # Extract using mappings
        return await self.config_service.extract_variables(
            collected_data=collected_data,
            target_variables=all_vars,
            agent_type="generation"
        )


# ============================================
# EXAMPLE 3: Using Prompts from Database
# ============================================

class AgentWithDatabasePrompts:
    """
    Example of loading prompts from database.
    """
    
    # Fallback prompts
    DEFAULT_PROMPTS = {
        "system_prompt": "你是一个法律助手。",
        "greeting": "您好，我是法律助手，请问有什么可以帮您？"
    }
    
    def __init__(self, db, agent_id, agent_type):
        self.db = db
        self.agent_id = agent_id
        self.agent_type = agent_type
        from services.agent_config_service import AgentConfigService
        self.config_service = AgentConfigService(db)
        
        # Prompts will be loaded lazily
        self._prompts = None
    
    async def _ensure_prompts_loaded(self):
        """Load prompts from database if not loaded."""
        if self._prompts is None:
            self._prompts = await self.config_service.get_prompts(
                agent_id=self.agent_id,
                agent_type=self.agent_type,
                default_prompts=self.DEFAULT_PROMPTS
            )
    
    async def get_prompt(self, key: str, variables: dict = None) -> str:
        """
        Get a prompt by key, optionally with variable substitution.
        """
        await self._ensure_prompts_loaded()
        
        prompt = self._prompts.get(key, "")
        
        if variables:
            for var_name, var_value in variables.items():
                prompt = prompt.replace(f"{{{var_name}}}", str(var_value))
        
        return prompt
    
    async def get_initial_message(self, session):
        """
        Generate initial message using database prompt.
        """
        greeting = await self.get_prompt(
            "greeting",
            variables={
                "user_name": session.collected_data.get("user_name", "用户")
            }
        )
        return {"message": greeting}


# ============================================
# MIGRATION STEPS
# ============================================
"""
To migrate existing agents to database-driven configuration:

1. Run the database migration:
   psql -U user -d database -f migrations/009_configurable_agent_settings.sql

2. Seed initial data:
   python scripts/seed_agent_configs.py

3. Update each agent class:
   a. Add AgentConfigService import
   b. Keep DEFAULT_* as fallback constants
   c. Replace direct dict access with config_service calls
   d. Test with database configs
   
4. Create admin API endpoints for CRUD operations (optional)

5. Create admin UI for managing configurations (optional)


BENEFITS:
- Non-developers can modify prompts, rules, mappings
- Changes don't require code deployment
- A/B testing different configurations
- Audit trail of changes
- Per-case-type customization
- Easy to add new case types without code changes
"""


# ============================================
# ADMIN API EXAMPLE
# ============================================
"""
# routers/agent_config_api.py

@router.get("/document-types")
async def list_document_types(
    case_type: str = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    query = db.query(AgentDocumentType).filter(AgentDocumentType.is_active == True)
    if case_type:
        query = query.filter(AgentDocumentType.applicable_case_types.contains([case_type]))
    return [dt.to_dict() for dt in query.all()]

@router.post("/document-types")
async def create_document_type(
    data: DocumentTypeCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    dt = AgentDocumentType(**data.dict())
    db.add(dt)
    db.commit()
    return dt.to_dict()

@router.put("/document-types/{code}")
async def update_document_type(
    code: str,
    data: DocumentTypeUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    dt = db.query(AgentDocumentType).filter(AgentDocumentType.code == code).first()
    if not dt:
        raise HTTPException(404)
    for key, value in data.dict(exclude_unset=True).items():
        setattr(dt, key, value)
    db.commit()
    return dt.to_dict()

# Similar endpoints for:
# - /variable-mappings
# - /compensation-rules  
# - /legal-rights
# - /risk-factors
# - /case-type-configs
"""
