# 🚀 AI Law Agent - Complete Legal Data System Integration Guide

## Overview

This guide integrates the **Legal Data System** (vector search, client-aware ranking, case/law loading) into your existing AI Law Agent platform.

---

## 📋 What's Being Added

### New Features

| Feature | Description |
|---------|-------------|
| **Vector Semantic Search** | Find similar cases using AI embeddings (pgvector) |
| **Client-Aware Ranking** | Rank cases favorably for YOUR client (原告 or 被告) |
| **Excel Case Loading** | Import massive case datasets from Excel files |
| **JSON Law Loading** | Import civil_code.json and PKU Law format |
| **Reference Score** | Calculate case outcome score from Column P |
| **Lawyer Extraction** | Extract lawyers/firms from judgment text |
| **Hybrid Search** | Combine keyword + vector + law similarity |
| **LLM Reranking** | Optional AI-powered result reranking |

### New Files

```
services/
├── legal_case_search.py       # NEW - Hybrid search service
└── legal_data_loader.py       # NEW - Data loading service

services/agents/
└── search_agent.py            # MODIFIED - Client-aware search

routers/
├── case_records.py            # NEW - Case search API
└── data_loader.py             # NEW - Admin data loading API

migrations/
└── FINAL_CONSOLIDATED_MIGRATION.sql  # NEW - Complete DB schema
```

---

## 🔧 Step-by-Step Integration

### Phase 1: Database Setup (45 minutes)

#### Step 1.1: Install pgvector Extension

pgvector must be installed at the PostgreSQL level first:

```bash
# Ubuntu/Debian
sudo apt update
sudo apt install postgresql-14-pgvector

# macOS with Homebrew
brew install pgvector

# Or compile from source
git clone https://github.com/pgvector/pgvector.git
cd pgvector
make
sudo make install
```

#### Step 1.2: Enable Extension in Database

```bash
# Connect as superuser
sudo -u postgres psql -d your_database

# Enable extensions
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

# Verify
SELECT * FROM pg_extension WHERE extname = 'vector';
```

#### Step 1.3: Run Migration

**Option A: Fresh Database (Recommended for new setup)**
```bash
psql -U your_user -d your_database -f migrations/FINAL_CONSOLIDATED_MIGRATION.sql
```

**Option B: Existing Database (Add new features only)**
```bash
# Run only the enhancement migration
psql -U your_user -d your_database -f migrations/014_legal_data_system_enhancement.sql
```

#### Step 1.4: Verify Migration

```sql
-- Check tables
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' AND table_name IN ('legal_cases', 'law_articles');

-- Check new columns
SELECT column_name FROM information_schema.columns 
WHERE table_name = 'legal_cases' AND column_name IN ('embedding', 'support_status', 'client_role');

-- Check pgvector works
SELECT '[1,2,3]'::vector;

-- Check helper functions
SELECT calculate_reference_score('支持原告全部诉讼请求');  -- Should return 1.0
SELECT calculate_reference_score('驳回原告全部诉讼请求');  -- Should return -1.0
```

---

### Phase 2: Copy Service Files (10 minutes)

#### Step 2.1: Copy New Services

```bash
# Copy to services directory
cp legal_case_search.py your_project/services/
cp legal_data_loader.py your_project/services/
```

#### Step 2.2: Replace Search Agent

**IMPORTANT**: This replaces your existing search_agent.py with an enhanced version:

```bash
# Backup existing
cp your_project/services/agents/search_agent.py your_project/services/agents/search_agent.py.backup

# Replace with new version
cp search_agent.py your_project/services/agents/
```

#### Step 2.3: Copy New Routers

```bash
cp case_records.py your_project/routers/
cp data_loader.py your_project/routers/
```

---

### Phase 3: Update main.py (5 minutes)

#### Step 3.1: Add Imports

Find this section (around line 47):
```python
from routers.v2_chat import router as v2_chat_router
```

Add after it:
```python
# === NEW: Legal Data System Routers (Vector Search + Client-Aware Ranking) ===
from routers.case_records import router as case_records_router
from routers.data_loader import router as data_loader_router
```

#### Step 3.2: Register Routers

Find this section (around line 327):
```python
app.include_router(v2_chat_router)              # /api/v2/chat/*
```

Add after it:
```python
# === NEW: Legal Data System Routes (Vector Search + Client-Aware Ranking) ===
app.include_router(case_records_router)         # /api/case-records/*
app.include_router(data_loader_router)          # /api/admin/data-loader/*
```

**OR simply replace main.py with the provided updated version.**

---

### Phase 4: Install Dependencies (5 minutes)

```bash
# Add to requirements.txt
echo "pgvector>=0.2.0" >> requirements.txt
echo "pandas>=2.0.0" >> requirements.txt
echo "openpyxl>=3.1.0" >> requirements.txt

# Install
pip install pgvector pandas openpyxl
```

---

### Phase 5: Configure Embedding Model (10 minutes)

#### Step 5.1: Pull Embedding Model in Ollama

```bash
# Option 1: Fast, good quality
ollama pull nomic-embed-text

# Option 2: Best quality (slower)
ollama pull bge-m3

# Option 3: Multilingual (good for Chinese)
ollama pull mxbai-embed-large
```

#### Step 5.2: Update .env

```bash
# Add to .env
EMBEDDING_MODEL=nomic-embed-text
EMBEDDING_DIM=768

# Or for bge-m3
# EMBEDDING_MODEL=bge-m3
# EMBEDDING_DIM=1024
```

---

### Phase 6: Test the Integration (15 minutes)

#### Step 6.1: Start Server

```bash
uvicorn main:app --reload --port 8000
```

#### Step 6.2: Check API Documentation

Open: http://localhost:8000/docs

You should see new endpoints:
- `/api/case-records/*`
- `/api/admin/data-loader/*`

#### Step 6.3: Test Search API

```bash
# Get auth token first
TOKEN=$(curl -s -X POST "http://localhost:8000/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"username": "demo_user", "password": "Demo123456"}' | jq -r '.access_token')

# Test search as plaintiff (原告)
curl "http://localhost:8000/api/case-records/search?q=交通事故&client_role=原告" \
  -H "Authorization: Bearer $TOKEN"

# Test search as defendant (被告)
curl "http://localhost:8000/api/case-records/search?q=交通事故&client_role=被告" \
  -H "Authorization: Bearer $TOKEN"
```

#### Step 6.4: Check Stats

```bash
curl "http://localhost:8000/api/admin/data-loader/stats" \
  -H "Authorization: Bearer $TOKEN"
```

---

### Phase 7: Load Your Data (Time varies)

#### Step 7.1: Prepare Your Excel File

Your Excel file should have these columns:

| Column | Content | Required |
|--------|---------|----------|
| A | 案件名称 (Case Name) | ✅ |
| B | 案号 (Case Number) | ✅ |
| C | 法院 (Court) | ✅ |
| **D** | **文书类型 (Filter: 判决书)** | ✅ |
| E | 案件类别 | |
| F | 审级 | |
| G-I | 日期 | |
| J | 案例级别 | |
| K | 法院层级 | |
| L | 案由 | |
| M-N | 省市 | |
| O | 年份 | |
| **P** | **支持情况 → reference_score** | ✅ |
| **Q** | **适用法条 → law matching** | |
| **R** | **判决书全文 → lawyer extraction** | |

#### Step 7.2: Load Law Codes First

```bash
# Load civil_code.json format
curl -X POST "http://localhost:8000/api/admin/data-loader/laws/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@civil_code.json" \
  -F "format_type=civil_code"

# Check status
curl "http://localhost:8000/api/admin/data-loader/laws/status" \
  -H "Authorization: Bearer $TOKEN"
```

#### Step 7.3: Load Case Records

```bash
# Load Excel file (filters for 判决书 automatically)
curl -X POST "http://localhost:8000/api/admin/data-loader/cases/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@your_cases.xlsx" \
  -F "generate_embeddings=false" \
  -F "batch_size=500"

# Check status
curl "http://localhost:8000/api/admin/data-loader/cases/status" \
  -H "Authorization: Bearer $TOKEN"
```

#### Step 7.4: Generate Embeddings (After Data Load)

```bash
# Run in batches (100 at a time)
for i in {1..50}; do
  echo "Generating embeddings batch $i..."
  curl -X POST "http://localhost:8000/api/admin/data-loader/generate-embeddings" \
    -H "Authorization: Bearer $TOKEN" \
    -F "target=cases" \
    -F "batch_size=100"
  sleep 3  # Give Ollama time to process
done
```

#### Step 7.5: Create Vector Index (After Embeddings)

```sql
-- Create IVFFlat index for fast similarity search
CREATE INDEX idx_legal_cases_embedding 
ON legal_cases USING ivfflat (embedding vector_cosine_ops) 
WITH (lists = 100);

CREATE INDEX idx_law_articles_embedding 
ON law_articles USING ivfflat (embedding vector_cosine_ops) 
WITH (lists = 100);
```

---

## 📊 Client-Aware Ranking Algorithm

### The Problem

When searching for reference cases, we need cases that are:
1. **Similar** to the current case
2. **Favorable** to our client's position

### The Solution

**Reference Score** (from Column P):
```
支持原告全部诉讼请求  →  +1.0  (原告 won completely)
部分支持原告          →  +0.3 to +0.9
中立/撤诉/调解        →   0.0
部分驳回             →  -0.3 to -0.9
驳回原告全部诉讼请求  →  -1.0  (原告 lost = 被告 won)
```

**Strategic Score Formula**:
```python
if client_role == "原告":
    adjusted_ref = reference_score      # Keep as-is
else:  # 被告
    adjusted_ref = -reference_score     # Flip sign

strategic_score = similarity × (1 + adjusted_ref) / 2
```

### Visual Example

| Case | Similarity | Ref Score | 原告 Score | 被告 Score |
|------|------------|-----------|------------|------------|
| A: 原告获赔30万 | 0.9 | +0.8 | **0.81** ⬆️ | 0.09 ⬇️ |
| B: 原告败诉 | 0.92 | -0.9 | 0.05 ⬇️ | **0.87** ⬆️ |
| C: 部分支持 | 0.85 | +0.3 | 0.55 | 0.30 |

---

## 🔌 API Reference

### Search Endpoints

#### GET /api/case-records/search

Basic search with client-aware ranking.

```bash
GET /api/case-records/search?q=交通事故十级伤残&client_role=原告&limit=10
```

**Parameters:**
- `q`: Search query (required)
- `client_role`: "原告" or "被告" (default: 原告)
- `case_type`: Filter by case type
- `case_cause`: Filter by case cause
- `limit`: Results count (1-50, default: 10)
- `use_vector`: Enable vector search (default: true)

**Response:**
```json
{
  "query": "交通事故十级伤残",
  "client_role": "原告",
  "total": 10,
  "cases": [
    {
      "id": "uuid",
      "case_name": "张某诉李某交通事故纠纷案",
      "case_cause": "机动车交通事故责任纠纷",
      "reference_score": 0.8,
      "adjusted_reference_score": 0.8,
      "strategic_score": 0.81,
      "vector_score": 0.9,
      "judgment_result": "支持原告..."
    }
  ]
}
```

#### POST /api/case-records/search/advanced

Advanced search with LLM reranking.

```bash
POST /api/case-records/search/advanced
Content-Type: application/json

{
  "query": "交通事故十级伤残",
  "client_role": "被告",
  "use_vector": true,
  "use_llm_rerank": true,
  "case_context": {
    "facts_summary": "对方闯红灯，我方当事人正常行驶...",
    "key_issues": ["责任划分", "赔偿金额"]
  }
}
```

### Data Loading Endpoints

#### POST /api/admin/data-loader/cases/upload

Upload Excel case file.

```bash
curl -X POST "http://localhost:8000/api/admin/data-loader/cases/upload" \
  -H "Authorization: Bearer TOKEN" \
  -F "file=@cases.xlsx" \
  -F "generate_embeddings=false" \
  -F "batch_size=500"
```

#### POST /api/admin/data-loader/laws/upload

Upload law codes (civil_code or pkulaw format).

```bash
curl -X POST "http://localhost:8000/api/admin/data-loader/laws/upload" \
  -H "Authorization: Bearer TOKEN" \
  -F "file=@civil_code.json" \
  -F "format_type=civil_code"
```

#### GET /api/admin/data-loader/stats

Get database statistics.

```json
{
  "legal_cases": {
    "total": 15000,
    "with_embeddings": 12500,
    "by_case_type": {"traffic_accident": 8000, "contract": 5000}
  },
  "law_articles": {
    "total": 2800,
    "with_embeddings": 2800
  }
}
```

---

## 🔍 Search Agent Integration

The Search Agent now automatically uses client-aware ranking:

```python
# In services/agents/search_agent.py

async def _run_search(self, session: AgentSession):
    collected_data = session.collected_data or {}
    case_type = collected_data.get("case_type", "")
    client_role = collected_data.get("client_role", "原告")  # NEW
    
    # ...
    
    # Search with client-aware ranking
    cases = await self._search_legal_cases(search_terms, case_type, client_role)
```

### Setting Client Role in Frontend

When starting a consultation, collect client_role:

```javascript
// In questionnaire or intake form
const caseData = {
  case_type: "traffic_accident",
  client_role: "原告",  // or "被告"
  // ... other fields
};
```

---

## ⚠️ Troubleshooting

### "pgvector extension not found"

```bash
# Check if installed
psql -c "SELECT * FROM pg_available_extensions WHERE name = 'vector'"

# If not available, install it first at OS level
sudo apt install postgresql-14-pgvector
```

### "Embedding generation slow"

1. Check Ollama is running: `curl http://localhost:11434/api/tags`
2. Use faster model: `EMBEDDING_MODEL=nomic-embed-text`
3. Process in smaller batches with delays

### "Search returns no results"

```sql
-- Check data exists
SELECT COUNT(*) FROM legal_cases WHERE is_active = true;

-- Check embeddings exist
SELECT COUNT(*) FROM legal_cases WHERE embedding IS NOT NULL;

-- Check index exists
\di idx_legal_cases_embedding
```

### "reference_score always 0"

Check Column P format in your Excel:
```python
# Test the parsing
from services.legal_data_loader import LegalDataLoader
loader = LegalDataLoader(db)
print(loader._calculate_reference_score("支持原告全部诉讼请求"))  # Should be 1.0
```

---

## 📁 Final Project Structure

After integration:

```
proj1/
├── main.py                           # MODIFIED
├── services/
│   ├── agents/
│   │   └── search_agent.py           # MODIFIED
│   ├── legal_case_search.py          # NEW
│   └── legal_data_loader.py          # NEW
├── routers/
│   ├── case_records.py               # NEW
│   └── data_loader.py                # NEW
├── migrations/
│   ├── CONSOLIDATED_MIGRATION.sql    # Original
│   └── FINAL_CONSOLIDATED_MIGRATION.sql  # NEW (Complete)
└── docs/
    └── LEGAL_DATA_INTEGRATION.md     # This file
```

---

## ✅ Integration Verification Checklist

- [ ] pgvector extension enabled
- [ ] Migration applied successfully
- [ ] New services copied (legal_case_search.py, legal_data_loader.py)
- [ ] search_agent.py replaced with enhanced version
- [ ] New routers copied (case_records.py, data_loader.py)
- [ ] main.py updated with new imports and includes
- [ ] Dependencies installed (pgvector, pandas, openpyxl)
- [ ] Embedding model pulled in Ollama
- [ ] Server starts without errors
- [ ] `/api/case-records/search` endpoint accessible
- [ ] `/api/admin/data-loader/stats` returns data
- [ ] Law codes loaded
- [ ] Case records loaded
- [ ] Embeddings generated (at least 50%)
- [ ] Vector index created
- [ ] Client-aware search working (test with 原告 and 被告)

---

## 🎯 Quick Test Commands

```bash
# 1. Health check
curl http://localhost:8000/health

# 2. Check stats
curl http://localhost:8000/api/admin/data-loader/stats -H "Authorization: Bearer TOKEN"

# 3. Test plaintiff search
curl "http://localhost:8000/api/case-records/search?q=交通事故&client_role=原告" -H "Authorization: Bearer TOKEN"

# 4. Test defendant search
curl "http://localhost:8000/api/case-records/search?q=交通事故&client_role=被告" -H "Authorization: Bearer TOKEN"

# 5. Compare results (plaintiff vs defendant rankings should differ!)
```

---

**Integration Complete! 🎉**

The system now supports intelligent case search that favors YOUR client's position.
