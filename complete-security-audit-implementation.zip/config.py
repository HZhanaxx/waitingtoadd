from pydantic_settings import BaseSettings
from pydantic import field_validator
from typing import Optional, List
import os


class Settings(BaseSettings):
    """
    Application settings loaded from environment variables.
    
    SECURITY NOTE:
    - SECRET_KEY and DATABASE_URL MUST be set via .env file
    - Never commit .env to version control
    - See .env.example for template
    """
    
    # Application
    APP_NAME: str = "Legal AI Assistant"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False  # Default to False for safety
    
    # Database - REQUIRED, no default for security
    DATABASE_URL: str
    
    # JWT Settings - REQUIRED, no default for security
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    
    # n8n Integration
    N8N_WEBHOOK_BASE_URL: str = "http://localhost:5678/webhook-test"
    N8N_JWT_SECRET: str = ""  # Must be set in .env
    N8N_JWT_ALGORITHM: str = "HS256"
    N8N_JWT_EXPIRE_HOURS: float = 0.5
    
    @field_validator('SECRET_KEY')
    @classmethod
    def validate_secret_key(cls, v: str) -> str:
        """Ensure SECRET_KEY is secure enough"""
        if len(v) < 32:
            raise ValueError(
                "SECRET_KEY must be at least 32 characters long. "
                "Generate one with: openssl rand -base64 64"
            )
        # Check for common placeholder values
        insecure_patterns = [
            'change_me', 'your_secret', 'secret_key', 'password',
            'dGhpcyBpcyBhIHZlcnkgc2VjdXJlIGtleQ'  # The old hardcoded value
        ]
        if any(pattern.lower() in v.lower() for pattern in insecure_patterns):
            raise ValueError(
                "SECRET_KEY appears to be a placeholder. "
                "Please set a secure random value in .env"
            )
        return v
    
    @field_validator('DATABASE_URL')
    @classmethod
    def validate_database_url(cls, v: str) -> str:
        """Validate DATABASE_URL format"""
        if not v.startswith(('postgresql://', 'postgres://')):
            raise ValueError("DATABASE_URL must be a PostgreSQL connection string")
        return v
    
    # ===========================================
    # LLM Settings (Ollama)
    # ===========================================
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "qwen3:8b"
    OLLAMA_TIMEOUT: int = 60
    OLLAMA_TEMPERATURE: float = 0.7
    OLLAMA_MAX_TOKENS: int = 4096
    
    # ===========================================
    # Embedding Settings
    # ===========================================
    EMBEDDING_MODEL: str = "nomic-embed-text"  # or "bge-m3", "mxbai-embed-large"
    EMBEDDING_DIM: int = 768  # nomic-embed-text=768, bge-m3=1024, text-embedding-ada=1536
    EMBEDDING_BATCH_SIZE: int = 10
    EMBEDDING_MAX_TEXT_LENGTH: int = 8000
    
    # ===========================================
    # Search Settings
    # ===========================================
    SEARCH_DEFAULT_LIMIT: int = 10
    SEARCH_MAX_LIMIT: int = 50
    SEARCH_VECTOR_WEIGHT: float = 0.6  # Weight for vector similarity (vs keyword)
    SEARCH_KEYWORD_WEIGHT: float = 0.4
    SEARCH_USE_VECTOR: bool = True  # Set False if pgvector not available
    SEARCH_USE_LLM_RERANK: bool = False  # Enable LLM reranking (slower but better)
    
    # ===========================================
    # Elasticsearch Settings (Law Articles)
    # ===========================================
    ELASTICSEARCH_HOST: str = "localhost"
    ELASTICSEARCH_PORT: int = 9200
    ELASTICSEARCH_ENABLED: bool = True  # You use ES for law_articles!
    
    # ===========================================
    # Redis (for session management)
    # ===========================================
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    REDIS_PASSWORD: Optional[str] = None
    
    # WeChat OAuth (Optional - leave empty if not using)
    WECHAT_APP_ID: Optional[str] = None
    WECHAT_APP_SECRET: Optional[str] = None
    WECHAT_REDIRECT_URI: Optional[str] = None
    WECHAT_ENABLED: bool = False  # Set to True when WeChat is configured
    
    # SMS Settings (example with Aliyun)
    SMS_ACCESS_KEY_ID: str = ""
    SMS_ACCESS_KEY_SECRET: str = ""
    SMS_SIGN_NAME: str = "Your App"
    SMS_TEMPLATE_CODE: str = "SMS_123456789"
    
    # CORS - Add all development origins
    CORS_ORIGINS: list = [
        "http://localhost:8080",
        "http://localhost:3000",
        "http://localhost:5173",  # Vite dev server
        "http://127.0.0.1:8080",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
    ]
    
    # Cookie Settings (Google-style HttpOnly cookies)
    COOKIE_SECURE: bool = False  # Set True in production (HTTPS only)
    COOKIE_SAMESITE: str = "lax"  # "strict" for max security, "lax" for usability
    COOKIE_HTTPONLY: bool = True  # Prevent JS access
    COOKIE_DOMAIN: Optional[str] = None  # None = current domain only
    
    # Security
    PASSWORD_MIN_LENGTH: int = 8
    BCRYPT_ROUNDS: int = 12
    SMS_CODE_EXPIRE_MINUTES: int = 5
    MAX_LOGIN_ATTEMPTS: int = 5
    LOCKOUT_DURATION_MINUTES: int = 30
    
    class Config:
        env_file = ".env"
        case_sensitive = True
    
    def is_wechat_enabled(self) -> bool:
        """Check if WeChat OAuth is properly configured"""
        return (
            self.WECHAT_ENABLED and
            self.WECHAT_APP_ID is not None and
            self.WECHAT_APP_SECRET is not None and
            self.WECHAT_REDIRECT_URI is not None and
            self.WECHAT_APP_ID != "" and
            self.WECHAT_APP_SECRET != ""
        )


settings = Settings()
